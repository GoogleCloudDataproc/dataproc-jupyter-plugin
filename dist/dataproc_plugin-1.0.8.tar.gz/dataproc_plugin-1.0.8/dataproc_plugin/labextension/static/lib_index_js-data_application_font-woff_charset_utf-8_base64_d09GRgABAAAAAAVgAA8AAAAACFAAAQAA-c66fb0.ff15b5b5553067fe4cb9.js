"use strict";
(self["webpackChunkdataproc_plugin"] = self["webpackChunkdataproc_plugin"] || []).push([["lib_index_js-data_application_font-woff_charset_utf-8_base64_d09GRgABAAAAAAVgAA8AAAAACFAAAQAA-c66fb0"],{

/***/ "./lib/batches/batchDetails.js":
/*!*************************************!*\
  !*** ./lib/batches/batchDetails.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _style_icons_left_arrow_icon_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../style/icons/left_arrow_icon.svg */ "./style/icons/left_arrow_icon.svg");
/* harmony import */ var _style_icons_clone_job_icon_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../style/icons/clone_job_icon.svg */ "./style/icons/clone_job_icon.svg");
/* harmony import */ var _utils_viewLogs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../utils/viewLogs */ "./lib/utils/viewLogs.js");
/* harmony import */ var _style_icons_delete_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../style/icons/delete_cluster_icon.svg */ "./style/icons/delete_cluster_icon.svg");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-spinners */ "webpack/sharing/consume/default/react-spinners/react-spinners");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_spinners__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../utils/utils */ "./lib/utils/utils.js");
/* harmony import */ var _utils_deletePopup__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../utils/deletePopup */ "./lib/utils/deletePopup.js");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-toastify */ "webpack/sharing/consume/default/react-toastify/react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/* harmony import */ var _utils_batchService__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../utils/batchService */ "./lib/utils/batchService.js");
/* harmony import */ var _utils_statusDisplay__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../utils/statusDisplay */ "./lib/utils/statusDisplay.js");
/* harmony import */ var _utils_pollingTimer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../utils/pollingTimer */ "./lib/utils/pollingTimer.js");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */















const iconLeftArrow = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:left-arrow-icon',
    svgstr: _style_icons_left_arrow_icon_svg__WEBPACK_IMPORTED_MODULE_5__
});
const iconCloneJob = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:clone-job-icon',
    svgstr: _style_icons_clone_job_icon_svg__WEBPACK_IMPORTED_MODULE_6__
});
const iconDeleteCluster = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:delete-cluster-icon',
    svgstr: _style_icons_delete_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_7__
});
function BatchDetails({ batchSelected, setDetailedBatchView }) {
    const [batchInfoResponse, setBatchInfoResponse] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        uuid: '',
        state: '',
        createTime: '',
        runtimeInfo: {
            approximateUsage: { milliDcuSeconds: '', shuffleStorageGbSeconds: '' }
        },
        creator: '',
        runtimeConfig: {
            version: '',
            properties: {
                'spark:spark.executor.instances': '',
                'spark:spark.driver.cores': '',
                'spark:spark.driver.memory': '',
                'spark:spark.executor.cores': '',
                'spark:spark.executor.memory': '',
                'spark:spark.dynamicAllocation.executorAllocationRatio': '',
                'spark:spark.app.name': ''
            }
        },
        sparkBatch: {
            mainJarFileUri: '',
            mainClass: '',
            jarFileUris: ''
        },
        pysparkBatch: {
            mainPythonFileUri: ''
        },
        sparkRBatch: {
            mainRFileUri: ''
        },
        sparkSqlBatch: {
            queryFileUri: ''
        },
        environmentConfig: {
            executionConfig: {
                serviceAccount: '',
                subnetworkUri: ''
            }
        },
        stateHistory: [{ state: '', stateStartTime: '' }],
        stateTime: ''
    });
    const [regionName, setRegionName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [labelDetail, setLabelDetail] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(['']);
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [deletePopupOpen, setDeletePopupOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [selectedBatch, setSelectedBatch] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const timer = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(undefined);
    const pollingBatchDetails = async (pollingFunction, pollingDisable) => {
        timer.current = (0,_utils_pollingTimer__WEBPACK_IMPORTED_MODULE_8__["default"])(pollingFunction, pollingDisable, timer.current);
    };
    const handleDetailedBatchView = () => {
        pollingBatchDetails(getBatchDetails, true);
        setDetailedBatchView(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        getBatchDetails();
        pollingBatchDetails(getBatchDetails, false);
        return () => {
            pollingBatchDetails(getBatchDetails, true);
        };
    }, []);
    const getBatchDetails = async () => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_9__.authApi)();
        if (credentials) {
            setRegionName(credentials.region_id || '');
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_10__.BASE_URL}/projects/${credentials.project_id}/locations/${credentials.region_id}/batches/${batchSelected}`, {
                method: 'GET',
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_10__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_10__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResult) => {
                    setBatchInfoResponse(responseResult);
                    if (responseResult.labels) {
                        const labelValue = Object.entries(responseResult.labels).map(([key, value]) => `${key}:${value}`);
                        setLabelDetail(labelValue);
                    }
                    setIsLoading(false);
                })
                    .catch((e) => {
                    console.log(e);
                    setIsLoading(false);
                });
            })
                .catch((err) => {
                setIsLoading(false);
                console.error('Error in getting Batch details', err);
                react_toastify__WEBPACK_IMPORTED_MODULE_3__.toast.error(`Failed to fetch batch details ${batchSelected}`);
            });
        }
    };
    const statusMsg = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_9__.statusMessageBatch)(batchInfoResponse);
    const startTime = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_9__.jobTimeFormat)(batchInfoResponse.createTime);
    const startTimeElapsed = new Date(batchInfoResponse.createTime);
    const endTime = new Date(batchInfoResponse.stateTime);
    let jobStartTime;
    let runTimeString = '';
    if (batchInfoResponse.stateHistory) {
        const lastStateHistory = batchInfoResponse.stateHistory[batchInfoResponse.stateHistory.length - 1];
        jobStartTime = new Date(lastStateHistory.stateStartTime);
        runTimeString = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_9__.elapsedTime)(endTime, jobStartTime);
    }
    const batch = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_9__.BatchTypeValue)(batchInfoResponse);
    const elapsedTimeString = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_9__.elapsedTime)(new Date(batchInfoResponse.stateTime), startTimeElapsed);
    const handleDeleteBatch = (batchSelected) => {
        setSelectedBatch(batchSelected);
        setDeletePopupOpen(true);
    };
    const handleCancelDelete = () => {
        setDeletePopupOpen(false);
    };
    const handleDelete = async () => {
        await (0,_utils_batchService__WEBPACK_IMPORTED_MODULE_11__.deleteBatchAPI)(selectedBatch);
        handleDetailedBatchView();
        setDeletePopupOpen(false);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_toastify__WEBPACK_IMPORTED_MODULE_3__.ToastContainer, null),
        batchInfoResponse.uuid === '' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "loader-full-style" }, isLoading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_spinners__WEBPACK_IMPORTED_MODULE_2__.ClipLoader, { color: "#8A8A8A", loading: true, size: 20, "aria-label": "Loading Spinner", "data-testid": "loader" }),
            "Loading Batch Details")))),
        deletePopupOpen && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_deletePopup__WEBPACK_IMPORTED_MODULE_12__["default"], { onCancel: () => handleCancelDelete(), onDelete: () => handleDelete(), deletePopupOpen: deletePopupOpen, DeleteMsg: 'This will delete ' + selectedBatch + ' and cannot be undone.' })),
        batchInfoResponse.uuid !== '' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "scroll-comp" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-header" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: "back-arrow-icon", onClick: () => handleDetailedBatchView() },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconLeftArrow.react, { tag: "div" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-title" }, batchSelected),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-disabled action-cluster-section" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-icon" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconCloneJob.react, { tag: "div" })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-text" }, "CLONE")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: "action-cluster-section", onClick: () => handleDeleteBatch(batchSelected) },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-icon" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconDeleteCluster.react, { tag: "div" })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-text" }, "DELETE")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_viewLogs__WEBPACK_IMPORTED_MODULE_13__["default"], { batchInfoResponse: batchInfoResponse })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "batch-details-container-top" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Batch ID"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, batchSelected)),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Batch UUID"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, batchInfoResponse.uuid)),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Resource type"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, "Batch")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Status"),
                    (0,_utils_statusDisplay__WEBPACK_IMPORTED_MODULE_14__.statusDisplay)(statusMsg))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-header" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-title" }, "Details")),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "batch-details-container" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Start time"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, startTime)),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Elapsed time"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, elapsedTimeString)),
                runTimeString !== '' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Run time"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, runTimeString))),
                batchInfoResponse.runtimeInfo.approximateUsage &&
                    batchInfoResponse.runtimeInfo.approximateUsage
                        .milliDcuSeconds && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Approximate DCU usage"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, (0,_utils_utils__WEBPACK_IMPORTED_MODULE_9__.convertToDCUHours)(batchInfoResponse.runtimeInfo.approximateUsage
                        .milliDcuSeconds)))),
                batchInfoResponse.runtimeInfo.approximateUsage &&
                    batchInfoResponse.runtimeInfo.approximateUsage
                        .shuffleStorageGbSeconds && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Approximate shuffle storage usage"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, (0,_utils_utils__WEBPACK_IMPORTED_MODULE_9__.convertToGBMonths)(batchInfoResponse.runtimeInfo.approximateUsage
                        .shuffleStorageGbSeconds)))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Creator"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, batchInfoResponse.creator)),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Version"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, batchInfoResponse.runtimeConfig.version)),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Region"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, regionName)),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Batch type"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, batch)),
                batch === 'Spark' &&
                    batchInfoResponse.sparkBatch.mainJarFileUri && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Main jar"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, batchInfoResponse.sparkBatch.mainJarFileUri))),
                batch === 'Spark' && batchInfoResponse.sparkBatch.mainClass && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Main class"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, batchInfoResponse.sparkBatch.mainClass)),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Jar files"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, batchInfoResponse.sparkBatch.jarFileUris ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, batchInfoResponse.sparkBatch.jarFileUris)) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, "None")))))),
                batch === 'PySpark' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Main python file"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, batchInfoResponse.pysparkBatch.mainPythonFileUri))),
                batch === 'SparkR' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Main R file"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, batchInfoResponse.sparkRBatch.mainRFileUri))),
                batch === 'SparkSQL' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Query file"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, batchInfoResponse.sparkSqlBatch.queryFileUri))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Properties"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" })),
                Object.entries(batchInfoResponse.runtimeConfig.properties).map(([key, value]) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details", key: key },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "batch-details-label-level-one" }, key),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, value)))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Environment config"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "batch-details-label-level-one" }, "Execution config"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" })),
                Object.entries(batchInfoResponse.environmentConfig.executionConfig).map(([key, value]) => {
                    let label;
                    if (key === _utils_const__WEBPACK_IMPORTED_MODULE_10__.SERVICE_ACCOUNT_KEY) {
                        label = _utils_const__WEBPACK_IMPORTED_MODULE_10__.SERVICE_ACCOUNT_LABEL;
                    }
                    else if (key === _utils_const__WEBPACK_IMPORTED_MODULE_10__.NETWORK_KEY) {
                        label = _utils_const__WEBPACK_IMPORTED_MODULE_10__.NETWORK_LABEL;
                    }
                    else if (key === _utils_const__WEBPACK_IMPORTED_MODULE_10__.SUBNETWORK_KEY) {
                        label = _utils_const__WEBPACK_IMPORTED_MODULE_10__.SUBNETWORK_LABEL;
                    }
                    else {
                        label = '';
                    }
                    if (key === _utils_const__WEBPACK_IMPORTED_MODULE_10__.SERVICE_ACCOUNT_KEY ||
                        key === _utils_const__WEBPACK_IMPORTED_MODULE_10__.NETWORK_KEY ||
                        key === _utils_const__WEBPACK_IMPORTED_MODULE_10__.SUBNETWORK_KEY) {
                        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details", key: key },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "batch-details-label-level-two" }, label),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, value)));
                    }
                }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Encryption type"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" }, "Google-managed")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "batch-details-row-label" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-label" }, "Labels"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "details-value" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "job-label-style-parent" }, labelDetail.length > 0
                            ? labelDetail.map(label => {
                                const labelParts = label.split(':');
                                return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: label, className: "job-label-style" },
                                    labelParts[0],
                                    " : ",
                                    labelParts[1]));
                            })
                            : ''))))))));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BatchDetails);


/***/ }),

/***/ "./lib/batches/batches.js":
/*!********************************!*\
  !*** ./lib/batches/batches.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Batches: () => (/* binding */ Batches)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../utils/utils */ "./lib/utils/utils.js");
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/* harmony import */ var _listBatches__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./listBatches */ "./lib/batches/listBatches.js");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _style_icons_delete_icon_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../style/icons/delete_icon.svg */ "./style/icons/delete_icon.svg");
/* harmony import */ var _batchDetails__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./batchDetails */ "./lib/batches/batchDetails.js");
/* harmony import */ var _sessions_listSessions__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../sessions/listSessions */ "./lib/sessions/listSessions.js");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-spinners */ "webpack/sharing/consume/default/react-spinners/react-spinners");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_spinners__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_deletePopup__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../utils/deletePopup */ "./lib/utils/deletePopup.js");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-toastify */ "webpack/sharing/consume/default/react-toastify/react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/* harmony import */ var _utils_batchService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../utils/batchService */ "./lib/utils/batchService.js");
/* harmony import */ var _createBatch__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./createBatch */ "./lib/batches/createBatch.js");
/* harmony import */ var _utils_pollingTimer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../utils/pollingTimer */ "./lib/utils/pollingTimer.js");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
















const iconDelete = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:delete-icon',
    svgstr: _style_icons_delete_icon_svg__WEBPACK_IMPORTED_MODULE_6__
});
const BatchesComponent = () => {
    const [batchesList, setBatchesList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [selectedMode, setSelectedMode] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('Batches');
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [batchSelected, setBatchSelected] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const [pollingDisable, setPollingDisable] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [detailedBatchView, setDetailedBatchView] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [loggedIn, setLoggedIn] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [configError, setConfigError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [loginError, setLoginError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [configLoading, setConfigLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [deletePopupOpen, setDeletePopupOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [selectedBatch, setSelectedBatch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const [regionName, setRegionName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const [projectName, setProjectName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const [createBatchView, setCreateBatchView] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const timer = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(undefined);
    const pollingBatches = async (pollingFunction, pollingDisable) => {
        timer.current = (0,_utils_pollingTimer__WEBPACK_IMPORTED_MODULE_7__["default"])(pollingFunction, pollingDisable, timer.current);
    };
    const selectedModeChange = (mode) => {
        setSelectedMode(mode);
    };
    const listBatchAPI = async (nextPageToken, previousBatchesList) => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_8__.authApi)();
        const pageToken = nextPageToken !== null && nextPageToken !== void 0 ? nextPageToken : '';
        if (credentials) {
            setRegionName(credentials.region_id || '');
            setProjectName(credentials.project_id || '');
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_9__.BASE_URL}/projects/${credentials.project_id}/locations/${credentials.region_id}/batches?orderBy=create_time desc&&pageSize=50&pageToken=${pageToken}`, {
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_9__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_9__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResult) => {
                    let transformBatchListData = [];
                    if (responseResult && responseResult.batches) {
                        transformBatchListData = responseResult.batches.map((data) => {
                            const startTimeDisplay = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_8__.jobTimeFormat)(data.createTime);
                            const startTime = new Date(data.createTime);
                            const elapsedTimeString = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_8__.elapsedTime)(data.stateTime, startTime);
                            const batchType = Object.keys(data).filter(key => key.endsWith('Batch'));
                            /*
                             Extracting batchID, location from batchInfo.name
                              Example: "projects/{project}/locations/{location}/batches/{batchID}"
                            */
                            const batchTypeDisplay = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_8__.jobTypeDisplay)(batchType[0].split('Batch')[0]);
                            return {
                                batchID: data.name.split('/')[5],
                                status: data.state,
                                location: data.name.split('/')[3],
                                creationTime: startTimeDisplay,
                                type: batchTypeDisplay,
                                elapsedTime: elapsedTimeString,
                                actions: renderActions(data)
                            };
                        });
                    }
                    const existingBatchData = previousBatchesList !== null && previousBatchesList !== void 0 ? previousBatchesList : [];
                    //setStateAction never type issue
                    let allBatchesData = [
                        ...existingBatchData,
                        ...transformBatchListData
                    ];
                    if (responseResult.nextPageToken) {
                        listBatchAPI(responseResult.nextPageToken, allBatchesData);
                    }
                    else {
                        setBatchesList(allBatchesData);
                        setIsLoading(false);
                        setLoggedIn(true);
                    }
                })
                    .catch((e) => {
                    console.log(e);
                    setIsLoading(false);
                });
            })
                .catch((err) => {
                setIsLoading(false);
                console.error('Error listing batches', err);
                react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error('Failed to fetch batches');
            });
        }
    };
    const handleBatchDetails = (selectedName) => {
        pollingBatches(listBatchAPI, true);
        setBatchSelected(selectedName);
        setDetailedBatchView(true);
    };
    const handleDeleteBatch = (batch) => {
        setSelectedBatch(batch);
        setDeletePopupOpen(true);
    };
    const handleCancelDelete = () => {
        setDeletePopupOpen(false);
    };
    const handleDelete = async () => {
        await (0,_utils_batchService__WEBPACK_IMPORTED_MODULE_10__.deleteBatchAPI)(selectedBatch);
        listBatchAPI();
        setDetailedBatchView(false);
        setDeletePopupOpen(false);
    };
    const renderActions = (data) => {
        return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "actions-icon", role: "button", "aria-label": "Delete Job" },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "icon-buttons-style", title: "Delete Batch", onClick: () => handleDeleteBatch(data.name.split('/')[5]) },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement(iconDelete.react, { tag: "div" }))));
    };
    const toggleStyleSelection = (toggleItem) => {
        if (selectedMode === toggleItem) {
            return 'selected-header';
        }
        else {
            return 'unselected-header';
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        (0,_utils_utils__WEBPACK_IMPORTED_MODULE_8__.checkConfig)(setLoggedIn, setConfigError, setLoginError);
        const localstorageGetInformation = localStorage.getItem('loginState');
        setLoggedIn(localstorageGetInformation === _utils_const__WEBPACK_IMPORTED_MODULE_9__.LOGIN_STATE);
        if (loggedIn) {
            setConfigLoading(false);
        }
        listBatchAPI();
        if (!detailedBatchView && selectedMode === 'Batches') {
            pollingBatches(listBatchAPI, pollingDisable);
        }
        return () => {
            pollingBatches(listBatchAPI, true);
        };
    }, [pollingDisable, detailedBatchView, selectedMode]);
    return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "component-level" },
        configLoading && !loggedIn && !configError && !loginError && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "spin-loaderMain" },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement(react_spinners__WEBPACK_IMPORTED_MODULE_3__.ClipLoader, { color: "#8A8A8A", loading: true, size: 18, "aria-label": "Loading Spinner", "data-testid": "loader" }),
            "Loading Batches")),
        deletePopupOpen && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_utils_deletePopup__WEBPACK_IMPORTED_MODULE_11__["default"], { onCancel: () => handleCancelDelete(), onDelete: () => handleDelete(), deletePopupOpen: deletePopupOpen, DeleteMsg: 'This will delete ' + selectedBatch + ' and cannot be undone.' })),
        loggedIn && !configError ? (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
            detailedBatchView && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_batchDetails__WEBPACK_IMPORTED_MODULE_12__["default"], { batchSelected: batchSelected, setDetailedBatchView: setDetailedBatchView })),
            createBatchView && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_createBatch__WEBPACK_IMPORTED_MODULE_13__["default"], { setCreateBatchView: setCreateBatchView, regionName: regionName, projectName: projectName })),
            !detailedBatchView && !createBatchView && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "clusters-list-component", role: "tablist" },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "clusters-list-overlay", role: "tab" },
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { role: "tabpanel", className: toggleStyleSelection('Batches'), onClick: () => selectedModeChange('Batches') }, "Batches"),
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { role: "tabpanel", className: toggleStyleSelection('Sessions'), onClick: () => selectedModeChange('Sessions') }, "Sessions")),
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", null, selectedMode === 'Sessions' ? (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_sessions_listSessions__WEBPACK_IMPORTED_MODULE_14__["default"], null)) : (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_listBatches__WEBPACK_IMPORTED_MODULE_15__["default"], { batchesList: batchesList, isLoading: isLoading, setPollingDisable: setPollingDisable, listBatchAPI: listBatchAPI, handleBatchDetails: handleBatchDetails, setCreateBatchView: setCreateBatchView, createBatchView: createBatchView }))),
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement(react_toastify__WEBPACK_IMPORTED_MODULE_4__.ToastContainer, null))))) : (loginError && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { role: "alert", className: "login-error" }, "Please login to continue"))),
        configError && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { role: "alert", className: "login-error" }, "Please configure gcloud with account, project-id and region"))));
};
class Batches extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ReactWidget {
    constructor() {
        super();
    }
    render() {
        return react__WEBPACK_IMPORTED_MODULE_1___default().createElement(BatchesComponent, null);
    }
}


/***/ }),

/***/ "./lib/batches/createBatch.js":
/*!************************************!*\
  !*** ./lib/batches/createBatch.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _style_icons_left_arrow_icon_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../style/icons/left_arrow_icon.svg */ "./style/icons/left_arrow_icon.svg");
/* harmony import */ var semantic_ui_css_semantic_min_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! semantic-ui-css/semantic.min.css */ "./node_modules/semantic-ui-css/semantic.min.css");
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! semantic-ui-react */ "webpack/sharing/consume/default/semantic-ui-react/semantic-ui-react");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/* harmony import */ var react_tagsinput__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-tagsinput */ "webpack/sharing/consume/default/react-tagsinput/react-tagsinput");
/* harmony import */ var react_tagsinput__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_tagsinput__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_tagsinput_react_tagsinput_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-tagsinput/react-tagsinput.css */ "./node_modules/react-tagsinput/react-tagsinput.css");
/* harmony import */ var _jobs_labelProperties__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../jobs/labelProperties */ "./lib/jobs/labelProperties.js");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../utils/utils */ "./lib/utils/utils.js");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-spinners */ "webpack/sharing/consume/default/react-spinners/react-spinners");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_spinners__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-toastify */ "webpack/sharing/consume/default/react-toastify/react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _utils_errorPopup__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../utils/errorPopup */ "./lib/utils/errorPopup.js");
/* harmony import */ var _style_icons_error_icon_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../style/icons/error_icon.svg */ "./style/icons/error_icon.svg");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */















const iconLeftArrow = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:left-arrow-icon',
    svgstr: _style_icons_left_arrow_icon_svg__WEBPACK_IMPORTED_MODULE_9__
});
const iconError = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:error-icon',
    svgstr: _style_icons_error_icon_svg__WEBPACK_IMPORTED_MODULE_10__
});
let jarFileUris = [];
let fileUris = [];
let archiveFileUris = [];
let argumentsUris = [];
let networkUris = [];
let key = [];
let value = [];
let pythonFileUris = [];
function CreateBatch({ setCreateBatchView, regionName, projectName }) {
    const [batchTypeList, setBatchTypeList] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([{}]);
    const [versionList, setVersionList] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([{}]);
    const [generationCompleted, setGenerationCompleted] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [hexNumber, setHexNumber] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [batchIdSelected, setBatchIdSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [batchTypeSelected, setBatchTypeSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('spark');
    const [versionSelected, setVersionSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('2.1');
    const [selectedRadio, setSelectedRadio] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('mainClass');
    const [mainClassSelected, setMainClassSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [mainJarSelected, setMainJarSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [mainRSelected, setMainRSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [containerImageSelected, setContainerImageSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [jarFilesSelected, setJarFilesSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([...jarFileUris]);
    const [filesSelected, setFilesSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([...fileUris]);
    const [queryFileSelected, setQueryFileSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [ArchiveFilesSelected, setArchiveFileSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([
        ...archiveFileUris
    ]);
    const [argumentsSelected, setArgumentsSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([
        ...argumentsUris
    ]);
    const [serviceAccountSelected, setServiceAccountSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [networkTagSelected, setNetworkTagSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([
        ...networkUris
    ]);
    const [propertyDetail, setPropertyDetail] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(['']);
    const [propertyDetailUpdated, setPropertyDetailUpdated] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(['']);
    const [keyValidation, setKeyValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(-1);
    const [valueValidation, setvalueValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(-1);
    const [duplicateKeyError, setDuplicateKeyError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(-1);
    const [labelDetail, setLabelDetail] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(key);
    const [labelDetailUpdated, setLabelDetailUpdated] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(value);
    const [servicesList, setServicesList] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [servicesSelected, setServicesSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('None');
    const [clusterSelected, setClusterSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [projectId, setProjectId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [region, setRegion] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [projectList, setProjectList] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([{}]);
    const [regionList, setRegionList] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [networkList, setNetworklist] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([{}]);
    const [isLoadingRegion, setIsLoadingRegion] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [networkSelected, setNetworkSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('default');
    const [subNetworkSelected, setSubNetworkSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('default');
    const [isLoadingService, setIsLoadingService] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({ isOpen: false, message: '' });
    const [parameterDetail, setParameterDetail] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(['']);
    const [parameterDetailUpdated, setParameterDetailUpdated] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(['']);
    const [additionalPythonFileSelected, setAdditionalPythonFileSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([...pythonFileUris]);
    const [mainPythonSelected, setMainPythonSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [clustersList, setClustersList] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [additionalPythonFileValidation, setAdditionalPythonFileValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [jarFileValidation, setJarFileValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [fileValidation, setFileValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [archieveFileValidation, setArchieveFileValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [mainPythonValidation, setMainPythonValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [queryFileValidation, setQueryFileValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [mainRValidation, setMainRValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [batchIdValidation, setBatchIdValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [mainJarValidation, setMainJarValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const handleCreateBatchBackView = () => {
        setCreateBatchView(false);
    };
    const handleMainClassRadio = () => {
        setSelectedRadio('mainClass');
        setMainJarSelected('');
        setMainClassSelected('');
    };
    const handleMainJarRadio = () => {
        setSelectedRadio('mainJarURI');
        setMainClassSelected('');
        setMainJarSelected('');
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const batchTypeData = [
            { key: 'spark', value: 'spark', text: 'Spark' },
            { key: 'sparkR', value: 'sparkR', text: 'SparkR' },
            { key: 'sparkSql', value: 'sparkSql', text: 'SparkSql' },
            { key: 'pySpark', value: 'pySpark', text: 'PySpark' }
        ];
        const runTimeVersionData = [
            {
                key: '2.1',
                value: '2.1',
                text: '2.1 (Spark 3.4, Java 17, Scala 2.13)'
            },
            {
                key: '2.0',
                value: '2.0',
                text: '2.0 (Spark 3.3, Java 17, Scala 2.13)'
            },
            {
                key: '1.1',
                value: '1.1',
                text: '1.1 (Spark 3.3, Java 11, Scala 2.12)'
            }
        ];
        setVersionList(runTimeVersionData);
        setBatchTypeList(batchTypeData);
        projectListAPI();
        listClustersAPI();
        listNetworksAPI();
    }, [clusterSelected]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        generateRandomHex();
    }, [
        batchIdSelected,
        mainClassSelected,
        mainRSelected,
        mainPythonSelected,
        queryFileSelected,
        jarFileValidation,
        mainJarValidation,
        archieveFileValidation,
        mainRValidation,
        fileValidation,
        mainPythonValidation,
        queryFileValidation,
        keyValidation,
        valueValidation,
        batchIdValidation,
        duplicateKeyError
    ]);
    function isSubmitDisabled() {
        const commonConditions = batchIdSelected === '' || regionName === '';
        switch (batchTypeSelected) {
            case 'spark':
                return (commonConditions ||
                    (selectedRadio === 'mainClass' && mainClassSelected === '') ||
                    (selectedRadio === 'mainJarURI' && mainJarSelected === '') ||
                    !mainJarValidation ||
                    !fileValidation ||
                    !archieveFileValidation);
            case 'sparkR':
                return (commonConditions ||
                    mainRSelected === '' ||
                    !mainRValidation ||
                    !fileValidation ||
                    !archieveFileValidation);
            case 'pySpark':
                return (commonConditions ||
                    mainPythonSelected === '' ||
                    !mainPythonValidation ||
                    !additionalPythonFileValidation ||
                    !fileValidation ||
                    !archieveFileValidation);
            case 'sparkSql':
                return (commonConditions ||
                    queryFileSelected === '' ||
                    !queryFileValidation ||
                    !jarFileValidation);
            default:
                return false;
        }
    }
    const handleValidationFiles = (listOfFiles, setValuesPart, setValidationPart) => {
        if (typeof listOfFiles === 'string') {
            if (listOfFiles.startsWith('file://') ||
                listOfFiles.startsWith('gs://') ||
                listOfFiles.startsWith('hdfs://')) {
                setValidationPart(true);
            }
            else {
                setValidationPart(false);
            }
            setValuesPart(listOfFiles);
        }
        else {
            if (listOfFiles.length === 0) {
                setValidationPart(true);
            }
            else {
                listOfFiles.forEach((fileName) => {
                    if (fileName.startsWith('file://') ||
                        fileName.startsWith('gs://') ||
                        fileName.startsWith('hdfs://')) {
                        setValidationPart(true);
                    }
                    else {
                        setValidationPart(false);
                    }
                });
            }
            setValuesPart(listOfFiles);
        }
    };
    const listClustersAPI = async () => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_11__.authApi)();
        if (credentials) {
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_12__.BASE_URL}/projects/${credentials.project_id}/regions/${credentials.region_id}/clusters?pageSize=100`, {
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_12__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_12__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResult) => {
                    let transformClusterListData = [];
                    transformClusterListData = responseResult.clusters.filter((data) => {
                        if (data.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_12__.STATUS_RUNNING) {
                            return {
                                clusterName: data.clusterName
                            };
                        }
                    });
                    const keyLabelStructure = transformClusterListData.map((obj) => ({
                        key: obj.clusterName,
                        value: obj.clusterName,
                        text: obj.clusterName
                    }));
                    setClustersList(keyLabelStructure);
                })
                    .catch((e) => {
                    console.log(e);
                });
            })
                .catch((err) => {
                console.error('Error listing clusters', err);
            });
        }
    };
    const listNetworksAPI = async () => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_11__.authApi)();
        if (credentials) {
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_12__.BASE_URL_NETWORKS}/projects/${credentials.project_id}/regions/${credentials.region_id}/subnetworks`, {
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_12__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_12__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResult) => {
                    let transformedNetworkList = [];
                    /*
              Extracting network, subnetwork from items
              Example: "https://www.googleapis.com/compute/v1/projects/{projectName}/global/networks/",
           */
                    transformedNetworkList = responseResult.items.map((data) => {
                        return {
                            network: data.network.split('/')[9],
                            subnetworks: data.selfLink.split('/')[10]
                        };
                    });
                    const keyLabelStructureNetwork = transformedNetworkList.map((obj) => ({
                        key: obj.network,
                        value: obj.network,
                        text: obj.network
                    }));
                    setNetworklist(keyLabelStructureNetwork);
                })
                    .catch((e) => {
                    console.log(e);
                });
            })
                .catch((err) => {
                console.error('Error listing Networks', err);
            });
        }
    };
    const listMetaStoreAPI = async (data) => {
        setIsLoadingService(true);
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_11__.authApi)();
        if (credentials) {
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_12__.BASE_URL_META}/projects/${projectId}/locations/${data}/services`, {
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_12__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_12__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResult) => {
                    let transformClusterListData = [];
                    transformClusterListData = responseResult.services.filter((data) => {
                        return {
                            name: data.name
                        };
                    });
                    const keyLabelStructure = transformClusterListData.map((obj) => ({
                        key: obj.name,
                        value: obj.name,
                        text: obj.name
                    }));
                    const noneOption = { key: 'None', value: 'None', text: 'None' };
                    setServicesList([noneOption, ...keyLabelStructure]);
                    setIsLoadingService(false);
                })
                    .catch((e) => {
                    console.log(e);
                    setIsLoadingService(false);
                });
            })
                .catch((err) => {
                console.error('Error listing services', err);
                setIsLoadingService(false);
            });
        }
    };
    const projectListAPI = async () => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_11__.authApi)();
        if (credentials) {
            fetch(_utils_const__WEBPACK_IMPORTED_MODULE_12__.PROJECT_LIST_URL, {
                method: 'GET',
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_12__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_12__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResult) => {
                    let transformedProjectList = [];
                    transformedProjectList = responseResult.projects.map((data) => {
                        return {
                            value: data.projectId,
                            key: data.projectId,
                            text: data.projectId
                        };
                    });
                    setProjectList(transformedProjectList);
                })
                    .catch((e) => console.log(e));
            })
                .catch((err) => {
                console.error('Error fetching project list', err);
            });
        }
    };
    const regionListAPI = async (projectId) => {
        setIsLoadingRegion(true);
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_11__.authApi)();
        if (credentials) {
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_12__.REGION_URL}${projectId}/regions`, {
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_12__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_12__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResult) => {
                    let transformedRegionList = [];
                    transformedRegionList = responseResult.items.map((data) => {
                        return {
                            value: data.name,
                            key: data.name,
                            text: data.name
                        };
                    });
                    setRegionList(transformedRegionList);
                    setIsLoadingRegion(false);
                })
                    .catch((e) => {
                    console.log(e);
                    setIsLoadingRegion(false);
                });
            })
                .catch((err) => {
                console.error('Error listing regions', err);
                setIsLoadingRegion(false);
            });
        }
    };
    const createPayload = (batchTypeSelected, mainJarSelected, mainClassSelected, propertyObject, ArchiveFilesSelected, filesSelected, jarFilesSelected, argumentsSelected, networkTagSelected, labelObject, projectName, regionName, clusterSelected, batchIdSelected, parameterObject, mainRSelected, additionalPythonFileSelected, mainPythonSelected, queryFileSelected) => {
        const payload = {};
        if (batchTypeSelected === 'spark') {
            payload.sparkBatch = {
                ...(mainJarSelected !== '' && { mainJarFileUri: mainJarSelected }),
                ...(mainClassSelected !== '' && { mainClass: mainClassSelected }),
            };
        }
        if (batchTypeSelected === 'sparkR') {
            payload.sparkRBatch = {
                ...(mainRSelected !== '' && { mainRFileUri: mainRSelected }),
            };
        }
        if (batchTypeSelected === 'pySpark') {
            payload.pysparkBatch = {
                ...(additionalPythonFileSelected.length > 0 && {
                    pythonFileUris: additionalPythonFileSelected,
                }),
                ...(mainPythonSelected !== '' && {
                    mainPythonFileUri: mainPythonSelected,
                }),
            };
        }
        if (batchTypeSelected === 'sparkSql') {
            payload.sparkSqlBatch = {
                ...(queryFileSelected !== '' && { queryFileUri: queryFileSelected }),
                ...(parameterObject && { queryVariables: { query: parameterObject } }),
            };
        }
        payload.labels = labelObject;
        payload.name = `projects/${projectName}/locations/${regionName}/batches/${batchIdSelected}`;
        payload.runtimeConfig = {
            version: versionSelected,
            ...(containerImageSelected !== '' && {
                containerImage: containerImageSelected,
            }),
            ...(propertyObject && { properties: propertyObject }),
        };
        payload.environmentConfig = {
            executionConfig: {
                ...(serviceAccountSelected !== '' && {
                    serviceAccount: serviceAccountSelected,
                }),
                subnetworkUri: networkSelected,
                ...(networkTagSelected.length > 0 && {
                    networkTags: networkTagSelected,
                }),
            },
        };
        if (servicesSelected !== 'None' || clusterSelected !== '') {
            payload.peripheralsConfig = {
                ...(servicesSelected !== 'None' && {
                    metastoreService: servicesSelected,
                }),
                ...(clusterSelected !== '' && {
                    sparkHistoryServerConfig: {
                        dataprocCluster: `projects/${projectName}/locations/${regionName}/clusters/${clusterSelected}`,
                    },
                }),
            };
        }
        payload.archiveUris =
            ArchiveFilesSelected.length > 0 ? ArchiveFilesSelected : undefined;
        payload.fileUris = filesSelected.length > 0 ? filesSelected : undefined;
        payload.jarFileUris = jarFilesSelected.length > 0 ? jarFilesSelected : undefined;
        payload.args = argumentsSelected.length > 0 ? argumentsSelected : undefined;
        return payload;
    };
    const handleSubmit = async () => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_11__.authApi)();
        if (credentials) {
            const labelObject = {};
            labelDetailUpdated.forEach((label) => {
                const labelSplit = label.split(':');
                const key = labelSplit[0];
                const value = labelSplit[1];
                labelObject[key] = value;
            });
            const propertyObject = {};
            propertyDetailUpdated.forEach((label) => {
                const labelSplit = label.split(':');
                const key = labelSplit[0];
                const value = labelSplit[1];
                propertyObject[key] = value;
            });
            const parameterObject = {};
            parameterDetailUpdated.forEach((label) => {
                const labelSplit = label.split(':');
                const key = labelSplit[0];
                const value = labelSplit[1];
                parameterObject[key] = value;
            });
            const payload = createPayload(batchTypeSelected, mainJarSelected, mainClassSelected, propertyObject, ArchiveFilesSelected, filesSelected, jarFilesSelected, argumentsSelected, networkTagSelected, labelObject, projectName, regionName, clusterSelected, batchIdSelected, parameterObject, mainRSelected, additionalPythonFileSelected, mainPythonSelected, queryFileSelected);
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_12__.BASE_URL}/projects/${credentials.project_id}/locations/${credentials.region_id}/batches?batchId=${batchIdSelected}`, {
                method: 'POST',
                body: JSON.stringify(payload),
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_12__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_12__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then(async (response) => {
                if (response.ok) {
                    const responseResult = await response.json();
                    console.log(responseResult);
                    setCreateBatchView(false);
                }
                else {
                    const errorResponse = await response.json();
                    console.log(errorResponse);
                    setError({ isOpen: true, message: errorResponse.error.message });
                }
            })
                .catch((err) => {
                console.error('Error submitting Batch', err);
                react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast.error('Failed to submit the Batch');
            });
        }
    };
    const generateRandomHex = () => {
        if (!generationCompleted) {
            const crypto = window.crypto || window.Crypto;
            const array = new Uint32Array(1);
            crypto.getRandomValues(array);
            const hex = array[0].toString(16);
            const paddedHex = hex.padStart(6, '0');
            setHexNumber('batch-' + paddedHex);
            setBatchIdSelected('batch-' + paddedHex);
            setGenerationCompleted(true);
        }
    };
    const handleInputChange = (event) => {
        setHexNumber(event.target.value);
        event.target.value.length > 0
            ? setBatchIdValidation(false)
            : setBatchIdValidation(true);
        const newBatchId = event.target.value;
        setBatchIdSelected(newBatchId);
    };
    const handleBatchTypeSelected = (event, data) => {
        setBatchTypeSelected(data.value);
        setFilesSelected([]);
        setJarFilesSelected([]);
        setAdditionalPythonFileSelected([]);
        setArchiveFileSelected([]);
        setArgumentsSelected([]);
        setMainPythonSelected('');
        setMainRSelected('');
        setQueryFileSelected('');
        setMainClassSelected('');
    };
    const handleVersionSelected = (event, data) => {
        setVersionSelected(data.value);
    };
    const handleServiceSelected = (event, data) => {
        setServicesSelected(data.value);
    };
    const handleProjectIdChange = (event, data) => {
        regionListAPI(data.value);
        setProjectId(data.value);
    };
    const handleRegionChange = (event, data) => {
        setRegion(data.value);
        listMetaStoreAPI(data.value);
    };
    const handleNetworkChange = (event, data) => {
        setNetworkSelected(data.value);
        setSubNetworkSelected(data.value);
    };
    const handleSubNetworkChange = (event, data) => {
        setSubNetworkSelected(data.value);
    };
    const handleClusterSelected = (event, data) => {
        setClusterSelected(data.value);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "scroll-comp" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-header" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "back-arrow-icon", onClick: () => handleCreateBatchBackView() },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconLeftArrow.react, { tag: "div" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-title" }, "Create batch")),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-container" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("form", { onSubmit: handleSubmit },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-label-header" }, "Batch info"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" }, "Batch ID*"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__.Input, { className: "create-batch-style ", value: hexNumber, onChange: e => handleInputChange(e), type: "text" }),
                    batchIdValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "ID is required"))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" }, "Region*"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__.Select, { className: "select-job-style", value: regionName, type: "text", disabled: true, options: [], placeholder: regionName }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-label-header" }, "Container"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" }, "Batch type*"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__.Select, { className: "select-job-style", value: batchTypeSelected, type: "text", options: batchTypeList, onChange: handleBatchTypeSelected }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" }, "Runtime version*"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__.Select, { className: "select-job-style", value: versionSelected, type: "text", options: versionList, onChange: handleVersionSelected }),
                    batchTypeSelected === 'spark' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-radio" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__.Radio, { className: "select-batch-radio-style", value: "mainClass", checked: selectedRadio === 'mainClass', onChange: handleMainClassRadio }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-message" }, "Main class")),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-sub-message" }, "The fully qualified name of a class in a provided or standard jar file, for example, com.example.wordcount.")),
                        selectedRadio === 'mainClass' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-input" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-message" }, "Main class*"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__.Input, { className: "create-batch-style ", value: mainClassSelected, onChange: e => setMainClassSelected(e.target.value), type: "text" }),
                            selectedRadio === 'mainClass' &&
                                mainClassSelected === '' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "Main class is required"))))))),
                    batchTypeSelected === 'spark' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-radio" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__.Radio, { className: "select-batch-radio-style", value: "mainJarURI", checked: selectedRadio === 'mainJarURI', onChange: handleMainJarRadio }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-message" }, "Main jar URI")),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-sub-message" }, "A provided jar file to use the main class of that jar file.")),
                        selectedRadio === 'mainJarURI' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-input" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-message" }, "Main jar*"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__.Input, { className: "create-batch-style ", value: mainJarSelected, onChange: e => handleValidationFiles(e.target.value, setMainJarSelected, setMainJarValidation), type: "text" }),
                            selectedRadio === 'mainJarURI' &&
                                mainJarSelected === '' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "Main jar is required"))),
                            !mainJarValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "File must include a valid scheme prefix: 'file://', 'gs://', or 'hdfs://'"))))))),
                    batchTypeSelected === 'sparkR' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-message" }, "Main R file*"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__.Input, { className: "create-batch-style", onChange: e => handleValidationFiles(e.target.value, setMainRSelected, setMainRValidation), addOnBlur: true, value: mainRSelected }),
                        !mainRValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "File must include a valid scheme prefix: 'file://', 'gs://', or 'hdfs://'"))),
                        mainRValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-message" }, _utils_const__WEBPACK_IMPORTED_MODULE_12__.QUERY_FILE_MESSAGE)))),
                    batchTypeSelected === 'pySpark' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-message" }, "Main python file*"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__.Input
                        //placeholder="Main R file*"
                        , { 
                            //placeholder="Main R file*"
                            className: "create-batch-style", onChange: e => handleValidationFiles(e.target.value, setMainPythonSelected, setMainPythonValidation), addOnBlur: true, value: mainPythonSelected }),
                        !mainPythonValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "File must include a valid scheme prefix: 'file://', 'gs://', or 'hdfs://'"))),
                        mainPythonValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-message" }, _utils_const__WEBPACK_IMPORTED_MODULE_12__.QUERY_FILE_MESSAGE)))),
                    batchTypeSelected === 'pySpark' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" }, "Additional python files"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_tagsinput__WEBPACK_IMPORTED_MODULE_5___default()), { className: "select-job-style", onChange: e => handleValidationFiles(e, setAdditionalPythonFileSelected, setAdditionalPythonFileValidation), addOnBlur: true, value: additionalPythonFileSelected, inputProps: { placeholder: '' } }),
                        !additionalPythonFileValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "All files must include a valid scheme prefix: 'file://', 'gs://', or 'hdfs://'"))))),
                    batchTypeSelected === 'sparkSql' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-message" }, "Query file*"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__.Input
                        //placeholder="Main R file*"
                        , { 
                            //placeholder="Main R file*"
                            className: "create-batch-style", onChange: e => handleValidationFiles(e.target.value, setQueryFileSelected, setQueryFileValidation), addOnBlur: true, value: queryFileSelected }),
                        !queryFileValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "File must include a valid scheme prefix: 'file://', 'gs://', or 'hdfs://'"))),
                        queryFileValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-messagelist" }, _utils_const__WEBPACK_IMPORTED_MODULE_12__.QUERY_FILE_MESSAGE)))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" }, "Custom container image"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__.Input, { className: "create-batch-style ", value: containerImageSelected, onChange: e => setContainerImageSelected(e.target.value), type: "text", placeholder: "" }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-custom-messagelist" },
                        _utils_const__WEBPACK_IMPORTED_MODULE_12__.CUSTOM_CONTAINER_MESSAGE,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-container-message" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-learn-more", onClick: () => {
                                    window.open(`${_utils_const__WEBPACK_IMPORTED_MODULE_12__.CONTAINER_REGISTERY}`, '_blank');
                                } }, "Container Registry"),
                            ' or ',
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-learn-more", onClick: () => {
                                    window.open(`${_utils_const__WEBPACK_IMPORTED_MODULE_12__.ARTIFACT_REGISTERY}`, '_blank');
                                } }, "Artifact Registry"),
                            ' . ',
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-learn-more", onClick: () => {
                                    window.open(`${_utils_const__WEBPACK_IMPORTED_MODULE_12__.CUSTOM_CONTAINERS}`, '_blank');
                                } }, "Learn more"))),
                    batchTypeSelected === 'spark' ||
                        (batchTypeSelected === 'sparkSql' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" }, "Jar files"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_tagsinput__WEBPACK_IMPORTED_MODULE_5___default()), { className: "select-job-style", onChange: e => handleValidationFiles(e, setJarFilesSelected, setJarFileValidation), addOnBlur: true, value: jarFilesSelected, inputProps: { placeholder: '' } }),
                            !jarFileValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "All files must include a valid scheme prefix: 'file://', 'gs://', or 'hdfs://'"))),
                            jarFileValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-messagelist" }, _utils_const__WEBPACK_IMPORTED_MODULE_12__.JAR_FILE_MESSAGE))))),
                    batchTypeSelected !== 'sparkSql' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" }, "Files"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_tagsinput__WEBPACK_IMPORTED_MODULE_5___default()), { className: "select-job-style", onChange: e => handleValidationFiles(e, setFilesSelected, setFileValidation), addOnBlur: true, value: filesSelected, inputProps: { placeholder: '' } }),
                        !fileValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "All files must include a valid scheme prefix: 'file://', 'gs://', or 'hdfs://'"))),
                        fileValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-messagelist" }, _utils_const__WEBPACK_IMPORTED_MODULE_12__.FILES_MESSAGE)))),
                    batchTypeSelected !== 'sparkSql' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" }, "Archive files"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_tagsinput__WEBPACK_IMPORTED_MODULE_5___default()), { className: "select-job-style", onChange: e => handleValidationFiles(e, setArchiveFileSelected, setArchieveFileValidation), addOnBlur: true, value: ArchiveFilesSelected, inputProps: { placeholder: '' } }),
                        !archieveFileValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "All files must include a valid scheme prefix: 'file://', 'gs://', or 'hdfs://'"))),
                        archieveFileValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-messagelist" }, _utils_const__WEBPACK_IMPORTED_MODULE_12__.ARCHIVE_FILES_MESSAGE)))),
                    batchTypeSelected !== 'sparkSql' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" }, "Arguments"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_tagsinput__WEBPACK_IMPORTED_MODULE_5___default()), { className: "select-job-style", onChange: e => setArgumentsSelected(e), addOnBlur: true, value: argumentsSelected, inputProps: { placeholder: '' } }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-messagelist" }, _utils_const__WEBPACK_IMPORTED_MODULE_12__.ARGUMENTS_MESSAGE))),
                    batchTypeSelected === 'sparkSql' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-label-header" }, "Query parameters"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_jobs_labelProperties__WEBPACK_IMPORTED_MODULE_13__["default"], { labelDetail: parameterDetail, setLabelDetail: setParameterDetail, labelDetailUpdated: parameterDetailUpdated, setLabelDetailUpdated: setParameterDetailUpdated, buttonText: "ADD PARAMETER", keyValidation: keyValidation, setKeyValidation: setKeyValidation, valueValidation: valueValidation, setvalueValidation: setvalueValidation, duplicateKeyError: duplicateKeyError, setDuplicateKeyError: setDuplicateKeyError }))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-label-header" }, "Execution Configuration"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" }, "Service account"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__.Input, { className: "create-batch-style ", value: serviceAccountSelected, onChange: e => setServiceAccountSelected(e.target.value), type: "text", placeholder: "" }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-messagelist" },
                        "If not provided, the default GCE service account will be used.",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-learn-more", onClick: () => {
                                window.open(`${_utils_const__WEBPACK_IMPORTED_MODULE_12__.SERVICE_ACCOUNT}`, '_blank');
                            } }, "Learn more")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-label-header" }, "Network Configuration"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" }, "Establishes connectivity for the VM instances in this cluster."),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" }, "Networks in this project"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-network" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-network-message" }, "Primary network*"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-network-message" }, "Subnetwork")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-network" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__.Select, { className: "select-primary-network-style", value: networkSelected, onChange: handleNetworkChange, type: "text", options: networkList }),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__.Select, { className: "select-sub-network-style", value: subNetworkSelected, onChange: handleSubNetworkChange, type: "text", options: [], placeholder: networkSelected }))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" }, "Network tags*"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_tagsinput__WEBPACK_IMPORTED_MODULE_5___default()), { className: "select-job-style", onChange: e => setNetworkTagSelected(e), addOnBlur: true, value: networkTagSelected, inputProps: { placeholder: '' } }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-label-header" }, "Encryption"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-radio" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-message" }, "Google-managed encryption key")),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-sub-message" }, "No configuration required"))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-label-header" }, "Peripheral Configuration"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" },
                        "Configure Dataproc to use Dataproc Metastore as its Hive metastore.",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-learn-more", onClick: () => {
                                window.open(`${_utils_const__WEBPACK_IMPORTED_MODULE_12__.SELF_MANAGED_CLUSTER}`, '_blank');
                            } }, "Learn more")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-messagelist" }, _utils_const__WEBPACK_IMPORTED_MODULE_12__.METASTORE_MESSAGE),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" }, "Metastore project"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__.Select, { placeholder: projectId, className: "select-job-style", value: projectId, onChange: handleProjectIdChange, options: projectList }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" }, "Metastore region"),
                    isLoadingRegion ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_spinners__WEBPACK_IMPORTED_MODULE_7__.ClipLoader, { loading: true, size: 25, "aria-label": "Loading Spinner", "data-testid": "loader" })) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__.Select, { placeholder: region, className: "select-job-style", value: region, onChange: handleRegionChange, options: regionList })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" }, "Metastore service"),
                    isLoadingService ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_spinners__WEBPACK_IMPORTED_MODULE_7__.ClipLoader, { loading: true, size: 25, "aria-label": "Loading Spinner", "data-testid": "loader" })) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__.Select, { className: "select-job-style", value: servicesSelected, type: "text", options: servicesList, onChange: handleServiceSelected })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-label-header" }, "History server cluster"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" },
                        "Choose a history server cluster to store logs in.",
                        ' '),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batches-message" }, "History server cluster"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_4__.Dropdown, { className: "select-job-style", search: true, selection: true, value: clusterSelected, onChange: handleClusterSelected, options: clustersList, placeholder: "Search..." }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-label-header" }, "Properties"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_jobs_labelProperties__WEBPACK_IMPORTED_MODULE_13__["default"], { labelDetail: propertyDetail, setLabelDetail: setPropertyDetail, labelDetailUpdated: propertyDetailUpdated, setLabelDetailUpdated: setPropertyDetailUpdated, buttonText: "ADD PROPERTY", keyValidation: keyValidation, setKeyValidation: setKeyValidation, valueValidation: valueValidation, setvalueValidation: setvalueValidation, duplicateKeyError: duplicateKeyError, setDuplicateKeyError: setDuplicateKeyError }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-label-header" }, "Labels"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_jobs_labelProperties__WEBPACK_IMPORTED_MODULE_13__["default"], { labelDetail: labelDetail, setLabelDetail: setLabelDetail, labelDetailUpdated: labelDetailUpdated, setLabelDetailUpdated: setLabelDetailUpdated, buttonText: "ADD LABEL", keyValidation: keyValidation, setKeyValidation: setKeyValidation, valueValidation: valueValidation, setvalueValidation: setvalueValidation, duplicateKeyError: duplicateKeyError, setDuplicateKeyError: setDuplicateKeyError }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "job-button-style-parent" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: isSubmitDisabled()
                                ? 'submit-button-disable-style'
                                : 'submit-button-style', "aria-label": "submit Batch" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { onClick: () => {
                                    if (!isSubmitDisabled()) {
                                        handleSubmit();
                                    }
                                } }, "SUBMIT")),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "job-cancel-button-style", "aria-label": "cancel Batch" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { onClick: () => handleCreateBatchBackView() }, "CANCEL")),
                        error.isOpen && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_errorPopup__WEBPACK_IMPORTED_MODULE_14__["default"], { onCancel: () => setError({ isOpen: false, message: '' }), errorPopupOpen: error.isOpen, DeleteMsg: error.message }))))))));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateBatch);


/***/ }),

/***/ "./lib/batches/listBatches.js":
/*!************************************!*\
  !*** ./lib/batches/listBatches.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_table__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-table */ "webpack/sharing/consume/default/react-table/react-table");
/* harmony import */ var react_table__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_table__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _style_icons_create_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../style/icons/create_cluster_icon.svg */ "./style/icons/create_cluster_icon.svg");
/* harmony import */ var _style_icons_filter_icon_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../style/icons/filter_icon.svg */ "./style/icons/filter_icon.svg");
/* harmony import */ var _style_icons_succeeded_icon_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../style/icons/succeeded_icon.svg */ "./style/icons/succeeded_icon.svg");
/* harmony import */ var _style_icons_cluster_running_icon_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../style/icons/cluster_running_icon.svg */ "./style/icons/cluster_running_icon.svg");
/* harmony import */ var _style_icons_cluster_error_icon_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../style/icons/cluster_error_icon.svg */ "./style/icons/cluster_error_icon.svg");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-spinners */ "webpack/sharing/consume/default/react-spinners/react-spinners");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_spinners__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_globalFilter__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../utils/globalFilter */ "./lib/utils/globalFilter.js");
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/* harmony import */ var _utils_tableData__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../utils/tableData */ "./lib/utils/tableData.js");
/* harmony import */ var _utils_paginationView__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../utils/paginationView */ "./lib/utils/paginationView.js");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */













const iconCreateCluster = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:create-cluster-icon',
    svgstr: _style_icons_create_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_4__
});
const iconFilter = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:filter-icon',
    svgstr: _style_icons_filter_icon_svg__WEBPACK_IMPORTED_MODULE_5__
});
const iconSucceeded = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:succeeded-icon',
    svgstr: _style_icons_succeeded_icon_svg__WEBPACK_IMPORTED_MODULE_6__
});
const iconClusterRunning = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:cluster-running-icon',
    svgstr: _style_icons_cluster_running_icon_svg__WEBPACK_IMPORTED_MODULE_7__
});
const iconClusterError = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:cluster-error-icon',
    svgstr: _style_icons_cluster_error_icon_svg__WEBPACK_IMPORTED_MODULE_8__
});
function ListBatches({ batchesList, isLoading, setPollingDisable, listBatchAPI, handleBatchDetails, setCreateBatchView, createBatchView }) {
    const data = batchesList;
    const columns = react__WEBPACK_IMPORTED_MODULE_0___default().useMemo(() => [
        {
            Header: 'Batch ID',
            accessor: 'batchID'
        },
        {
            Header: 'Status',
            accessor: 'status'
        },
        {
            Header: 'Location',
            accessor: 'location'
        },
        {
            Header: 'Creation time',
            accessor: 'creationTime'
        },
        {
            Header: 'Elapsed time',
            accessor: 'elapsedTime'
        },
        {
            Header: 'Type',
            accessor: 'type'
        },
        {
            Header: 'Actions',
            accessor: 'actions'
        }
    ], []);
    const { getTableProps, getTableBodyProps, headerGroups, rows, prepareRow, state, preGlobalFilteredRows, setGlobalFilter, page, canPreviousPage, canNextPage, nextPage, previousPage, setPageSize, state: { pageIndex, pageSize } } = (0,react_table__WEBPACK_IMPORTED_MODULE_1__.useTable)(
    //@ts-ignore react-table 'columns' which is declared here on type 'TableOptions<ICluster>'
    { columns, data, autoResetPage: false, initialState: { pageSize: 50 } }, react_table__WEBPACK_IMPORTED_MODULE_1__.useGlobalFilter, react_table__WEBPACK_IMPORTED_MODULE_1__.usePagination);
    const handleCreateBatchOpen = () => {
        setCreateBatchView(true);
    };
    const tableDataCondition = (cell) => {
        if (cell.column.Header === 'Batch ID') {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { role: "button", ...cell.getCellProps(), className: "cluster-name", onClick: () => handleBatchDetails(cell.value) }, cell.value));
        }
        else if (cell.column.Header === 'Status') {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { ...cell.getCellProps(), className: "clusters-table-data" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: "Status", className: "cluster-status-parent" },
                    cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_9__.STATUS_RUNNING && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconClusterRunning.react, { tag: "div" })),
                    cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_9__.STATUS_FAIL && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconClusterError.react, { tag: "div" }),
                    cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_9__.STATUS_SUCCESS && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconSucceeded.react, { tag: "div" }),
                    (cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_9__.STATUS_PROVISIONING ||
                        cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_9__.STATUS_CREATING ||
                        cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_9__.STATUS_PENDING ||
                        cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_9__.STATUS_DELETING) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_spinners__WEBPACK_IMPORTED_MODULE_3__.ClipLoader, { color: "#8A8A8A", loading: true, size: 15, "aria-label": "Loading Spinner", "data-testid": "loader" })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-status" }, cell.value && cell.value.toLowerCase()))));
        }
        else {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { ...cell.getCellProps(), className: "clusters-table-data" }, cell.render('Cell')));
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null, batchesList.length > 0 && !createBatchView ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "batch-header-part" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-batch-overlay", onClick: () => {
                    handleCreateBatchOpen();
                } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-cluster-icon" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconCreateCluster.react, { tag: "div" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-cluster-text" }, "Create Batch"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "filter-cluster-overlay" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "filter-cluster-icon" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconFilter.react, { tag: "div" })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "filter-cluster-text" }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "filter-cluster-section" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_globalFilter__WEBPACK_IMPORTED_MODULE_10__["default"], { preGlobalFilteredRows: preGlobalFilteredRows, globalFilter: state.globalFilter, setGlobalFilter: setGlobalFilter, setPollingDisable: setPollingDisable }))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "clusters-list-table-parent" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_tableData__WEBPACK_IMPORTED_MODULE_11__["default"], { getTableProps: getTableProps, headerGroups: headerGroups, getTableBodyProps: getTableBodyProps, isLoading: isLoading, rows: rows, page: page, prepareRow: prepareRow, tableDataCondition: tableDataCondition, fromPage: "Batches" }),
            batchesList.length > 50 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_paginationView__WEBPACK_IMPORTED_MODULE_12__.PaginationView, { pageSize: pageSize, setPageSize: setPageSize, pageIndex: pageIndex, allData: batchesList, previousPage: previousPage, nextPage: nextPage, canPreviousPage: canPreviousPage, canNextPage: canNextPage }))))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        isLoading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "spin-loaderMain" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_spinners__WEBPACK_IMPORTED_MODULE_3__.ClipLoader, { color: "#8A8A8A", loading: true, size: 18, "aria-label": "Loading Spinner", "data-testid": "loader" }),
            "Loading Batches")),
        !isLoading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "no-data-style" }, "No rows to display"))))));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ListBatches);


/***/ }),

/***/ "./lib/cluster/cluster.js":
/*!********************************!*\
  !*** ./lib/cluster/cluster.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Cluster: () => (/* binding */ Cluster)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jobs_jobs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../jobs/jobs */ "./lib/jobs/jobs.js");
/* harmony import */ var _clusterDetails__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./clusterDetails */ "./lib/cluster/clusterDetails.js");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../utils/utils */ "./lib/utils/utils.js");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _style_icons_start_icon_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../style/icons/start_icon.svg */ "./style/icons/start_icon.svg");
/* harmony import */ var _style_icons_stop_icon_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../style/icons/stop_icon.svg */ "./style/icons/stop_icon.svg");
/* harmony import */ var _style_icons_restart_icon_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../style/icons/restart_icon.svg */ "./style/icons/restart_icon.svg");
/* harmony import */ var _style_icons_start_icon_disable_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../style/icons/start_icon_disable.svg */ "./style/icons/start_icon_disable.svg");
/* harmony import */ var _style_icons_stop_icon_disable_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../style/icons/stop_icon_disable.svg */ "./style/icons/stop_icon_disable.svg");
/* harmony import */ var _style_icons_restart_icon_disable_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../style/icons/restart_icon_disable.svg */ "./style/icons/restart_icon_disable.svg");
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/* harmony import */ var _listCluster__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./listCluster */ "./lib/cluster/listCluster.js");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-spinners */ "webpack/sharing/consume/default/react-spinners/react-spinners");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_spinners__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-toastify */ "webpack/sharing/consume/default/react-toastify/react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/* harmony import */ var _utils_clusterServices__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../utils/clusterServices */ "./lib/utils/clusterServices.js");
/* harmony import */ var _utils_pollingTimer__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../utils/pollingTimer */ "./lib/utils/pollingTimer.js");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */



















const iconStart = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:start-icon',
    svgstr: _style_icons_start_icon_svg__WEBPACK_IMPORTED_MODULE_6__
});
const iconStop = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:stop-icon',
    svgstr: _style_icons_stop_icon_svg__WEBPACK_IMPORTED_MODULE_7__
});
const iconRestart = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:restart-icon',
    svgstr: _style_icons_restart_icon_svg__WEBPACK_IMPORTED_MODULE_8__
});
const iconStartDisable = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:start-disable-icon',
    svgstr: _style_icons_start_icon_disable_svg__WEBPACK_IMPORTED_MODULE_9__
});
const iconStopDisable = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:stop-disable-icon',
    svgstr: _style_icons_stop_icon_disable_svg__WEBPACK_IMPORTED_MODULE_10__
});
const iconRestartDisable = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:restart-disable-icon',
    svgstr: _style_icons_restart_icon_disable_svg__WEBPACK_IMPORTED_MODULE_11__
});
const ClusterComponent = () => {
    const [clustersList, setclustersList] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [clusterResponse, setClusterResponse] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [detailedJobView, setDetailedJobView] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [submitJobView, setSubmitJobView] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [restartEnabled, setRestartEnabled] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [selectedMode, setSelectedMode] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('Clusters');
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [clusterSelected, setClusterSelected] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const [pollingDisable, setPollingDisable] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [detailedView, setDetailedView] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [loggedIn, setLoggedIn] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [configError, setConfigError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [loginError, setLoginError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [configLoading, setConfigLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [projectId, setProjectId] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const timer = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(undefined);
    const [selectedJobClone, setSelectedJobClone] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const pollingClusters = async (pollingFunction, pollingDisable) => {
        timer.current = (0,_utils_pollingTimer__WEBPACK_IMPORTED_MODULE_12__["default"])(pollingFunction, pollingDisable, timer.current);
    };
    const selectedModeChange = (mode) => {
        setSelectedMode(mode);
    };
    const listClustersAPI = async (nextPageToken, previousClustersList) => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_13__.authApi)();
        const pageToken = nextPageToken !== null && nextPageToken !== void 0 ? nextPageToken : '';
        if (credentials) {
            setProjectId(credentials.project_id || '');
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_14__.BASE_URL}/projects/${credentials.project_id}/regions/${credentials.region_id}/clusters?pageSize=50&pageToken=${pageToken}`, {
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_14__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_14__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResult) => {
                    let transformClusterListData = [];
                    if (responseResult && responseResult.clusters) {
                        setClusterResponse(responseResult);
                        transformClusterListData = responseResult.clusters.map((data) => {
                            const statusVal = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_13__.statusValue)(data);
                            /*
                             Extracting zone from zoneUri
                              Example: "projects/{project}/zones/{zone}"
                          */
                            const zoneUri = data.config.gceClusterConfig.zoneUri.split('/');
                            return {
                                clusterUuid: data.clusterUuid,
                                status: statusVal,
                                clusterName: data.clusterName,
                                clusterImage: data.config.softwareConfig.imageVersion,
                                region: data.labels['goog-dataproc-location'],
                                zone: zoneUri[zoneUri.length - 1],
                                totalWorkersNode: data.config.workerConfig
                                    ? data.config.workerConfig.numInstances
                                    : 0,
                                schedulesDeletion: data.config.lifecycleConfig
                                    ? 'On'
                                    : 'Off',
                                actions: renderActions(data)
                            };
                        });
                    }
                    const existingClusterData = previousClustersList !== null && previousClustersList !== void 0 ? previousClustersList : [];
                    //setStateAction never type issue
                    const allClustersData = [
                        ...existingClusterData,
                        ...transformClusterListData
                    ];
                    if (responseResult.nextPageToken) {
                        listClustersAPI(responseResult.nextPageToken, allClustersData);
                    }
                    else {
                        setclustersList(allClustersData);
                        setIsLoading(false);
                        setLoggedIn(true);
                    }
                })
                    .catch((e) => {
                    console.log(e);
                    setIsLoading(false);
                });
            })
                .catch((err) => {
                setIsLoading(false);
                console.error('Error listing clusters', err);
                react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error('Failed to fetch clusters');
            });
        }
    };
    const handleClusterDetails = (selectedName) => {
        pollingClusters(listClustersAPI, true);
        setClusterSelected(selectedName);
        setDetailedView(true);
    };
    const statusApi = async (selectedcluster) => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_13__.authApi)();
        if (credentials) {
            await fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_14__.BASE_URL}/projects/${credentials.project_id}/regions/${credentials.region_id}/clusters/${selectedcluster}`, {
                method: 'GET',
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_14__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_14__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResult) => {
                    if (responseResult.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_14__.ClusterStatus.STATUS_STOPPED) {
                        (0,_utils_clusterServices__WEBPACK_IMPORTED_MODULE_15__.startClusterApi)(selectedcluster);
                        clearInterval(timer.current);
                    }
                })
                    .catch((e) => console.log(e));
            })
                .catch((err) => {
                console.error('Error fetching status', err);
                react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(`Failed to fetch the status ${selectedcluster}`);
            });
            listClustersAPI();
        }
    };
    const restartClusterApi = async (selectedcluster) => {
        setRestartEnabled(true);
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_13__.authApi)();
        if (credentials) {
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_14__.BASE_URL}/projects/${credentials.project_id}/regions/${credentials.region_id}/clusters/${selectedcluster}:stop`, {
                method: 'POST',
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_14__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_14__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResult) => {
                    console.log(responseResult);
                    listClustersAPI();
                    timer.current = setInterval(() => {
                        statusApi(selectedcluster);
                    }, _utils_const__WEBPACK_IMPORTED_MODULE_14__.POLLING_TIME_LIMIT);
                })
                    .catch((e) => console.log(e));
            })
                .catch((err) => {
                console.error('Error restarting cluster', err);
                react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(`Failed to restart the cluster ${selectedcluster}`);
            });
            listClustersAPI();
            setRestartEnabled(false);
        }
    };
    const startButton = (data) => {
        return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { role: "button", "aria-disabled": data.status.state !== _utils_const__WEBPACK_IMPORTED_MODULE_14__.ClusterStatus.STATUS_STOPPED &&
                restartEnabled !== true, className: data.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_14__.ClusterStatus.STATUS_STOPPED &&
                restartEnabled !== true
                ? 'icon-buttons-style'
                : 'icon-buttons-style-disable', title: "Start Cluster", onClick: data.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_14__.ClusterStatus.STATUS_STOPPED
                ? () => (0,_utils_clusterServices__WEBPACK_IMPORTED_MODULE_15__.startClusterApi)(data.clusterName)
                : undefined }, data.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_14__.ClusterStatus.STATUS_STOPPED ? (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(iconStart.react, { tag: "div" })) : (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(iconStartDisable.react, { tag: "div" }))));
    };
    const stopButton = (data) => {
        return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { role: "button", "aria-disabled": data.status.state !== _utils_const__WEBPACK_IMPORTED_MODULE_14__.ClusterStatus.STATUS_RUNNING, className: data.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_14__.ClusterStatus.STATUS_RUNNING
                ? 'icon-buttons-style'
                : 'icon-buttons-style-disable', title: "Stop Cluster", onClick: data.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_14__.ClusterStatus.STATUS_RUNNING
                ? () => (0,_utils_clusterServices__WEBPACK_IMPORTED_MODULE_15__.stopClusterApi)(data.clusterName)
                : undefined }, data.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_14__.ClusterStatus.STATUS_RUNNING ? (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(iconStop.react, { tag: "div" })) : (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(iconStopDisable.react, { tag: "div" }))));
    };
    const restartButton = (data) => {
        return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { role: "button", "aria-disabled": data.status.state !== _utils_const__WEBPACK_IMPORTED_MODULE_14__.ClusterStatus.STATUS_RUNNING, className: data.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_14__.ClusterStatus.STATUS_RUNNING
                ? 'icon-buttons-style'
                : 'icon-buttons-style-disable', title: "Restart Cluster", onClick: data.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_14__.ClusterStatus.STATUS_RUNNING
                ? () => restartClusterApi(data.clusterName)
                : undefined }, data.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_14__.ClusterStatus.STATUS_RUNNING ? (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(iconRestart.react, { tag: "div" })) : (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(iconRestartDisable.react, { tag: "div" }))));
    };
    const renderActions = (data) => {
        return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "actions-icon" },
            startButton(data),
            stopButton(data),
            restartButton(data)));
    };
    const toggleStyleSelection = (toggleItem) => {
        if (selectedMode === toggleItem) {
            return 'selected-header';
        }
        else {
            return 'unselected-header';
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        (0,_utils_utils__WEBPACK_IMPORTED_MODULE_13__.checkConfig)(setLoggedIn, setConfigError, setLoginError);
        const localstorageGetInformation = localStorage.getItem('loginState');
        setLoggedIn(localstorageGetInformation === _utils_const__WEBPACK_IMPORTED_MODULE_14__.LOGIN_STATE);
        if (loggedIn) {
            setConfigLoading(false);
        }
        listClustersAPI();
        if (!detailedView && selectedMode === 'Clusters') {
            pollingClusters(listClustersAPI, pollingDisable);
        }
        return () => {
            pollingClusters(listClustersAPI, true);
        };
    }, [pollingDisable, detailedView, selectedMode]);
    return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "component-level" },
        configLoading && !loggedIn && !configError && !loginError && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "spin-loaderMain" },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement(react_spinners__WEBPACK_IMPORTED_MODULE_3__.ClipLoader, { color: "#8A8A8A", loading: true, size: 18, "aria-label": "Loading Spinner", "data-testid": "loader" }),
            "Loading Clusters")),
        loggedIn && !configError ? (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
            detailedView && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_clusterDetails__WEBPACK_IMPORTED_MODULE_16__["default"], { clusterSelected: clusterSelected, setDetailedView: setDetailedView, detailedJobView: detailedJobView, setDetailedJobView: setDetailedJobView, submitJobView: submitJobView, clusterResponse: clusterResponse, selectedJobClone: selectedJobClone, setSelectedJobClone: setSelectedJobClone, setSubmitJobView: setSubmitJobView })),
            !detailedView && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "clusters-list-component", role: "tablist" },
                !detailedJobView && !submitJobView && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "clusters-list-overlay", role: "tab" },
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { role: "tabpanel", className: toggleStyleSelection('Clusters'), onClick: () => selectedModeChange('Clusters') }, "Clusters"),
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { role: "tabpanel", className: toggleStyleSelection('Jobs'), onClick: () => selectedModeChange('Jobs') }, "Jobs"))),
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", null, selectedMode === 'Jobs' ? (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_jobs_jobs__WEBPACK_IMPORTED_MODULE_17__["default"], { clustersList: clustersList, detailedJobView: detailedJobView, setDetailedJobView: setDetailedJobView, submitJobView: submitJobView, setSubmitJobView: setSubmitJobView, setDetailedView: setDetailedView, clusterResponse: clusterResponse, selectedJobClone: selectedJobClone, setSelectedJobClone: setSelectedJobClone })) : (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_listCluster__WEBPACK_IMPORTED_MODULE_18__["default"], { clustersList: clustersList, isLoading: isLoading, setPollingDisable: setPollingDisable, listClustersAPI: listClustersAPI, handleClusterDetails: handleClusterDetails, project_id: projectId }))),
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement(react_toastify__WEBPACK_IMPORTED_MODULE_4__.ToastContainer, null))))) : (loginError && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "login-error" }, "Please login to continue"))),
        configError && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "login-error" }, "Please configure gcloud with account, project-id and region"))));
};
class Cluster extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ReactWidget {
    constructor() {
        super();
    }
    render() {
        return react__WEBPACK_IMPORTED_MODULE_1___default().createElement(ClusterComponent, null);
    }
}


/***/ }),

/***/ "./lib/cluster/clusterDetails.js":
/*!***************************************!*\
  !*** ./lib/cluster/clusterDetails.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jobs_jobs__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../jobs/jobs */ "./lib/jobs/jobs.js");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _style_icons_left_arrow_icon_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../style/icons/left_arrow_icon.svg */ "./style/icons/left_arrow_icon.svg");
/* harmony import */ var _style_icons_start_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../style/icons/start_cluster_icon.svg */ "./style/icons/start_cluster_icon.svg");
/* harmony import */ var _style_icons_start_cluster_icon_disable_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../style/icons/start_cluster_icon_disable.svg */ "./style/icons/start_cluster_icon_disable.svg");
/* harmony import */ var _style_icons_stop_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../style/icons/stop_cluster_icon.svg */ "./style/icons/stop_cluster_icon.svg");
/* harmony import */ var _style_icons_stop_cluster_disable_icon_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../style/icons/stop_cluster_disable_icon.svg */ "./style/icons/stop_cluster_disable_icon.svg");
/* harmony import */ var _style_icons_delete_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../style/icons/delete_cluster_icon.svg */ "./style/icons/delete_cluster_icon.svg");
/* harmony import */ var _style_icons_error_icon_svg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../style/icons/error_icon.svg */ "./style/icons/error_icon.svg");
/* harmony import */ var _style_icons_cluster_running_icon_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../style/icons/cluster_running_icon.svg */ "./style/icons/cluster_running_icon.svg");
/* harmony import */ var _style_icons_cluster_error_icon_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../style/icons/cluster_error_icon.svg */ "./style/icons/cluster_error_icon.svg");
/* harmony import */ var _style_icons_stop_icon_svg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../style/icons/stop_icon.svg */ "./style/icons/stop_icon.svg");
/* harmony import */ var _utils_clusterServices__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../utils/clusterServices */ "./lib/utils/clusterServices.js");
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../utils/utils */ "./lib/utils/utils.js");
/* harmony import */ var react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! react-spinners/ClipLoader */ "./node_modules/react-spinners/ClipLoader.js");
/* harmony import */ var react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _utils_viewLogs__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../utils/viewLogs */ "./lib/utils/viewLogs.js");
/* harmony import */ var _utils_deletePopup__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../utils/deletePopup */ "./lib/utils/deletePopup.js");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-toastify */ "webpack/sharing/consume/default/react-toastify/react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/* harmony import */ var _jobs_submitJob__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../jobs/submitJob */ "./lib/jobs/submitJob.js");
/* harmony import */ var _utils_pollingTimer__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../utils/pollingTimer */ "./lib/utils/pollingTimer.js");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */























const iconLeftArrow = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:left-arrow-icon',
    svgstr: _style_icons_left_arrow_icon_svg__WEBPACK_IMPORTED_MODULE_4__
});
const iconStartCluster = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:start-cluster-icon',
    svgstr: _style_icons_start_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_5__
});
const iconStartClusterDisable = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:start-cluster-disable-icon',
    svgstr: _style_icons_start_cluster_icon_disable_svg__WEBPACK_IMPORTED_MODULE_6__
});
const iconStopCluster = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:stop-cluster-icon',
    svgstr: _style_icons_stop_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_7__
});
const iconStopClusterDisable = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:stop-cluster-disable-icon',
    svgstr: _style_icons_stop_cluster_disable_icon_svg__WEBPACK_IMPORTED_MODULE_8__
});
const iconDeleteCluster = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:delete-cluster-icon',
    svgstr: _style_icons_delete_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_9__
});
const iconClusterRunning = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:cluster-running-icon',
    svgstr: _style_icons_cluster_running_icon_svg__WEBPACK_IMPORTED_MODULE_10__
});
const iconClusterError = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:cluster-error-icon',
    svgstr: _style_icons_cluster_error_icon_svg__WEBPACK_IMPORTED_MODULE_11__
});
const iconStop = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:stop-icon',
    svgstr: _style_icons_stop_icon_svg__WEBPACK_IMPORTED_MODULE_12__
});
const iconError = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:error-icon',
    svgstr: _style_icons_error_icon_svg__WEBPACK_IMPORTED_MODULE_13__
});
function ClusterDetails({ clusterSelected, setDetailedView, setDetailedClusterView, detailedJobView, setSubmitJobView, setDetailedJobView, submitJobView, clusterResponse, selectedJobClone, setSelectedJobClone }) {
    const [clusterInfo, setClusterInfo] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        status: { state: '' },
        clusterName: '',
        clusterUuid: ''
    });
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [errorView, setErrorView] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [projectName, setProjectName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [deletePopupOpen, setDeletePopupOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [selectedCluster, setSelectedCluster] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const timer = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(undefined);
    const pollingClusterDetails = async (pollingFunction, pollingDisable) => {
        timer.current = (0,_utils_pollingTimer__WEBPACK_IMPORTED_MODULE_14__["default"])(pollingFunction, pollingDisable, timer.current);
    };
    const handleDetailedView = () => {
        pollingClusterDetails(getClusterDetails, true);
        setDetailedView(false);
        setDetailedClusterView === null || setDetailedClusterView === void 0 ? void 0 : setDetailedClusterView(false);
        setDetailedJobView === null || setDetailedJobView === void 0 ? void 0 : setDetailedJobView(false);
    };
    const handleDeleteCluster = (clustername) => {
        setSelectedCluster(clustername);
        setDeletePopupOpen(true);
    };
    const handleCancelDelete = () => {
        setDeletePopupOpen(false);
    };
    const handleDelete = async () => {
        await (0,_utils_clusterServices__WEBPACK_IMPORTED_MODULE_15__.deleteClusterApi)(selectedCluster);
        setDeletePopupOpen(false);
        handleDetailedView();
    };
    const getClusterDetails = async () => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_16__.authApi)();
        if (credentials) {
            setProjectName(credentials.project_id || '');
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_17__.BASE_URL}/projects/${credentials.project_id}/regions/${credentials.region_id}/clusters/${clusterSelected}`, {
                method: 'GET',
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_17__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_17__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResult) => {
                    if (responseResult.error && responseResult.error.code === 404) {
                        setErrorView(true);
                    }
                    setClusterInfo(responseResult);
                    setIsLoading(false);
                })
                    .catch((e) => {
                    console.log(e);
                    setIsLoading(false);
                });
            })
                .catch((err) => {
                setIsLoading(false);
                console.error('Error listing clusters Details', err);
                react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.error(`Failed to fetch cluster details ${clusterSelected}`);
            });
        }
    };
    const clusterDetailsAction = () => {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-action-parent" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", "aria-disabled": clusterInfo.status.state !== _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_STOPPED, className: clusterInfo.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_STOPPED
                    ? 'action-cluster-section'
                    : 'action-cluster-section disabled', onClick: () => clusterInfo.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_STOPPED &&
                    (0,_utils_clusterServices__WEBPACK_IMPORTED_MODULE_15__.startClusterApi)(clusterInfo.clusterName) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-icon", role: "button", "aria-disabled": clusterInfo.status.state !== _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_STOPPED }, clusterInfo.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_STOPPED ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconStartCluster.react, { tag: "div" })) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconStartClusterDisable.react, { tag: "div" }))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-text" }, "START")),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", "aria-disabled": clusterInfo.status.state !== _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_RUNNING, className: clusterInfo.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_RUNNING
                    ? 'action-cluster-section'
                    : 'action-cluster-section disabled', onClick: () => clusterInfo.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_RUNNING &&
                    (0,_utils_clusterServices__WEBPACK_IMPORTED_MODULE_15__.stopClusterApi)(clusterInfo.clusterName) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-icon" }, clusterInfo.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_RUNNING ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconStopCluster.react, { tag: "div" })) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconStopClusterDisable.react, { tag: "div" }))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-text" }, "STOP")),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: "action-cluster-section", onClick: () => handleDeleteCluster(clusterInfo.clusterName) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-icon" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconDeleteCluster.react, { tag: "div" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-text" }, "DELETE"))));
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        getClusterDetails();
        pollingClusterDetails(getClusterDetails, false);
        return () => {
            pollingClusterDetails(getClusterDetails, true);
        };
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        errorView && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-view-parent" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", "aria-label": "back-arrow-icon", className: "back-arrow-icon", onClick: () => handleDetailedView() },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconLeftArrow.react, { tag: "div" })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-view-message-parent" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "alert", className: "error-view-message" }, "Unable to find the resource you requested")))),
        submitJobView && !detailedJobView && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_jobs_submitJob__WEBPACK_IMPORTED_MODULE_18__["default"], { setSubmitJobView: setSubmitJobView, selectedJobClone: selectedJobClone, clusterResponse: clusterResponse })),
        deletePopupOpen && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_deletePopup__WEBPACK_IMPORTED_MODULE_19__["default"], { onCancel: () => handleCancelDelete(), onDelete: () => handleDelete(), deletePopupOpen: deletePopupOpen, DeleteMsg: 'This will delete ' + selectedCluster + ' and cannot be undone.' })),
        !submitJobView && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "scroll-comp" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_toastify__WEBPACK_IMPORTED_MODULE_2__.ToastContainer, null),
            !errorView && clusterInfo.clusterName !== '' ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                !detailedJobView && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-header" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", "aria-label": "back-arrow-icon", className: "back-arrow-icon", onClick: () => handleDetailedView() },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconLeftArrow.react, { tag: "div" })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-title" }, "Cluster details"),
                        clusterDetailsAction(),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_viewLogs__WEBPACK_IMPORTED_MODULE_20__["default"], { clusterInfo: clusterInfo, projectName: projectName })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-container" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Name"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, clusterInfo.clusterName)),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Cluster UUID"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, clusterInfo.clusterUuid)),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Type"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, "Dataproc Cluster")),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Status"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-detail-status-parent", "aria-status": clusterInfo.status.state, "aria-label": clusterInfo.status.state },
                                clusterInfo.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_RUNNING && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconClusterRunning.react, { tag: "div" })),
                                clusterInfo.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_STOPPED && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconStop.react, { tag: "div" })),
                                clusterInfo.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_ERROR && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconClusterError.react, { tag: "div" })),
                                (clusterInfo.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_PROVISIONING ||
                                    clusterInfo.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_CREATING ||
                                    clusterInfo.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_STARTING ||
                                    clusterInfo.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_STOPPING ||
                                    clusterInfo.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_DELETING) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_21___default()), { color: "#8A8A8A", loading: true, size: 15, "aria-label": "Loading Spinner", "data-testid": "loader" }))),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-status" }, clusterInfo.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_CREATING
                                    ? _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_PROVISIONING
                                    : clusterInfo.status.state.toLowerCase())))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-header" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-title" }, "Jobs")))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_jobs_jobs__WEBPACK_IMPORTED_MODULE_22__["default"], { clusterSelected: clusterSelected, setDetailedView: setDetailedView, detailedJobView: detailedJobView, setDetailedJobView: setDetailedJobView, setSubmitJobView: setSubmitJobView, setSelectedJobClone: setSelectedJobClone, clusterResponse: clusterResponse }))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "loader-full-style" }, isLoading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_21___default()), { color: "#8A8A8A", loading: true, size: 20, "aria-label": "Loading Spinner", "data-testid": "loader" }),
                "Loading Cluster Details"))))))));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ClusterDetails);


/***/ }),

/***/ "./lib/cluster/listCluster.js":
/*!************************************!*\
  !*** ./lib/cluster/listCluster.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_table__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-table */ "webpack/sharing/consume/default/react-table/react-table");
/* harmony import */ var react_table__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_table__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _style_icons_create_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../style/icons/create_cluster_icon.svg */ "./style/icons/create_cluster_icon.svg");
/* harmony import */ var _style_icons_filter_icon_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../style/icons/filter_icon.svg */ "./style/icons/filter_icon.svg");
/* harmony import */ var _style_icons_stop_icon_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../style/icons/stop_icon.svg */ "./style/icons/stop_icon.svg");
/* harmony import */ var _style_icons_cluster_running_icon_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../style/icons/cluster_running_icon.svg */ "./style/icons/cluster_running_icon.svg");
/* harmony import */ var _style_icons_cluster_error_icon_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../style/icons/cluster_error_icon.svg */ "./style/icons/cluster_error_icon.svg");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-spinners */ "webpack/sharing/consume/default/react-spinners/react-spinners");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_spinners__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/* harmony import */ var _utils_globalFilter__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../utils/globalFilter */ "./lib/utils/globalFilter.js");
/* harmony import */ var _utils_tableData__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../utils/tableData */ "./lib/utils/tableData.js");
/* harmony import */ var _utils_paginationView__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../utils/paginationView */ "./lib/utils/paginationView.js");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */













const iconCreateCluster = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:create-cluster-icon',
    svgstr: _style_icons_create_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_4__
});
const iconFilter = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:filter-icon',
    svgstr: _style_icons_filter_icon_svg__WEBPACK_IMPORTED_MODULE_5__
});
const iconStop = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:stop-icon',
    svgstr: _style_icons_stop_icon_svg__WEBPACK_IMPORTED_MODULE_6__
});
const iconClusterRunning = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:cluster-running-icon',
    svgstr: _style_icons_cluster_running_icon_svg__WEBPACK_IMPORTED_MODULE_7__
});
const iconClusterError = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:cluster-error-icon',
    svgstr: _style_icons_cluster_error_icon_svg__WEBPACK_IMPORTED_MODULE_8__
});
function ListCluster({ clustersList, isLoading, setPollingDisable, listClustersAPI, handleClusterDetails, project_id }) {
    const data = clustersList;
    const columns = react__WEBPACK_IMPORTED_MODULE_0___default().useMemo(() => [
        {
            Header: 'Name',
            accessor: 'clusterName'
        },
        {
            Header: 'Status',
            accessor: 'status'
        },
        {
            Header: 'Cluster image name',
            accessor: 'clusterImage'
        },
        {
            Header: 'Region',
            accessor: 'region'
        },
        {
            Header: 'Zone',
            accessor: 'zone'
        },
        {
            Header: 'Total worker nodes',
            accessor: 'totalWorkersNode'
        },
        {
            Header: 'Scheduled deletion',
            accessor: 'schedulesDeletion'
        },
        {
            Header: 'Actions',
            accessor: 'actions'
        }
    ], []);
    const tableDataCondition = (cell) => {
        if (cell.column.Header === 'Name') {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { ...cell.getCellProps(), role: "button", className: "cluster-name", onClick: () => cell.row.original.status !== _utils_const__WEBPACK_IMPORTED_MODULE_9__.STATUS_DELETING &&
                    handleClusterDetails(cell.value) }, cell.value));
        }
        else if (cell.column.Header === 'Status') {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { ...cell.getCellProps(), className: "clusters-table-data" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: "Status", className: "cluster-status-parent", role: "status", "aria-labels": cell.value },
                    cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_9__.STATUS_RUNNING && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconClusterRunning.react, { tag: "div" })),
                    cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_9__.STATUS_STOPPED && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconStop.react, { tag: "div" }),
                    cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_9__.STATUS_ERROR && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconClusterError.react, { tag: "div" })),
                    (cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_9__.STATUS_PROVISIONING ||
                        cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_9__.STATUS_CREATING ||
                        cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_9__.STATUS_STARTING ||
                        cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_9__.STATUS_STOPPING ||
                        cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_9__.STATUS_DELETING) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_spinners__WEBPACK_IMPORTED_MODULE_3__.ClipLoader, { color: "#8A8A8A", loading: true, size: 15, "aria-label": "Loading Spinner", "data-testid": "loader" })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-status" }, cell.value && cell.value.toLowerCase()))));
        }
        else {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { ...cell.getCellProps(), className: "clusters-table-data" }, cell.render('Cell')));
        }
    };
    const { getTableProps, getTableBodyProps, headerGroups, rows, prepareRow, state, preGlobalFilteredRows, setGlobalFilter, page, canPreviousPage, canNextPage, nextPage, previousPage, setPageSize, state: { pageIndex, pageSize } } = (0,react_table__WEBPACK_IMPORTED_MODULE_1__.useTable)(
    //@ts-ignore react-table 'columns' which is declared here on type 'TableOptions<ICluster>'
    { columns, data, autoResetPage: false, initialState: { pageSize: 50 } }, react_table__WEBPACK_IMPORTED_MODULE_1__.useGlobalFilter, react_table__WEBPACK_IMPORTED_MODULE_1__.usePagination);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-cluster-overlay" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: "create-cluster-sub-overlay", onClick: () => {
                    window.open(`${_utils_const__WEBPACK_IMPORTED_MODULE_9__.CREATE_CLUSTER_URL}?project=${project_id}`, '_blank');
                } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-cluster-icon" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconCreateCluster.react, { tag: "div" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-cluster-text" }, "Create cluster"))),
        clustersList.length > 0 ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "filter-cluster-overlay" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "filter-cluster-icon" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconFilter.react, { tag: "div" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "filter-cluster-text" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "filter-cluster-section" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_globalFilter__WEBPACK_IMPORTED_MODULE_10__["default"], { preGlobalFilteredRows: preGlobalFilteredRows, globalFilter: state.globalFilter, setGlobalFilter: setGlobalFilter, setPollingDisable: setPollingDisable }))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "clusters-list-table-parent" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_tableData__WEBPACK_IMPORTED_MODULE_11__["default"], { getTableProps: getTableProps, headerGroups: headerGroups, getTableBodyProps: getTableBodyProps, isLoading: isLoading, rows: rows, page: page, prepareRow: prepareRow, tableDataCondition: tableDataCondition, fromPage: "Clusters" }),
                clustersList.length > 50 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_paginationView__WEBPACK_IMPORTED_MODULE_12__.PaginationView, { pageSize: pageSize, setPageSize: setPageSize, pageIndex: pageIndex, allData: clustersList, previousPage: previousPage, nextPage: nextPage, canPreviousPage: canPreviousPage, canNextPage: canNextPage }))))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
            isLoading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "spin-loaderMain" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_spinners__WEBPACK_IMPORTED_MODULE_3__.ClipLoader, { color: "#8A8A8A", loading: true, size: 18, "aria-label": "Loading Spinner", "data-testid": "loader" }),
                "Loading Clusters")),
            !isLoading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "no-data-style" }, "No rows to display"))))));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ListCluster);


/***/ }),

/***/ "./lib/dpms/databaseInfo.js":
/*!**********************************!*\
  !*** ./lib/dpms/databaseInfo.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Database: () => (/* binding */ Database)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


const DatabaseInfo = ({ title, dataprocMetastoreServices, databaseDetails }) => {
    const database = {
        dname: title,
        description: databaseDetails[title],
        instanceName: dataprocMetastoreServices
    };
    const renderTable = () => {
        return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "table-container" },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("table", { className: "db-table" },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("tbody", null, Object.entries(database).map(([key, value], index) => (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("tr", { key: key, className: index % 2 === 0 ? 'tr-row-even' : 'tr-row-odd' },
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("td", { className: "bold-column" }, key),
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("td", null, value))))))));
    };
    return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "title-overlay" }, title),
        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "db-title" }, "Database info"),
        renderTable()));
};
class Database extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ReactWidget {
    constructor(title, dataprocMetastoreServices, databaseDetails) {
        super();
        this.title.label = title;
        this.dataprocMetastoreServices = dataprocMetastoreServices;
        this.databaseDetails = databaseDetails;
    }
    render() {
        return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(DatabaseInfo, { title: this.title.label, dataprocMetastoreServices: this.dataprocMetastoreServices, databaseDetails: this.databaseDetails }));
    }
}


/***/ }),

/***/ "./lib/dpms/dpmsWidget.js":
/*!********************************!*\
  !*** ./lib/dpms/dpmsWidget.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   dpmsWidget: () => (/* binding */ dpmsWidget)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_arborist__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-arborist */ "webpack/sharing/consume/default/react-arborist/react-arborist");
/* harmony import */ var react_arborist__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_arborist__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _style_icons_database_icon_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../style/icons/database_icon.svg */ "./style/icons/database_icon.svg");
/* harmony import */ var _style_icons_table_icon_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../style/icons/table_icon.svg */ "./style/icons/table_icon.svg");
/* harmony import */ var _style_icons_columns_icon_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../style/icons/columns_icon.svg */ "./style/icons/columns_icon.svg");
/* harmony import */ var _style_icons_refresh_icon_svg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../style/icons/refresh_icon.svg */ "./style/icons/refresh_icon.svg");
/* harmony import */ var _style_icons_database_widget_icon_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../style/icons/database_widget_icon.svg */ "./style/icons/database_widget_icon.svg");
/* harmony import */ var _style_icons_datasets_icon_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../style/icons/datasets_icon.svg */ "./style/icons/datasets_icon.svg");
/* harmony import */ var _style_icons_search_icon_svg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../style/icons/search_icon.svg */ "./style/icons/search_icon.svg");
/* harmony import */ var _style_icons_right_arrow_icon_svg__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../style/icons/right_arrow_icon.svg */ "./style/icons/right_arrow_icon.svg");
/* harmony import */ var _style_icons_down_arrow_icon_svg__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../style/icons/down_arrow_icon.svg */ "./style/icons/down_arrow_icon.svg");
/* harmony import */ var _databaseInfo__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./databaseInfo */ "./lib/dpms/databaseInfo.js");
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! uuid */ "./node_modules/uuid/dist/esm-browser/v4.js");
/* harmony import */ var semantic_ui_css_semantic_min_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! semantic-ui-css/semantic.min.css */ "./node_modules/semantic-ui-css/semantic.min.css");
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../utils/utils */ "./lib/utils/utils.js");
/* harmony import */ var _tableInfo__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./tableInfo */ "./lib/dpms/tableInfo.js");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-spinners */ "webpack/sharing/consume/default/react-spinners/react-spinners");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_spinners__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-toastify */ "webpack/sharing/consume/default/react-toastify/react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_6__);
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */






















const iconDatabase = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.LabIcon({
    name: 'launcher:database-icon',
    svgstr: _style_icons_database_icon_svg__WEBPACK_IMPORTED_MODULE_7__
});
const iconTable = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.LabIcon({
    name: 'launcher:table-icon',
    svgstr: _style_icons_table_icon_svg__WEBPACK_IMPORTED_MODULE_8__
});
const iconColumns = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.LabIcon({
    name: 'launcher:columns-icon',
    svgstr: _style_icons_columns_icon_svg__WEBPACK_IMPORTED_MODULE_9__
});
const iconDatasets = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.LabIcon({
    name: 'launcher:datasets-icon',
    svgstr: _style_icons_datasets_icon_svg__WEBPACK_IMPORTED_MODULE_10__
});
const iconDatabaseWidget = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.LabIcon({
    name: 'launcher:databse-widget-icon',
    svgstr: _style_icons_database_widget_icon_svg__WEBPACK_IMPORTED_MODULE_11__
});
const iconRefresh = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.LabIcon({
    name: 'launcher:refresh-icon',
    svgstr: _style_icons_refresh_icon_svg__WEBPACK_IMPORTED_MODULE_12__
});
const iconSearch = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.LabIcon({
    name: 'launcher:search-icon',
    svgstr: _style_icons_search_icon_svg__WEBPACK_IMPORTED_MODULE_13__
});
const iconRightArrow = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.LabIcon({
    name: 'launcher:right-arrow-icon',
    svgstr: _style_icons_right_arrow_icon_svg__WEBPACK_IMPORTED_MODULE_14__
});
const iconDownArrow = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.LabIcon({
    name: 'launcher:down-arrow-icon',
    svgstr: _style_icons_down_arrow_icon_svg__WEBPACK_IMPORTED_MODULE_15__
});
const calculateDepth = (node) => {
    let depth = 0;
    let currentNode = node;
    while (currentNode.parent) {
        depth++;
        currentNode = currentNode.parent;
    }
    return depth;
};
const DpmsComponent = ({ app }) => {
    const [searchTerm, setSearchTerm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const [clusterValue, setClusterValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const [dataprocMetastoreServices, setDataprocMetastoreServices] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [noCluster, setNoCluster] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [entries, setEntries] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [columnResponse, setColumnResponse] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [databaseDetails, setDatabaseDetails] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const [tableDescription, setTableDescription] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const getColumnDetails = async (name) => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_16__.authApi)();
        if (credentials && clusterValue) {
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_17__.COLUMN_API}${name}`, {
                method: 'GET',
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_17__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_17__.API_HEADER_BEARER + credentials.access_token,
                    'X-Goog-User-Project': credentials.project_id || ''
                }
            })
                .then((response) => {
                response
                    .json()
                    .then(async (responseResult) => {
                    setColumnResponse((prevResponse) => [
                        ...prevResponse,
                        responseResult
                    ]);
                    if (data) {
                        setIsLoading(false);
                    }
                })
                    .catch((e) => {
                    console.log(e);
                });
            })
                .catch((err) => {
                console.error('Error getting column details', err);
                react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast.error('Error getting column details');
            });
        }
    };
    const getTableDetails = async (database) => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_16__.authApi)();
        if (credentials && clusterValue) {
            const requestBody = {
                query: `${_utils_const__WEBPACK_IMPORTED_MODULE_17__.QUERY_TABLE}${credentials.project_id}.${credentials.region_id}.${dataprocMetastoreServices}.${database}`,
                scope: {
                    includeProjectIds: [credentials.project_id]
                }
            };
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_17__.CATALOG_SEARCH}`, {
                method: 'POST',
                body: JSON.stringify(requestBody),
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_17__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_17__.API_HEADER_BEARER + credentials.access_token,
                    'X-Goog-User-Project': credentials.project_id || ''
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResult) => {
                    const filteredEntries = responseResult.results.filter((entry) => entry.displayName);
                    const tableNames = [];
                    const entryNames = [];
                    const updatedTableDetails = {};
                    filteredEntries.forEach((entry) => {
                        tableNames.push(entry.displayName);
                        entryNames.push(entry.relativeResourceName);
                        const description = entry.description || 'None';
                        updatedTableDetails[entry.displayName] = description;
                    });
                    setEntries(entryNames);
                    setTableDescription(updatedTableDetails);
                })
                    .catch((e) => {
                    console.log(e);
                });
            })
                .catch((err) => {
                console.error('Error getting table details', err);
                react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast.error('Error getting table details');
            });
        }
    };
    const database = {};
    columnResponse.forEach((res) => {
        /* fullyQualifiedName : dataproc_metastore:projectId.location.metastore_instance.database_name.table_name
        fetching database name from fully qualified name structure */
        const dbName = res.fullyQualifiedName.split('.').slice(-2, -1)[0];
        const tableName = res.displayName;
        const columns = res.schema.columns.map((column) => ({
            name: column.column,
            type: column.type.toUpperCase(),
            mode: column.mode,
            description: (column === null || column === void 0 ? void 0 : column.description) || 'None'
        }));
        if (!database[dbName]) {
            database[dbName] = {};
        }
        if (!database[dbName][tableName]) {
            database[dbName][tableName] = [];
        }
        database[dbName][tableName].push(...columns);
    });
    const data = Object.entries(database).map(([dbName, tables]) => ({
        id: (0,uuid__WEBPACK_IMPORTED_MODULE_18__["default"])(),
        name: dbName,
        children: Object.entries(tables).map(([tableName, columns]) => ({
            id: (0,uuid__WEBPACK_IMPORTED_MODULE_18__["default"])(),
            name: tableName,
            desciption: '',
            children: columns.map((column) => ({
                id: (0,uuid__WEBPACK_IMPORTED_MODULE_18__["default"])(),
                name: column.name,
                type: column.type,
                mode: column.mode,
                description: column.description
            }))
        }))
    }));
    const handleSearch = (event) => {
        setSearchTerm(event.target.value);
    };
    const searchMatch = (node, term) => {
        return node.data.name.toLowerCase().includes(term.toLowerCase());
    };
    const handleNodeClick = (node) => {
        const depth = calculateDepth(node);
        if (depth === 1) {
            const content = new _databaseInfo__WEBPACK_IMPORTED_MODULE_19__.Database(node.data.name, dataprocMetastoreServices, databaseDetails);
            const widget = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.MainAreaWidget({ content });
            const widgetId = `node-widget-${(0,uuid__WEBPACK_IMPORTED_MODULE_18__["default"])()}`;
            widget.id = widgetId;
            widget.title.label = node.data.name;
            widget.title.closable = true;
            widget.title.icon = iconDatabaseWidget;
            app.shell.add(widget, 'main');
        }
        else if (depth === 2) {
            const database = node.parent.data.name;
            const column = node.data.children;
            const content = new _tableInfo__WEBPACK_IMPORTED_MODULE_20__.Table(node.data.name, dataprocMetastoreServices, database, column, tableDescription);
            const widget = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.MainAreaWidget({ content });
            const widgetId = `node-widget-${(0,uuid__WEBPACK_IMPORTED_MODULE_18__["default"])()}`;
            widget.id = widgetId;
            widget.title.label = node.data.name;
            widget.title.closable = true;
            widget.title.icon = iconDatasets;
            app.shell.add(widget, 'main');
        }
    };
    const clearState = () => {
        setSearchTerm('');
        setClusterValue('');
        setDataprocMetastoreServices('');
        setIsLoading(true);
        setEntries([]);
        setColumnResponse([]);
        setDatabaseDetails({});
    };
    const handleRefreshClick = () => {
        clearState();
        setIsLoading(true);
        getActiveNotebook();
    };
    function Node({ node, style, dragHandle, onClick }) {
        const [expanded, setExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
        const handleToggle = () => {
            setExpanded(!expanded);
            node.toggle();
        };
        const handleIconClick = (event) => {
            if (event.currentTarget.classList.contains('caret-icon')) {
                handleToggle();
            }
        };
        const handleTextClick = (event) => {
            event.stopPropagation();
            onClick(node);
        };
        const renderNodeIcon = () => {
            const depth = calculateDepth(node);
            const hasChildren = node.children && node.children.length > 0;
            const arrowIcon = hasChildren ? (expanded ? (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { role: "treeitem", className: "caret-icon right", onClick: handleIconClick },
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement(iconDownArrow.react, { tag: "div" })))) : (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { role: "treeitem", className: "caret-icon down", onClick: handleIconClick },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement(iconRightArrow.react, { tag: "div" })))) : null;
            if (depth === 1) {
                return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
                    arrowIcon,
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { role: "img", className: "db-icon", onClick: handleIconClick },
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(iconDatabase.react, { tag: "div" }))));
            }
            else if (depth === 2) {
                return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
                    arrowIcon,
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { role: "img", className: "table-icon", onClick: handleIconClick },
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement(iconTable.react, { tag: "div" }))));
            }
            return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
                arrowIcon,
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement(iconColumns.react, { tag: "div" })));
        };
        return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { style: style },
            renderNodeIcon(),
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { role: "treeitem", onClick: handleTextClick }, node.data.name)));
    }
    const getDatabaseDetails = async () => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_16__.authApi)();
        if (credentials && clusterValue) {
            const requestBody = {
                query: `${_utils_const__WEBPACK_IMPORTED_MODULE_17__.QUERY_DATABASE}${credentials.project_id}.${credentials.region_id}.${dataprocMetastoreServices}`,
                scope: {
                    includeProjectIds: [credentials.project_id]
                }
            };
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_17__.CATALOG_SEARCH}`, {
                method: 'POST',
                body: JSON.stringify(requestBody),
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_17__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_17__.API_HEADER_BEARER + credentials.access_token,
                    'X-Goog-User-Project': credentials.project_id || ''
                }
            })
                .then((response) => {
                response
                    .json()
                    .then(async (responseResult) => {
                    const filteredEntries = responseResult.results.filter((entry) => entry.displayName);
                    const databaseNames = [];
                    const updatedDatabaseDetails = {};
                    filteredEntries.forEach((entry) => {
                        databaseNames.push(entry.displayName);
                        const description = entry.description || 'None';
                        updatedDatabaseDetails[entry.displayName] = description;
                    });
                    setDatabaseDetails(updatedDatabaseDetails);
                    databaseNames.map(async (db) => {
                        await getTableDetails(db);
                    });
                })
                    .catch((e) => {
                    console.log(e);
                });
            })
                .catch((err) => {
                console.error('Error getting database details', err);
                react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast.error('Error getting database details');
            });
        }
    };
    const getClusterDetails = async () => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_16__.authApi)();
        if (credentials && clusterValue) {
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_17__.BASE_URL}/projects/${credentials.project_id}/regions/${credentials.region_id}/clusters/${clusterValue}`, {
                method: 'GET',
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_17__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_17__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then(async (responseResult) => {
                    var _a, _b;
                    const metastoreServices = (_b = (_a = responseResult.config) === null || _a === void 0 ? void 0 : _a.metastoreConfig) === null || _b === void 0 ? void 0 : _b.dataprocMetastoreService;
                    if (metastoreServices) {
                        const lastIndex = metastoreServices.lastIndexOf('/');
                        const instanceName = lastIndex !== -1
                            ? metastoreServices.substring(lastIndex + 1)
                            : '';
                        setDataprocMetastoreServices(instanceName);
                        setNoCluster(false);
                    }
                    else {
                        setNoCluster(true);
                    }
                })
                    .catch((e) => {
                    console.log(e);
                });
            })
                .catch((err) => {
                setIsLoading(false);
                console.error('Error listing clusters details', err);
                react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast.error('Failed to fetch cluster details');
            });
        }
    };
    const getActiveNotebook = () => {
        const clusterVal = localStorage.getItem('clusterValue');
        if (clusterVal) {
            setClusterValue(clusterVal);
            getClusterDetails();
        }
        else {
            setNoCluster(true);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        getActiveNotebook();
        return () => {
            setClusterValue('');
        };
    }, [clusterValue]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        getDatabaseDetails();
    }, [dataprocMetastoreServices]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        entries.forEach(async (entry) => {
            await getColumnDetails(entry);
        });
    }, [entries]);
    return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "dpms-title" }, "Dataproc Metastore"),
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { role: "button", "aria-label": "refresh", className: "refresh-icon", "data-tip": "Refresh", onClick: handleRefreshClick },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement(iconRefresh.react, { tag: "div" }))),
        !noCluster ? (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", null, isLoading ? (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "database-loader" },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement(react_spinners__WEBPACK_IMPORTED_MODULE_5__.ClipLoader, { color: "#8A8A8A", loading: true, size: 20, "aria-label": "Loading Spinner", "data-testid": "loader" })),
                "Loading databases")) : (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "ui category search" },
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "ui icon input" },
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("input", { className: "search-field", type: "text", value: searchTerm, onChange: handleSearch }),
                        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "search-icon" },
                            react__WEBPACK_IMPORTED_MODULE_1___default().createElement(iconSearch.react, { tag: "div" })))),
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "tree-container" },
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement(react_arborist__WEBPACK_IMPORTED_MODULE_2__.Tree, { data: data, openByDefault: false, width: 600, height: 1000, indent: 24, rowHeight: 36, overscanCount: 1, paddingTop: 30, paddingBottom: 10, padding: 25, searchTerm: searchTerm, searchMatch: searchMatch }, (props) => (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(Node, { ...props, onClick: handleNodeClick }))),
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement(react_toastify__WEBPACK_IMPORTED_MODULE_6__.ToastContainer, null))))))) : (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "dpms-error" }, "Please select cluster notebook attached to metastore and refresh"))));
};
class dpmsWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ReactWidget {
    constructor(app) {
        super();
        this.app = app;
    }
    render() {
        return react__WEBPACK_IMPORTED_MODULE_1___default().createElement(DpmsComponent, { app: this.app });
    }
}


/***/ }),

/***/ "./lib/dpms/tableInfo.js":
/*!*******************************!*\
  !*** ./lib/dpms/tableInfo.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Table: () => (/* binding */ Table)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_table__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-table */ "webpack/sharing/consume/default/react-table/react-table");
/* harmony import */ var react_table__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_table__WEBPACK_IMPORTED_MODULE_2__);
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */



const TableInfo = ({ title, dataprocMetastoreServices, database, column, tableDescription }) => {
    const table = {
        'Table name': title,
        Description: tableDescription[title],
        'By column name': '',
        'By Database': database,
        'By Dataproc Metastore Instance': dataprocMetastoreServices
    };
    const renderColumnTable = () => {
        const columns = react__WEBPACK_IMPORTED_MODULE_0___default().useMemo(() => [
            {
                Header: 'Field name',
                accessor: 'name'
            },
            {
                Header: 'Type',
                accessor: 'type'
            },
            {
                Header: 'Mode',
                accessor: 'mode'
            },
            {
                Header: 'Description',
                accessor: 'description'
            }
        ], []);
        const data = react__WEBPACK_IMPORTED_MODULE_0___default().useMemo(() => {
            return column.map((column) => ({
                name: column.name,
                type: column.type || '',
                mode: column.mode || '',
                description: column.description
            }));
        }, [column]);
        const { getTableProps, getTableBodyProps, headerGroups, rows, prepareRow } = 
        // @ts-ignore  react-table 'columns' which is declared here on type 'TableOptions<IColumns>'
        (0,react_table__WEBPACK_IMPORTED_MODULE_2__.useTable)({ columns, data });
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "table-container" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("table", { className: "schema-table", ...getTableProps() },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("thead", null, headerGroups.map(headerGroup => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tr", { ...headerGroup.getHeaderGroupProps() }, headerGroup.headers.map(column => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", { ...column.getHeaderProps() }, column.render('Header')))))))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tbody", { ...getTableBodyProps() }, rows.map(row => {
                    prepareRow(row);
                    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tr", { ...row.getRowProps() }, row.cells.map((cell, index) => {
                        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { className: index === 0 ? 'bold-column' : '', ...cell.getCellProps() }, cell.render('Cell')));
                    })));
                })))));
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "table-info-overlay" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "title-overlay" }, title),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "db-title" }, "Table info"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "table-container" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("table", { className: "db-table" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tbody", null, Object.entries(table).map(([key, value], index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tr", { key: key, className: index % 2 === 0 ? 'tr-row-even' : 'tr-row-odd' },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { className: "bold-column" }, key),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", null, value))))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "db-title" }, "Schema"),
        renderColumnTable()));
};
class Table extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    constructor(title, dataprocMetastoreServices, database, column, tableDescription) {
        super();
        this.dataprocMetastoreServices = dataprocMetastoreServices;
        this.database = database;
        this.column = column;
        this.tableDescription = tableDescription;
    }
    render() {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(TableInfo, { title: this.title.label, dataprocMetastoreServices: this.dataprocMetastoreServices, database: this.database, column: this.column, tableDescription: this.tableDescription }));
    }
}


/***/ }),

/***/ "./lib/handler/handler.js":
/*!********************************!*\
  !*** ./lib/handler/handler.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   requestAPI: () => (/* binding */ requestAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


/**
 * Call the API extension
 *
 * @param endPoint API REST end point for the extension
 * @param init Initial values for the request
 * @returns The response body interpreted as JSON
 */
async function requestAPI(endPoint = '', init = {}) {
    // Make request to Jupyter API
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'dataproc-plugin', endPoint);
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, init, settings);
    }
    catch (error) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
    }
    let data = await response.text();
    if (data.length > 0) {
        try {
            data = JSON.parse(data);
        }
        catch (error) {
            console.log('Not a JSON response body.', response);
        }
    }
    if (!response.ok) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, data.message);
    }
    return data;
}


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/mainmenu */ "webpack/sharing/consume/default/@jupyterlab/mainmenu");
/* harmony import */ var _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _cluster_cluster__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./cluster/cluster */ "./lib/cluster/cluster.js");
/* harmony import */ var _batches_batches__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./batches/batches */ "./lib/batches/batches.js");
/* harmony import */ var _style_icons_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../style/icons/cluster_icon.svg */ "./style/icons/cluster_icon.svg");
/* harmony import */ var _style_icons_serverless_icon_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../style/icons/serverless_icon.svg */ "./style/icons/serverless_icon.svg");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _login_authLogin__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./login/authLogin */ "./lib/login/authLogin.js");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./utils/utils */ "./lib/utils/utils.js");
/* harmony import */ var _dpms_dpmsWidget__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./dpms/dpmsWidget */ "./lib/dpms/dpmsWidget.js");
/* harmony import */ var _style_icons_dpms_icon_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../style/icons/dpms_icon.svg */ "./style/icons/dpms_icon.svg");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./utils/const */ "./lib/utils/const.js");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
















const iconDpms = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.LabIcon({
    name: 'launcher:dpms-icon',
    svgstr: _style_icons_dpms_icon_svg__WEBPACK_IMPORTED_MODULE_8__
});

const extension = {
    id: 'cluster',
    autoStart: true,
    optional: [_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_2__.ILauncher, _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_4__.IMainMenu, _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.ILabShell, _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_7__.INotebookTracker],
    activate: async (app, launcher, mainMenu, labShell, notebookTracker) => {
        const { commands } = app;
        const iconCluster = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.LabIcon({
            name: 'launcher:clusters-icon',
            svgstr: _style_icons_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_9__
        });
        const iconServerless = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.LabIcon({
            name: 'launcher:serverless-icon',
            svgstr: _style_icons_serverless_icon_svg__WEBPACK_IMPORTED_MODULE_10__
        });
        window.addEventListener('beforeunload', () => {
            localStorage.removeItem('clusterValue');
        });
        const onTitleChanged = async (title) => {
            var _a;
            const widget = title.owner;
            if (widget && widget instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_7__.NotebookPanel) {
                const kernel = (_a = widget.sessionContext.session) === null || _a === void 0 ? void 0 : _a.kernel;
                if (kernel) {
                    const kernelName = kernel.name;
                    const kernelSpec = kernels[kernelName];
                    if (kernelSpec === null || kernelSpec === void 0 ? void 0 : kernelSpec.resources.endpointParentResource.includes('/clusters/')) {
                        const parts = kernelSpec === null || kernelSpec === void 0 ? void 0 : kernelSpec.resources.endpointParentResource.split('/');
                        const clusterValue = parts[parts.length - 1];
                        localStorage.setItem('clusterValue', clusterValue);
                    }
                }
                else {
                    localStorage.removeItem('clusterValue');
                }
                document.title = title.label;
            }
            else {
                document.title = title.label;
            }
            console.log(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_6__.Kernel);
        };
        labShell.currentChanged.connect((_, change) => {
            const { oldValue, newValue } = change;
            // Clean up after the old value if it exists,
            // listen for changes to the title of the activity
            if (oldValue) {
                // Check if the old value is an instance of NotebookPanel
                if (oldValue instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_7__.NotebookPanel) {
                    oldValue.title.changed.disconnect(onTitleChanged);
                }
            }
            if (newValue) {
                // Check if the new value is an instance of NotebookPanel
                if (newValue instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_7__.NotebookPanel) {
                    newValue.title.changed.connect(onTitleChanged);
                }
            }
        });
        const kernelSpecs = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_6__.KernelSpecAPI.getSpecs();
        const kernels = kernelSpecs.kernelspecs;
        const createClusterComponentCommand = 'create-cluster-component';
        commands.addCommand(createClusterComponentCommand, {
            caption: 'Create a new Cluster Component',
            label: 'Clusters',
            // @ts-ignore jupyter lab icon command issue
            icon: args => (args['isPalette'] ? null : iconCluster),
            execute: () => {
                const content = new _cluster_cluster__WEBPACK_IMPORTED_MODULE_11__.Cluster();
                const widget = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.MainAreaWidget({ content });
                widget.title.label = 'Clusters';
                widget.title.icon = iconCluster;
                app.shell.add(widget, 'main');
            }
        });
        const createBatchesComponentCommand = 'create-batches-component';
        commands.addCommand(createBatchesComponentCommand, {
            caption: 'Create a new Serverless Component',
            label: 'Serverless',
            // @ts-ignore jupyter lab icon command issue
            icon: args => (args['isPalette'] ? null : iconServerless),
            execute: () => {
                const content = new _batches_batches__WEBPACK_IMPORTED_MODULE_12__.Batches();
                const widget = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.MainAreaWidget({ content });
                widget.title.label = 'Serverless';
                widget.title.icon = iconServerless;
                app.shell.add(widget, 'main');
            }
        });
        const createAuthLoginComponentCommand = 'create-authlogin-component';
        commands.addCommand(createAuthLoginComponentCommand, {
            label: 'Setup',
            caption: 'Setup',
            execute: () => {
                const content = new _login_authLogin__WEBPACK_IMPORTED_MODULE_13__.AuthLogin();
                const widget = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.MainAreaWidget({ content });
                widget.title.label = 'Config Setup';
                widget.title.icon = iconCluster;
                app.shell.add(widget, 'main');
            }
        });
        const snippetMenu = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__.Menu({ commands });
        snippetMenu.title.label = 'Dataproc';
        snippetMenu.addItem({ command: createAuthLoginComponentCommand });
        mainMenu.addMenu(snippetMenu);
        if (launcher) {
            Object.values(kernels).forEach((kernelsData, index) => {
                if ((kernelsData === null || kernelsData === void 0 ? void 0 : kernelsData.resources.endpointParentResource) &&
                    (kernelsData === null || kernelsData === void 0 ? void 0 : kernelsData.resources.endpointParentResource.includes('/sessions'))) {
                    const commandNotebook = `notebook:create-${kernelsData === null || kernelsData === void 0 ? void 0 : kernelsData.display_name}`;
                    commands.addCommand(commandNotebook, {
                        caption: kernelsData === null || kernelsData === void 0 ? void 0 : kernelsData.display_name,
                        label: kernelsData === null || kernelsData === void 0 ? void 0 : kernelsData.display_name,
                        icon: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_14__.iconDisplay)(kernelsData),
                        execute: async () => {
                            const model = await app.commands.execute('docmanager:new-untitled', {
                                type: 'notebook',
                                path: '',
                                kernel: { name: kernelsData === null || kernelsData === void 0 ? void 0 : kernelsData.name }
                            });
                            await app.commands.execute('docmanager:open', {
                                kernel: { name: kernelsData === null || kernelsData === void 0 ? void 0 : kernelsData.name },
                                path: model.path,
                                factory: 'notebook'
                            });
                        }
                    });
                    launcher.add({
                        command: commandNotebook,
                        category: 'Dataproc Serverless Notebooks',
                        //@ts-ignore jupyter lab Launcher type issue
                        metadata: kernelsData === null || kernelsData === void 0 ? void 0 : kernelsData.metadata,
                        rank: index + 1,
                        //@ts-ignore jupyter lab Launcher type issue
                        args: kernelsData === null || kernelsData === void 0 ? void 0 : kernelsData.argv
                    });
                }
            });
            Object.values(kernels).forEach((kernelsData, index) => {
                if ((kernelsData === null || kernelsData === void 0 ? void 0 : kernelsData.resources.endpointParentResource) &&
                    !(kernelsData === null || kernelsData === void 0 ? void 0 : kernelsData.resources.endpointParentResource.includes('/sessions'))) {
                    const commandNotebook = `notebook:create-${kernelsData === null || kernelsData === void 0 ? void 0 : kernelsData.display_name}`;
                    commands.addCommand(commandNotebook, {
                        caption: kernelsData === null || kernelsData === void 0 ? void 0 : kernelsData.display_name,
                        label: kernelsData === null || kernelsData === void 0 ? void 0 : kernelsData.display_name,
                        icon: (0,_utils_utils__WEBPACK_IMPORTED_MODULE_14__.iconDisplay)(kernelsData),
                        execute: async () => {
                            const model = await app.commands.execute('docmanager:new-untitled', {
                                type: 'notebook',
                                path: '',
                                kernel: { name: kernelsData === null || kernelsData === void 0 ? void 0 : kernelsData.name }
                            });
                            await app.commands.execute('docmanager:open', {
                                kernel: { name: kernelsData === null || kernelsData === void 0 ? void 0 : kernelsData.name },
                                path: model.path,
                                factory: 'notebook'
                            });
                        }
                    });
                    launcher.add({
                        command: commandNotebook,
                        category: 'Dataproc Cluster Notebooks',
                        //@ts-ignore jupyter lab Launcher type issue
                        metadata: kernelsData === null || kernelsData === void 0 ? void 0 : kernelsData.metadata,
                        rank: index + 1,
                        //@ts-ignore jupyter lab Launcher type issue
                        args: kernelsData === null || kernelsData === void 0 ? void 0 : kernelsData.argv
                    });
                }
            });
            const panel = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__.Panel();
            panel.id = 'dpms-tab';
            panel.title.icon = iconDpms; // svg import
            panel.addWidget(new _dpms_dpmsWidget__WEBPACK_IMPORTED_MODULE_15__.dpmsWidget(app));
            app.shell.add(panel, 'left');
            launcher.add({
                command: createClusterComponentCommand,
                category: _utils_const__WEBPACK_IMPORTED_MODULE_16__.TITLE_LAUNCHER_CATEGORY,
                rank: 1
            });
            launcher.add({
                command: createBatchesComponentCommand,
                category: _utils_const__WEBPACK_IMPORTED_MODULE_16__.TITLE_LAUNCHER_CATEGORY,
                rank: 2
            });
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extension);


/***/ }),

/***/ "./lib/jobs/jobDetails.js":
/*!********************************!*\
  !*** ./lib/jobs/jobDetails.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _style_icons_left_arrow_icon_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../style/icons/left_arrow_icon.svg */ "./style/icons/left_arrow_icon.svg");
/* harmony import */ var semantic_ui_css_semantic_min_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! semantic-ui-css/semantic.min.css */ "./node_modules/semantic-ui-css/semantic.min.css");
/* harmony import */ var _style_icons_clone_job_icon_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../style/icons/clone_job_icon.svg */ "./style/icons/clone_job_icon.svg");
/* harmony import */ var _style_icons_stop_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../style/icons/stop_cluster_icon.svg */ "./style/icons/stop_cluster_icon.svg");
/* harmony import */ var _style_icons_stop_cluster_disable_icon_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../style/icons/stop_cluster_disable_icon.svg */ "./style/icons/stop_cluster_disable_icon.svg");
/* harmony import */ var _style_icons_delete_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../style/icons/delete_cluster_icon.svg */ "./style/icons/delete_cluster_icon.svg");
/* harmony import */ var _style_icons_edit_icon_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../style/icons/edit_icon.svg */ "./style/icons/edit_icon.svg");
/* harmony import */ var _style_icons_edit_icon_disable_svg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../style/icons/edit_icon_disable.svg */ "./style/icons/edit_icon_disable.svg");
/* harmony import */ var _utils_deletePopup__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../utils/deletePopup */ "./lib/utils/deletePopup.js");
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../utils/utils */ "./lib/utils/utils.js");
/* harmony import */ var _cluster_clusterDetails__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../cluster/clusterDetails */ "./lib/cluster/clusterDetails.js");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-spinners */ "webpack/sharing/consume/default/react-spinners/react-spinners");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_spinners__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _labelProperties__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./labelProperties */ "./lib/jobs/labelProperties.js");
/* harmony import */ var _submitJob__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./submitJob */ "./lib/jobs/submitJob.js");
/* harmony import */ var _utils_viewLogs__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../utils/viewLogs */ "./lib/utils/viewLogs.js");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-toastify */ "webpack/sharing/consume/default/react-toastify/react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/* harmony import */ var _utils_statusDisplay__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../utils/statusDisplay */ "./lib/utils/statusDisplay.js");
/* harmony import */ var _utils_jobServices__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../utils/jobServices */ "./lib/utils/jobServices.js");
/* harmony import */ var _style_icons_error_icon_svg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../style/icons/error_icon.svg */ "./style/icons/error_icon.svg");
/* harmony import */ var _utils_pollingTimer__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../utils/pollingTimer */ "./lib/utils/pollingTimer.js");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
























const iconLeftArrow = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:left-arrow-icon',
    svgstr: _style_icons_left_arrow_icon_svg__WEBPACK_IMPORTED_MODULE_6__
});
const iconCloneJob = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:clone-job-icon',
    svgstr: _style_icons_clone_job_icon_svg__WEBPACK_IMPORTED_MODULE_7__
});
const iconStopClusterDisable = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:stop-cluster-disable-icon',
    svgstr: _style_icons_stop_cluster_disable_icon_svg__WEBPACK_IMPORTED_MODULE_8__
});
const iconStopCluster = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:stop-cluster-icon',
    svgstr: _style_icons_stop_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_9__
});
const iconDeleteCluster = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:delete-cluster-icon',
    svgstr: _style_icons_delete_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_10__
});
const iconEdit = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:edit-icon',
    svgstr: _style_icons_edit_icon_svg__WEBPACK_IMPORTED_MODULE_11__
});
const iconEditDisable = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:edit-disable-icon',
    svgstr: _style_icons_edit_icon_disable_svg__WEBPACK_IMPORTED_MODULE_12__
});
const iconError = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:error-icon',
    svgstr: _style_icons_error_icon_svg__WEBPACK_IMPORTED_MODULE_13__
});
function JobDetails({ jobSelected, setDetailedJobView, region, setDetailedView, clusterResponse, clustersList }) {
    const [jobInfo, setjobInfo] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        status: { state: '', stateStartTime: '' },
        statusHistory: [{ stateStartTime: '' }],
        labels: '',
        reference: { jobId: '' },
        jobUuid: '',
        pysparkJob: { args: [], mainPythonFileUri: '' },
        sparkRJob: { args: [], mainRFileUri: '' },
        sparkJob: { args: [], mainJarFileUri: '', mainClass: '', jarFileUris: '' },
        sparkSqlJob: { queryFileUri: '', queryList: { queries: '' }, args: [] },
        placement: { clusterName: '' }
    });
    const [jobInfoResponse, setjobInfoResponse] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        status: { state: '', stateStartTime: '' },
        statusHistory: [{ stateStartTime: '' }],
        labels: {},
        reference: { jobId: '' },
        jobUuid: '',
        pysparkJob: { args: [], mainPythonFileUri: '' },
        sparkRJob: { args: [], mainRFileUri: '' },
        sparkJob: { args: [], mainJarFileUri: '', mainClass: '' },
        sparkSqlJob: { queryFileUri: '', queryList: { queries: '' }, args: [] },
        placement: { clusterName: '' }
    });
    const key = [];
    const value = [];
    const [labelEditMode, setLabelEditMode] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [labelDetail, setLabelDetail] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(key); //Final label value is stored
    const [labelDetailUpdated, setLabelDetailUpdated] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(value); //temporary storage to validate the label data being typed
    const [detailedClusterView, setDetailedClusterView] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [selectedJobClone, setSelectedJobClone] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
    const [submitJobView, setSubmitJobView] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [keyValidation, setKeyValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(-1);
    const [valueValidation, setValueValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(-1);
    const [duplicateKeyError, setDuplicateKeyError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(-1);
    const [deletePopupOpen, setDeletePopupOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [selectedJobId, setSelectedJobId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const timer = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(undefined);
    const [errorView, setErrorView] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const pollingJobDetails = async (pollingFunction, pollingDisable) => {
        timer.current = (0,_utils_pollingTimer__WEBPACK_IMPORTED_MODULE_14__["default"])(pollingFunction, pollingDisable, timer.current);
    };
    const handleDetailedJobView = () => {
        pollingJobDetails(getJobDetails, true);
        setDetailedJobView(false);
    };
    const handleDetailedClusterView = () => {
        pollingJobDetails(getJobDetails, true);
        if (!clustersList) {
            setDetailedJobView(false);
        }
        setDetailedClusterView(true);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (labelEditMode) {
            pollingJobDetails(getJobDetails, true);
        }
        else {
            getJobDetails();
            pollingJobDetails(getJobDetails, false);
        }
        return () => {
            pollingJobDetails(getJobDetails, true);
        };
    }, [labelEditMode]);
    const handleJobLabelEdit = () => {
        setLabelEditMode(true);
        setLabelDetailUpdated(labelDetail);
    };
    const handleDeleteJob = (jobId) => {
        setSelectedJobId(jobId);
        setDeletePopupOpen(true);
    };
    const handleStopJob = async (jobId) => {
        setSelectedJobId(jobId);
        await (0,_utils_jobServices__WEBPACK_IMPORTED_MODULE_15__.stopJobApi)(selectedJobId);
    };
    const handleCancelDelete = () => {
        setDeletePopupOpen(false);
    };
    const handleDelete = async () => {
        await (0,_utils_jobServices__WEBPACK_IMPORTED_MODULE_15__.deleteJobApi)(selectedJobId);
        setDeletePopupOpen(false);
        handleDetailedJobView();
    };
    const updateJobDetails = async (payloadJob) => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_16__.authApi)();
        if (credentials) {
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_17__.BASE_URL}/projects/${credentials.project_id}/regions/${credentials.region_id}/jobs/${jobSelected}?updateMask=${_utils_const__WEBPACK_IMPORTED_MODULE_17__.LABEL_TEXT}`, {
                method: 'PATCH',
                body: JSON.stringify(payloadJob),
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_17__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_17__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResultJob) => {
                    react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.success(`Request to update job ${jobSelected} submitted`);
                    console.log(responseResultJob);
                })
                    .catch((e) => console.error(e));
            })
                .catch((err) => {
                console.error('Error in updating job', err);
                react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(`Failed to update the job ${jobSelected}`);
            });
        }
    };
    const handleSaveEdit = () => {
        const payload = jobInfoResponse;
        const labelObject = {};
        labelDetailUpdated.forEach((label) => {
            /*
               Extracting key, value from label
               Example: "{client:dataproc_plugin}"
            */
            const labelParts = label.split(':');
            const key = labelParts[0];
            const value = labelParts[1];
            labelObject[key] = value;
        });
        payload.labels = labelObject;
        updateJobDetails(payload);
        setLabelEditMode(false);
        getJobDetails();
    };
    const handleCancelEdit = () => {
        setLabelEditMode(false);
    };
    const getJobDetails = async () => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_16__.authApi)();
        if (credentials) {
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_17__.BASE_URL}/projects/${credentials.project_id}/regions/${credentials.region_id}/jobs/${jobSelected}`, {
                method: 'GET',
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_17__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_17__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResult) => {
                    setjobInfoResponse(responseResult);
                    const labelValue = [];
                    if (responseResult.labels) {
                        for (const [key, value] of Object.entries(responseResult.labels)) {
                            labelValue.push(`${key}:${value}`);
                        }
                    }
                    setjobInfo(responseResult);
                    setLabelDetail(labelValue);
                    setIsLoading(false);
                    setSelectedJobClone(responseResult);
                })
                    .catch((e) => {
                    console.error(e);
                    setIsLoading(false);
                });
            })
                .catch((err) => {
                setIsLoading(false);
                console.error('Error in getting job details', err);
                react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(`Failed to fetch job details ${jobSelected}`);
            });
        }
    };
    const startTime = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_16__.jobTimeFormat)(jobInfo.statusHistory[0].stateStartTime);
    const job = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_16__.jobTypeValue)(jobInfo);
    const jobType = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_16__.jobTypeDisplay)(job);
    const jobArgument = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_16__.jobTypeValueArguments)(jobInfo);
    const jobTypeConcat = jobArgument + 'Job';
    //@ts-ignore string used as index
    const argumentsList = jobInfo[jobTypeConcat].args;
    const statusMsg = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_16__.statusMessage)(jobInfo);
    const endTime = new Date(jobInfo.status.stateStartTime);
    const jobStartTime = new Date(jobInfo.statusHistory[jobInfo.statusHistory.length - 1].stateStartTime);
    const elapsedTimeString = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_16__.elapsedTime)(endTime, jobStartTime);
    const statusStyleSelection = (jobInfo) => {
        if (jobInfo.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_RUNNING) {
            return 'action-cluster-section'; //CSS class
        }
        else {
            return 'action-cluster-section disabled';
        }
    };
    const handleCloneJob = () => {
        setSubmitJobView(true);
    };
    const styleJobEdit = (labelEditMode) => {
        if (labelEditMode) {
            return 'job-edit-button-disabled';
        }
        else {
            return 'job-edit-button';
        }
    };
    const styleIconColor = (labelEditMode) => {
        if (labelEditMode) {
            return 'color-icon-disabled';
        }
        else {
            return 'color-icon';
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        errorView && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-view-parent" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: "back-arrow-icon", onClick: () => setErrorView(false) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconLeftArrow.react, { tag: "div" })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-view-message-parent" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-view-message" }, "Unable to find the resource you requested")))),
        submitJobView && !detailedClusterView && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_submitJob__WEBPACK_IMPORTED_MODULE_18__["default"], { setSubmitJobView: setSubmitJobView, selectedJobClone: selectedJobClone, clusterResponse: clusterResponse })),
        deletePopupOpen && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_deletePopup__WEBPACK_IMPORTED_MODULE_19__["default"], { onCancel: () => handleCancelDelete(), onDelete: () => handleDelete(), deletePopupOpen: deletePopupOpen, DeleteMsg: 'This will delete ' + selectedJobId + ' and cannot be undone.' })),
        detailedClusterView && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_cluster_clusterDetails__WEBPACK_IMPORTED_MODULE_20__["default"], { clusterSelected: jobInfo.placement.clusterName, setDetailedView: setDetailedView, setDetailedClusterView: setDetailedClusterView, submitJobView: submitJobView, selectedJobClone: selectedJobClone, clusterResponse: clusterResponse, setSubmitJobView: setSubmitJobView, setDetailedJobView: setDetailedJobView, setSelectedJobClone: setSelectedJobClone })),
        !submitJobView && !detailedClusterView && !errorView && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "scroll-comp" },
            jobInfo.jobUuid !== '' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-header" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "back-arrow-icon", role: "button", "aria-label": "Delete Job", onClick: () => handleDetailedJobView() },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconLeftArrow.react, { tag: "div" })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-title" }, "Job details"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: "action-cluster-section", onClick: () => handleCloneJob() },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-icon" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconCloneJob.react, { tag: "div" })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-text" }, "CLONE")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: statusStyleSelection(jobInfo), onClick: () => jobInfo.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_RUNNING &&
                            handleStopJob(jobInfo.reference.jobId) },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-icon" }, jobInfo.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_RUNNING ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconStopCluster.react, { tag: "div" })) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconStopClusterDisable.react, { tag: "div" }))),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-text" }, "STOP")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: "action-cluster-section", onClick: () => handleDeleteJob(jobInfo.reference.jobId) },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-icon" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconDeleteCluster.react, { tag: "div" })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-text" }, "DELETE")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_viewLogs__WEBPACK_IMPORTED_MODULE_21__["default"], { clusterName: jobInfo.placement.clusterName, setErrorView: setErrorView })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-container" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Job ID"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, jobInfo.reference.jobId)),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Job UUID"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, jobInfo.jobUuid)),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Type"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, "Dataproc Job")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Status"),
                        (0,_utils_statusDisplay__WEBPACK_IMPORTED_MODULE_22__.statusDisplay)(statusMsg)),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_toastify__WEBPACK_IMPORTED_MODULE_4__.ToastContainer, null)),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-header" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-title" }, "Configuration")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "job-edit-header" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: styleJobEdit(labelEditMode), onClick: () => (labelEditMode ? '' : handleJobLabelEdit()) },
                        labelEditMode ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconEditDisable.react, { tag: "div", className: styleIconColor(labelEditMode) })) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconEdit.react, { tag: "div", className: styleIconColor(labelEditMode) })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: labelEditMode ? 'job-edit-text-disabled' : 'job-edit-text' }, "EDIT"))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-container" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Start time:"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, startTime)),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Elapsed time:"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, elapsedTimeString)),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Status:"),
                        (0,_utils_statusDisplay__WEBPACK_IMPORTED_MODULE_22__.statusDisplay)(statusMsg)),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Region"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, region.region)),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Cluster"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: "cluster-details-value-job", onClick: () => handleDetailedClusterView() }, jobInfo.placement.clusterName)),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Job type"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, jobType)),
                    job === 'SparkR' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Spark R files"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, jobInfo.sparkRJob.mainRFileUri))),
                    job === 'SparkSQL' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Query source type"),
                        jobInfo.sparkSqlJob.queryFileUri ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, "Query file")) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, "Query script")))),
                    job === 'PySpark' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Main python file"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, jobInfo.pysparkJob.mainPythonFileUri))),
                    job === 'Spark' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Main class or jar"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" },
                                jobInfo.sparkJob.mainJarFileUri,
                                jobInfo.sparkJob.mainClass)),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Jar files"),
                            jobInfo.sparkJob.jarFileUris ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, jobInfo.sparkJob.jarFileUris)) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, "None"))))),
                    job === 'SparkSQL' && jobInfo.sparkSqlJob.queryFileUri && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Query file"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, jobInfo.sparkSqlJob.queryFileUri))),
                    job === 'SparkSQL' && jobInfo.sparkSqlJob.queryList && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Query script"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, jobInfo.sparkSqlJob.queryList.queries))),
                    argumentsList && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Arguments"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-value" }, argumentsList.length > 0
                            ? argumentsList.map((argument) => {
                                return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: argument, className: "job-argument-style" }, argument));
                            })
                            : ''))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "job-details-label-row" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Labels"),
                        !labelEditMode ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "job-label-style-parent" }, labelDetail.length > 0
                            ? labelDetail.map(label => {
                                /*
                                Extracting key, value from label
                                   Example: "{client:dataproc_plugin}"
                             */
                                const labelParts = label.split(':');
                                return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: label, className: "job-label-style" },
                                    labelParts[0],
                                    " : ",
                                    labelParts[1]));
                            })
                            : 'None')) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_labelProperties__WEBPACK_IMPORTED_MODULE_23__["default"], { labelDetail: labelDetail, setLabelDetail: setLabelDetail, labelDetailUpdated: labelDetailUpdated, setLabelDetailUpdated: setLabelDetailUpdated, selectedJobClone: !!selectedJobClone, buttonText: "ADD LABEL", keyValidation: keyValidation, setKeyValidation: setKeyValidation, valueValidation: valueValidation, setValueValidation: setValueValidation, labelEditMode: labelEditMode, duplicateKeyError: duplicateKeyError, setDuplicateKeyError: setDuplicateKeyError }))),
                    labelEditMode && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "job-button-style-parent" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "job-save-button-style" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", onClick: () => {
                                    handleSaveEdit();
                                } }, "SAVE")),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "job-cancel-button-style" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", onClick: () => {
                                    handleCancelEdit();
                                } }, "CANCEL"))))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_toastify__WEBPACK_IMPORTED_MODULE_4__.ToastContainer, null))),
            jobInfo.jobUuid === '' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "loader-full-style" }, isLoading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_spinners__WEBPACK_IMPORTED_MODULE_3__.ClipLoader, { color: "#8A8A8A", loading: true, size: 20, "aria-label": "Loading Spinner", "data-testid": "loader" }),
                "Loading Job Details"))))))));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (JobDetails);


/***/ }),

/***/ "./lib/jobs/jobs.js":
/*!**************************!*\
  !*** ./lib/jobs/jobs.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_table__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-table */ "webpack/sharing/consume/default/react-table/react-table");
/* harmony import */ var react_table__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_table__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../utils/utils */ "./lib/utils/utils.js");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _style_icons_filter_icon_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../style/icons/filter_icon.svg */ "./style/icons/filter_icon.svg");
/* harmony import */ var _style_icons_clone_icon_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../style/icons/clone_icon.svg */ "./style/icons/clone_icon.svg");
/* harmony import */ var _style_icons_stop_icon_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../style/icons/stop_icon.svg */ "./style/icons/stop_icon.svg");
/* harmony import */ var _jobDetails__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./jobDetails */ "./lib/jobs/jobDetails.js");
/* harmony import */ var _style_icons_stop_disable_icon_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../style/icons/stop_disable_icon.svg */ "./style/icons/stop_disable_icon.svg");
/* harmony import */ var _style_icons_delete_icon_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../style/icons/delete_icon.svg */ "./style/icons/delete_icon.svg");
/* harmony import */ var _style_icons_cluster_running_icon_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../style/icons/cluster_running_icon.svg */ "./style/icons/cluster_running_icon.svg");
/* harmony import */ var _style_icons_cluster_error_icon_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../style/icons/cluster_error_icon.svg */ "./style/icons/cluster_error_icon.svg");
/* harmony import */ var _style_icons_succeeded_icon_svg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../style/icons/succeeded_icon.svg */ "./style/icons/succeeded_icon.svg");
/* harmony import */ var _style_icons_submit_job_icon_svg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../style/icons/submit_job_icon.svg */ "./style/icons/submit_job_icon.svg");
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/* harmony import */ var react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! react-spinners/ClipLoader */ "./node_modules/react-spinners/ClipLoader.js");
/* harmony import */ var react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _submitJob__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./submitJob */ "./lib/jobs/submitJob.js");
/* harmony import */ var _utils_globalFilter__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../utils/globalFilter */ "./lib/utils/globalFilter.js");
/* harmony import */ var _utils_tableData__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../utils/tableData */ "./lib/utils/tableData.js");
/* harmony import */ var _utils_deletePopup__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../utils/deletePopup */ "./lib/utils/deletePopup.js");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-toastify */ "webpack/sharing/consume/default/react-toastify/react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/* harmony import */ var _utils_jobServices__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../utils/jobServices */ "./lib/utils/jobServices.js");
/* harmony import */ var _utils_paginationView__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ../utils/paginationView */ "./lib/utils/paginationView.js");
/* harmony import */ var _utils_pollingTimer__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../utils/pollingTimer */ "./lib/utils/pollingTimer.js");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

























const iconFilter = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:filter-icon',
    svgstr: _style_icons_filter_icon_svg__WEBPACK_IMPORTED_MODULE_5__
});
const iconClone = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:clone-icon',
    svgstr: _style_icons_clone_icon_svg__WEBPACK_IMPORTED_MODULE_6__
});
const iconStop = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:stop-icon',
    svgstr: _style_icons_stop_icon_svg__WEBPACK_IMPORTED_MODULE_7__
});
const iconStopDisable = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:stop-disable-icon',
    svgstr: _style_icons_stop_disable_icon_svg__WEBPACK_IMPORTED_MODULE_8__
});
const iconDelete = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:delete-icon',
    svgstr: _style_icons_delete_icon_svg__WEBPACK_IMPORTED_MODULE_9__
});
const iconClusterRunning = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:cluster-running-icon',
    svgstr: _style_icons_cluster_running_icon_svg__WEBPACK_IMPORTED_MODULE_10__
});
const iconClusterError = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:cluster-error-icon',
    svgstr: _style_icons_cluster_error_icon_svg__WEBPACK_IMPORTED_MODULE_11__
});
const iconSucceeded = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:succeeded-icon',
    svgstr: _style_icons_succeeded_icon_svg__WEBPACK_IMPORTED_MODULE_12__
});
const iconSubmitJob = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:submit-job-icon',
    svgstr: _style_icons_submit_job_icon_svg__WEBPACK_IMPORTED_MODULE_13__
});
function JobComponent({ clusterSelected, detailedJobView, setDetailedJobView, submitJobView, setSubmitJobView, setDetailedView, clusterResponse, selectedJobClone, setSelectedJobClone, clustersList }) {
    const [jobsList, setjobsList] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [jobSelected, setjobSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [pollingDisable, setPollingDisable] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [region, setRegion] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [deletePopupOpen, setDeletePopupOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [selectedJobId, setSelectedJobId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const timer = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(undefined);
    const pollingJobs = async (pollingFunction, pollingDisable) => {
        timer.current = (0,_utils_pollingTimer__WEBPACK_IMPORTED_MODULE_14__["default"])(pollingFunction, pollingDisable, timer.current);
    };
    const data = jobsList;
    const columns = react__WEBPACK_IMPORTED_MODULE_0___default().useMemo(() => [
        {
            Header: 'Job ID',
            accessor: 'jobid'
        },
        {
            Header: 'Status',
            accessor: 'status'
        },
        {
            Header: 'Region',
            accessor: 'region'
        },
        {
            Header: 'Type',
            accessor: 'type'
        },
        {
            Header: 'Start time',
            accessor: 'starttime'
        },
        {
            Header: 'Elapsed time',
            accessor: 'elapsedtime'
        },
        {
            Header: 'Labels',
            accessor: 'labels'
        },
        {
            Header: 'Actions',
            accessor: 'actions'
        }
    ], []);
    const jobDetails = (selectedName) => {
        pollingJobs(listJobsAPI, true);
        const filteredJobDetails = jobsList.filter((jobInfo) => {
            return jobInfo.jobid === selectedName;
        });
        const region = filteredJobDetails[0];
        setRegion(region);
        setjobSelected(selectedName);
        setDetailedJobView(true);
    };
    const handleSubmitJobOpen = () => {
        setSubmitJobView(true);
        setSelectedJobClone('');
    };
    const handleDeleteJob = (jobId) => {
        setSelectedJobId(jobId);
        setDeletePopupOpen(true);
    };
    const handleStopJob = async (jobId) => {
        setSelectedJobId(jobId);
        await (0,_utils_jobServices__WEBPACK_IMPORTED_MODULE_15__.stopJobApi)(jobId);
    };
    const handleCancelDelete = () => {
        setDeletePopupOpen(false);
    };
    const handleDelete = async () => {
        await (0,_utils_jobServices__WEBPACK_IMPORTED_MODULE_15__.deleteJobApi)(selectedJobId);
        setDeletePopupOpen(false);
    };
    const listJobsAPI = async (nextPageToken, previousJobsList) => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_16__.authApi)();
        const clusterName = clusterSelected !== null && clusterSelected !== void 0 ? clusterSelected : '';
        const pageToken = nextPageToken !== null && nextPageToken !== void 0 ? nextPageToken : '';
        if (credentials) {
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_17__.BASE_URL}/projects/${credentials.project_id}/regions/${credentials.region_id}/jobs?pageSize=50&pageToken=${pageToken}&&clusterName=${clusterName}`, {
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_17__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_17__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResult) => {
                    let transformJobListData = [];
                    if (responseResult && responseResult.jobs) {
                        transformJobListData = responseResult.jobs.map((data) => {
                            const startTime = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_16__.jobTimeFormat)(data.statusHistory[0].stateStartTime);
                            const job = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_16__.jobTypeValue)(data);
                            const jobType = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_16__.jobTypeDisplay)(job);
                            const endTime = data.status.stateStartTime;
                            const jobStartTime = new Date(data.statusHistory[0].stateStartTime);
                            const elapsedTimeString = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_16__.elapsedTime)(endTime, jobStartTime);
                            const statusMsg = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_16__.statusMessage)(data);
                            const labelvalue = [];
                            if (data.labels) {
                                for (const [key, value] of Object.entries(data.labels)) {
                                    labelvalue.push(`${key} : ${value}`);
                                }
                            }
                            else {
                                labelvalue.push('None');
                            }
                            return {
                                jobid: data.reference.jobId,
                                status: statusMsg,
                                region: credentials.region_id,
                                type: jobType,
                                starttime: startTime,
                                elapsedtime: elapsedTimeString,
                                labels: labelvalue,
                                actions: renderActions(data)
                            };
                        });
                    }
                    const existingJobsData = previousJobsList !== null && previousJobsList !== void 0 ? previousJobsList : [];
                    //setStateAction never type issue
                    let allJobsData = [
                        ...existingJobsData,
                        ...transformJobListData
                    ];
                    if (responseResult.nextPageToken) {
                        listJobsAPI(responseResult.nextPageToken, allJobsData);
                    }
                    else {
                        setjobsList(allJobsData);
                        setIsLoading(false);
                    }
                })
                    .catch((e) => {
                    console.error(e);
                    setIsLoading(false);
                });
            })
                .catch((err) => {
                setIsLoading(false);
                console.error('Error listing jobs', err);
                react_toastify__WEBPACK_IMPORTED_MODULE_3__.toast.error('Failed to fetch jobs');
            });
        }
    };
    const handleCloneJob = (data) => {
        setSubmitJobView(true);
        setSelectedJobClone(data);
    };
    const renderActions = (data) => {
        const jobId = data.reference.jobId;
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "actions-icon" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: "icon-buttons-style", title: "Clone Job", onClick: () => handleCloneJob(data) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconClone.react, { tag: "div" })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", "aria-disabled": data.status.state !== _utils_const__WEBPACK_IMPORTED_MODULE_17__.ClusterStatus.STATUS_RUNNING, className: data.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.ClusterStatus.STATUS_RUNNING
                    ? 'icon-buttons-style'
                    : 'icon-buttons-style-disable', title: "Stop Job", onClick: data.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.ClusterStatus.STATUS_RUNNING
                    ? () => handleStopJob(jobId)
                    : undefined }, data.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.ClusterStatus.STATUS_RUNNING ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconStop.react, { tag: "div" })) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconStopDisable.react, { tag: "div" }))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", "aria-disabled": data.status.state !== _utils_const__WEBPACK_IMPORTED_MODULE_17__.ClusterStatus.STATUS_RUNNING, className: data.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.ClusterStatus.STATUS_RUNNING
                    ? 'icon-buttons-style-disable'
                    : 'icon-buttons-style', title: "Delete Job", onClick: data.status.state !== _utils_const__WEBPACK_IMPORTED_MODULE_17__.ClusterStatus.STATUS_RUNNING
                    ? () => handleDeleteJob(jobId)
                    : undefined }, data.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_17__.ClusterStatus.STATUS_RUNNING ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconDelete.react, { tag: "div" })) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconDelete.react, { tag: "div" })))));
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        listJobsAPI();
        if (!detailedJobView) {
            pollingJobs(listJobsAPI, pollingDisable);
        }
        return () => {
            pollingJobs(listJobsAPI, true);
        };
    }, [pollingDisable, detailedJobView]);
    const tableDataCondition = (cell) => {
        if (cell.column.Header === 'Job ID') {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { role: "button", ...cell.getCellProps(), className: "cluster-name", onClick: () => jobDetails(cell.value) }, cell.value));
        }
        if (cell.column.Header === 'Status' && cell.value) {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { ...cell.getCellProps(), className: "clusters-table-data" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: "Status", className: "cluster-status-parent" },
                    cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_17__.ClusterStatus.STATUS_RUNNING && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconClusterRunning.react, { tag: "div" })),
                    cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_CANCELLED && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconStop.react, { tag: "div" }),
                    cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_FAIL && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconClusterError.react, { tag: "div" }),
                    cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_SUCCESS && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconSucceeded.react, { tag: "div" }),
                    (cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_PROVISIONING ||
                        cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_CREATING ||
                        cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_STARTING ||
                        cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_STOPPING ||
                        cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_17__.STATUS_DELETING) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_18___default()), { color: "#8A8A8A", loading: true, size: 15, "aria-label": "Loading Spinner", "data-testid": "loader" })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-status" }, cell.value.toLowerCase()))));
        }
        if (cell.column.Header === 'Labels') {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { ...cell.getCellProps(), className: "clusters-table-data" }, cell.value.map((label) => {
                return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: label, className: label !== 'None' ? 'job-label-style-list' : '' }, label));
            })));
        }
        else {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { ...cell.getCellProps(), className: "clusters-table-data" }, cell.render('Cell')));
        }
    };
    const { getTableProps, getTableBodyProps, headerGroups, rows, prepareRow, state, preGlobalFilteredRows, setGlobalFilter, page, canPreviousPage, canNextPage, nextPage, previousPage, setPageSize, state: { pageIndex, pageSize } } = (0,react_table__WEBPACK_IMPORTED_MODULE_1__.useTable)({ columns, data, autoResetPage: false, initialState: { pageSize: 50 } }, react_table__WEBPACK_IMPORTED_MODULE_1__.useGlobalFilter, react_table__WEBPACK_IMPORTED_MODULE_1__.usePagination);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_toastify__WEBPACK_IMPORTED_MODULE_3__.ToastContainer, null),
        submitJobView && !detailedJobView && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_submitJob__WEBPACK_IMPORTED_MODULE_19__["default"], { setSubmitJobView: setSubmitJobView, selectedJobClone: selectedJobClone, clusterResponse: clusterResponse })),
        deletePopupOpen && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_deletePopup__WEBPACK_IMPORTED_MODULE_20__["default"], { onCancel: () => handleCancelDelete(), onDelete: () => handleDelete(), deletePopupOpen: deletePopupOpen, DeleteMsg: 'This will delete ' + selectedJobId + ' and cannot be undone.' })),
        !submitJobView && detailedJobView && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_jobDetails__WEBPACK_IMPORTED_MODULE_21__["default"], { jobSelected: jobSelected, setDetailedJobView: setDetailedJobView, stopJobApi: _utils_jobServices__WEBPACK_IMPORTED_MODULE_15__.stopJobApi, deleteJobApi: _utils_jobServices__WEBPACK_IMPORTED_MODULE_15__.deleteJobApi, region: region, setDetailedView: setDetailedView, clusterResponse: clusterResponse, clustersList: clustersList })),
        !submitJobView && !detailedJobView && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
            clusterResponse &&
                clusterResponse.clusters &&
                clusterResponse.clusters.length > 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-cluster-overlay" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: "create-cluster-sub-overlay", onClick: () => {
                        handleSubmitJobOpen();
                    } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-cluster-icon" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconSubmitJob.react, { tag: "div" })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "create-cluster-text" }, "SUBMIT JOB")))),
            jobsList.length > 0 ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "filter-cluster-overlay" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "filter-cluster-icon" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconFilter.react, { tag: "div" })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "filter-cluster-text" }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "filter-cluster-section" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_globalFilter__WEBPACK_IMPORTED_MODULE_22__["default"], { preGlobalFilteredRows: preGlobalFilteredRows, globalFilter: state.globalFilter, setGlobalFilter: setGlobalFilter, setPollingDisable: setPollingDisable }))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: clusterResponse
                        ? 'jobs-list-table-parent'
                        : 'jobs-list-table-parent-small' },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_tableData__WEBPACK_IMPORTED_MODULE_23__["default"], { getTableProps: getTableProps, headerGroups: headerGroups, getTableBodyProps: getTableBodyProps, isLoading: isLoading, page: page, rows: rows, prepareRow: prepareRow, tableDataCondition: tableDataCondition, fromPage: "Jobs" }),
                    jobsList.length > 50 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_paginationView__WEBPACK_IMPORTED_MODULE_24__.PaginationView, { pageSize: pageSize, setPageSize: setPageSize, pageIndex: pageIndex, allData: jobsList, previousPage: previousPage, nextPage: nextPage, canPreviousPage: canPreviousPage, canNextPage: canNextPage }))))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                isLoading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "spin-loaderMain" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_18___default()), { color: "#8A8A8A", loading: true, size: 20, "aria-label": "Loading Spinner", "data-testid": "loader" }),
                    "Loading Jobs")),
                !isLoading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "no-data-style" }, "No rows to display"))))))));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (JobComponent);


/***/ }),

/***/ "./lib/jobs/labelProperties.js":
/*!*************************************!*\
  !*** ./lib/jobs/labelProperties.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _style_icons_plus_icon_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../style/icons/plus_icon.svg */ "./style/icons/plus_icon.svg");
/* harmony import */ var _style_icons_plus_icon_disable_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../style/icons/plus_icon_disable.svg */ "./style/icons/plus_icon_disable.svg");
/* harmony import */ var _style_icons_delete_icon_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../style/icons/delete_icon.svg */ "./style/icons/delete_icon.svg");
/* harmony import */ var _style_icons_error_icon_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../style/icons/error_icon.svg */ "./style/icons/error_icon.svg");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! semantic-ui-react */ "webpack/sharing/consume/default/semantic-ui-react/semantic-ui-react");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */








const iconPlus = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:plus-icon',
    svgstr: _style_icons_plus_icon_svg__WEBPACK_IMPORTED_MODULE_3__
});
const iconPlusDisable = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:plus-disable-icon',
    svgstr: _style_icons_plus_icon_disable_svg__WEBPACK_IMPORTED_MODULE_4__
});
const iconDelete = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:delete-icon',
    svgstr: _style_icons_delete_icon_svg__WEBPACK_IMPORTED_MODULE_5__
});
const iconError = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:error-icon',
    svgstr: _style_icons_error_icon_svg__WEBPACK_IMPORTED_MODULE_6__
});
function LabelProperties({ labelDetail, setLabelDetail, labelDetailUpdated, setLabelDetailUpdated, selectedJobClone, buttonText, keyValidation, setKeyValidation, valueValidation, setValueValidation, duplicateKeyError, setDuplicateKeyError, labelEditMode }) {
    /*
    labelDetail used to store the permanent label details when onblur
    labelDetailUpdated used to store the temporay label details when onchange
    */
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!labelEditMode) {
            if (buttonText === 'ADD LABEL' && !selectedJobClone) {
                setLabelDetail([_utils_const__WEBPACK_IMPORTED_MODULE_7__.DEFAULT_LABEL_DETAIL]);
                setLabelDetailUpdated([_utils_const__WEBPACK_IMPORTED_MODULE_7__.DEFAULT_LABEL_DETAIL]);
            }
            else {
                setLabelDetail([]);
            }
        }
    }, []);
    const handleAddLabel = () => {
        const labelAdd = [...labelDetail];
        labelAdd.push(':');
        setLabelDetailUpdated(labelAdd);
        setLabelDetail(labelAdd);
    };
    const handleDeleteLabel = (index, value) => {
        const labelDelete = [...labelDetail];
        labelDelete.splice(index, 1);
        setLabelDetailUpdated(labelDelete);
        setLabelDetail(labelDelete);
        setDuplicateKeyError(-1);
        setKeyValidation(-1);
        setValueValidation(-1);
    };
    const handleEditLabelSwitch = () => {
        if (duplicateKeyError === -1) {
            setLabelDetail(labelDetailUpdated);
        }
    };
    const handleEditLabel = (value, index, keyValue) => {
        const labelEdit = [...labelDetail];
        labelEdit.forEach((data, dataNumber) => {
            if (index === dataNumber) {
                /*
                  allowed aplhanumeric and spaces and underscores
                */
                const regexp = /^[a-z0-9-_]+$/;
                if (keyValue === 'key') {
                    if (value.search(regexp) === -1 ||
                        value.charAt(0) !== value.charAt(0).toLowerCase()) {
                        setKeyValidation(index);
                    }
                    else {
                        setKeyValidation(-1);
                    }
                    // Check for duplicate key when editing
                    const newKey = value;
                    const duplicateIndex = labelEdit.findIndex((label, i) => i !== index && label.split(':')[0] === newKey);
                    if (duplicateIndex !== -1) {
                        setDuplicateKeyError(index);
                    }
                    else {
                        setDuplicateKeyError(-1);
                    }
                    data = data.replace(data.split(':')[0], value);
                }
                else {
                    if (value.search(regexp) === -1) {
                        setValueValidation(index);
                    }
                    else {
                        setValueValidation(-1);
                    }
                    /*
                    value is split from labels
                    Example:"client:dataproc_plugin"
                    */
                    if (data.split(':')[1] === '') {
                        data = data + value;
                    }
                    else {
                        data = data.replace(data.split(':')[1], value);
                    }
                }
            }
            labelEdit[dataNumber] = data;
        });
        setLabelDetailUpdated(labelEdit);
    };
    const styleAddLabelButton = (buttonText, labelDetail) => {
        if (buttonText === 'ADD LABEL' &&
            (labelDetail.length === 0 ||
                labelDetail[labelDetail.length - 1].split(':')[0].length > 0) &&
            duplicateKeyError === -1) {
            return 'job-add-label-button';
        }
        else if (buttonText === 'ADD LABEL' &&
            (labelDetail.length === 0 ||
                labelDetail[labelDetail.length - 1].split(':')[0].length === 0) &&
            duplicateKeyError !== -1) {
            return 'job-add-label-button-disabled';
        }
        else if (buttonText !== 'ADD LABEL' &&
            (labelDetail.length === 0 ||
                labelDetail[labelDetail.length - 1].split(':')[0].length > 0)) {
            return 'job-add-property-button';
        }
        else {
            return 'job-add-property-button-disabled';
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "job-label-edit-parent" },
            labelDetail.length > 0 &&
                labelDetail.map((label, index) => {
                    /*
                             Extracting key, value from label
                              Example: "{client:dataProc_plugin}"
                          */
                    const labelSplit = label.split(':');
                    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: label },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "job-label-edit-row" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "key-message-wrapper" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, { placeholder: `Key ${index + 1}*`, className: "edit-input-style", disabled: labelSplit[0] === '' ||
                                        buttonText !== 'ADD LABEL' ||
                                        duplicateKeyError !== -1
                                        ? false
                                        : true, onBlur: () => handleEditLabelSwitch(), onChange: e => handleEditLabel(e.target.value, index, 'key'), defaultValue: labelSplit[0] }),
                                labelDetailUpdated[index].split(':')[0] === '' ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "alert", className: "error-key-parent" },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "key is required"))) : (keyValidation === index &&
                                    buttonText === 'ADD LABEL' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "Only hyphens (-), underscores (_), lowercase characters, and numbers are allowed. Keys must start with a lowercase character. International characters are allowed.")))),
                                duplicateKeyError === index &&
                                    buttonText === 'ADD LABEL' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "The key is already present")))),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "key-message-wrapper" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, { placeholder: `Value ${index + 1}`, className: "edit-input-style", onBlur: () => handleEditLabelSwitch(), onChange: e => handleEditLabel(e.target.value, index, 'value'), disabled: label === _utils_const__WEBPACK_IMPORTED_MODULE_7__.DEFAULT_LABEL_DETAIL && buttonText === 'ADD LABEL', defaultValue: labelSplit[1] }),
                                valueValidation === index &&
                                    buttonText === 'ADD LABEL' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "Only hyphens (-), underscores (_), lowercase characters, and numbers are allowed. International characters are allowed.")))),
                            label === _utils_const__WEBPACK_IMPORTED_MODULE_7__.DEFAULT_LABEL_DETAIL && buttonText === 'ADD LABEL' ? "" :
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: "labels-delete-icon", onClick: () => handleDeleteLabel(index, labelSplit[0]) },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconDelete.react, { tag: "div" })),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null))));
                }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: styleAddLabelButton(buttonText, labelDetail), onClick: () => {
                    (labelDetail.length === 0 ||
                        labelDetail[labelDetail.length - 1].split(':')[0].length > 0) &&
                        handleAddLabel();
                } },
                labelDetail.length === 0 ||
                    labelDetail[labelDetail.length - 1].split(':')[0].length > 0 ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconPlus.react, { tag: "div" })) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconPlusDisable.react, { tag: "div" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: labelDetail.length === 0 ||
                        labelDetail[labelDetail.length - 1].split(':')[0].length > 0
                        ? 'job-edit-text'
                        : 'job-edit-text-disabled' }, buttonText)))));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LabelProperties);


/***/ }),

/***/ "./lib/jobs/submitJob.js":
/*!*******************************!*\
  !*** ./lib/jobs/submitJob.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _style_icons_left_arrow_icon_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../style/icons/left_arrow_icon.svg */ "./style/icons/left_arrow_icon.svg");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! semantic-ui-react */ "webpack/sharing/consume/default/semantic-ui-react/semantic-ui-react");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var semantic_ui_css_semantic_min_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! semantic-ui-css/semantic.min.css */ "./node_modules/semantic-ui-css/semantic.min.css");
/* harmony import */ var _labelProperties__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./labelProperties */ "./lib/jobs/labelProperties.js");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../utils/utils */ "./lib/utils/utils.js");
/* harmony import */ var react_tagsinput__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-tagsinput */ "webpack/sharing/consume/default/react-tagsinput/react-tagsinput");
/* harmony import */ var react_tagsinput__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_tagsinput__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_tagsinput_react_tagsinput_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-tagsinput/react-tagsinput.css */ "./node_modules/react-tagsinput/react-tagsinput.css");
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/* harmony import */ var _style_icons_error_icon_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../style/icons/error_icon.svg */ "./style/icons/error_icon.svg");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-toastify */ "webpack/sharing/consume/default/react-toastify/react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */













const iconLeftArrow = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:left-arrow-icon',
    svgstr: _style_icons_left_arrow_icon_svg__WEBPACK_IMPORTED_MODULE_8__
});
const iconError = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:error-icon',
    svgstr: _style_icons_error_icon_svg__WEBPACK_IMPORTED_MODULE_9__
});
function jobKey(selectedJobClone) {
    const jobKeys = [];
    for (const key in selectedJobClone) {
        if (key.endsWith('Job')) {
            jobKeys.push(key);
        }
    }
    return jobKeys;
}
function jobTypeFunction(jobKey) {
    let jobType = 'spark';
    switch (jobKey) {
        case 'sparkRJob':
            jobType = 'sparkR';
            return jobType;
        case 'pysparkJob':
            jobType = 'pySpark';
            return jobType;
        case 'sparkSqlJob':
            jobType = 'sparkSql';
            return jobType;
        default:
            return jobType;
    }
}
const handleOptionalFields = (selectedJobClone, jobTypeKey) => {
    let args = [];
    let jarFileUris = [];
    let archiveUris = [];
    let fileUris = [];
    let maxFailuresPerHour = '';
    let pythonFileUris = [];
    if (selectedJobClone[jobTypeKey].hasOwnProperty('fileUris')) {
        fileUris = [selectedJobClone[jobTypeKey].fileUris];
    }
    if (selectedJobClone[jobTypeKey].hasOwnProperty('jarFileUris')) {
        jarFileUris = [selectedJobClone[jobTypeKey].jarFileUris];
    }
    if (selectedJobClone[jobTypeKey].hasOwnProperty('args')) {
        args = [selectedJobClone[jobTypeKey].args];
    }
    if (selectedJobClone[jobTypeKey].hasOwnProperty('archiveUris')) {
        archiveUris = [selectedJobClone[jobTypeKey].archiveUris];
    }
    if (selectedJobClone[jobTypeKey].hasOwnProperty('pythonFileUris')) {
        pythonFileUris = [selectedJobClone[jobTypeKey].pythonFileUris];
    }
    if (selectedJobClone.hasOwnProperty('scheduling')) {
        maxFailuresPerHour = selectedJobClone.scheduling.maxFailuresPerHour;
    }
    return {
        fileUris,
        jarFileUris,
        args,
        archiveUris,
        pythonFileUris,
        maxFailuresPerHour
    };
};
function SubmitJob({ setSubmitJobView, selectedJobClone, clusterResponse }) {
    const [clusterList, setClusterList] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([{}]);
    const [jobTypeList, setJobTypeList] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([{}]);
    const [querySourceTypeList, setQuerySourceTypeList] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([{}]);
    const [clusterSelected, setClusterSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [jobIdSelected, setJobIdSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [propertyDetail, setPropertyDetail] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(['']);
    const [propertyDetailUpdated, setPropertyDetailUpdated] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(['']);
    const [parameterDetail, setParameterDetail] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(['']);
    const [parameterDetailUpdated, setParameterDetailUpdated] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(['']);
    const [hexNumber, setHexNumber] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [submitDisabled, setSubmitDisabled] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    let mainJarFileUri = '';
    let args = [];
    let jarFileUris = [];
    let archiveUris = [];
    let fileUris = [];
    let pythonFileUris = [];
    let maxFailuresPerHour = '';
    let mainRFileUri = '';
    let jobType = 'spark';
    let mainPythonFileUri = '';
    let queryFileUri = '';
    let queryType = '';
    let queryList = '';
    let mainClass = '';
    let key = [];
    let value = [];
    let jobKeys = [];
    if (Object.keys(selectedJobClone).length !== 0) {
        jobKeys = jobKey(selectedJobClone);
        const jobTypeKey = jobKeys[0];
        jobType = jobTypeFunction(jobKeys[0]);
        if (selectedJobClone[jobTypeKey].hasOwnProperty('queryFileUri')) {
            queryFileUri = selectedJobClone[jobTypeKey].queryFileUri;
            queryType = 'queryFile';
        }
        if (selectedJobClone[jobTypeKey].hasOwnProperty('queryList')) {
            queryList = selectedJobClone[jobTypeKey].queryList.queries[0];
            queryType = 'queryText';
        }
        mainJarFileUri = selectedJobClone[jobKeys[0]].mainJarFileUri;
        mainClass = selectedJobClone[jobKeys[0]].mainClass;
        mainRFileUri = selectedJobClone[jobKeys[0]].mainRFileUri;
        mainPythonFileUri = selectedJobClone[jobKeys[0]].mainPythonFileUri;
        ({
            fileUris,
            jarFileUris,
            args,
            archiveUris,
            pythonFileUris,
            maxFailuresPerHour
        } = handleOptionalFields(selectedJobClone, jobTypeKey));
    }
    const initialMainClassSelected = mainJarFileUri && mainJarFileUri !== '' ? mainJarFileUri : mainClass;
    const [mainClassSelected, setMainClassSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialMainClassSelected);
    const [mainRSelected, setMainRSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(mainRFileUri);
    const [mainPythonSelected, setMainPythonSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(mainPythonFileUri);
    const [jarFileSelected, setJarFileSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([...jarFileUris]);
    const [fileSelected, setFileSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([...fileUris]);
    const [archieveFileSelected, setArchieveFileSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([
        ...archiveUris
    ]);
    const [argumentSelected, setArgumentSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([...args]);
    const [maxRestartSelected, setMaxRestartSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(maxFailuresPerHour);
    const [jobTypeSelected, setJobTypeSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(jobType);
    const [additionalPythonFileSelected, setAdditionalPythonFileSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([...pythonFileUris]);
    const [queryFileSelected, setQueryFileSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(queryFileUri);
    const [querySourceSelected, setQuerySourceSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(queryType);
    const [queryTextSelected, setQueryTextSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(queryList);
    const [labelDetail, setLabelDetail] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(key);
    const [labelDetailUpdated, setLabelDetailUpdated] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(value);
    const [additionalPythonFileValidation, setAdditionalPythonFileValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [jarFileValidation, setJarFileValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [fileValidation, setFileValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [archieveFileValidation, setArchieveFileValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [mainPythonValidation, setMainPythonValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [queryFileValidation, setQueryFileValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [mainRValidation, setMainRValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [mainClassValidation, setMainClassValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [generationCompleted, setGenerationCompleted] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [keyValidation, setKeyValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(-1);
    const [valueValidation, setValueValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(-1);
    const [jobIdValidation, setjobIdValidation] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [duplicateKeyError, setDuplicateKeyError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(-1);
    const [mainClassActive, setMainClassActive] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const handleCancelJobButton = () => {
        setSubmitJobView(false);
    };
    const handleSubmitJobView = () => {
        if (!submitDisabled) {
            submitJob();
            setSubmitJobView(false);
        }
    };
    const handleSubmitJobBackView = () => {
        setSubmitJobView(false);
    };
    const handleClusterSelected = (event, data) => {
        setClusterSelected(data.value);
    };
    const handleJobTypeSelected = (event, data) => {
        setJobTypeSelected(data.value);
        setFileSelected([]);
        setJarFileSelected([]);
        setAdditionalPythonFileSelected([]);
        setArchieveFileSelected([]);
        setArgumentSelected([]);
        setMainPythonSelected('');
        setMainRSelected('');
        setQueryTextSelected('');
        setQueryFileSelected('');
        setMainClassSelected('');
    };
    const handleQuerySourceTypeSelected = (event, data) => {
        setQuerySourceSelected(data.value);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        let transformClusterListData = [];
        transformClusterListData = clusterResponse.clusters.filter((data) => {
            if (data.status.state === _utils_const__WEBPACK_IMPORTED_MODULE_10__.STATUS_RUNNING) {
                return {
                    clusterName: data.clusterName
                };
            }
        });
        const keyLabelStructure = transformClusterListData.map((obj) => ({
            key: obj.clusterName,
            value: obj.clusterName,
            text: obj.clusterName
        }));
        setClusterList(keyLabelStructure);
        const jobTypeData = [
            { key: 'spark', value: 'spark', text: 'Spark' },
            { key: 'sparkR', value: 'sparkR', text: 'SparkR' },
            { key: 'sparkSql', value: 'sparkSql', text: 'SparkSql' },
            { key: 'pySpark', value: 'pySpark', text: 'PySpark' }
        ];
        const querySourceData = [
            { key: 'queryFile', value: 'queryFile', text: 'Query file' },
            { key: 'queryText', value: 'queryText', text: 'Query text' }
        ];
        setJobTypeList(jobTypeData);
        setQuerySourceTypeList(querySourceData);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        disableSubmitButtonIfInvalid();
        generateRandomHex();
    }, [
        clusterSelected,
        jobIdSelected,
        mainClassSelected,
        mainRSelected,
        mainPythonSelected,
        queryFileSelected,
        queryTextSelected,
        mainClassValidation,
        jarFileValidation,
        archieveFileValidation,
        mainRValidation,
        fileValidation,
        mainPythonValidation,
        queryFileValidation,
        keyValidation,
        valueValidation,
        jobIdValidation,
        duplicateKeyError
    ]);
    const disableSubmitButtonIfInvalid = () => {
        const isSparkJob = jobTypeSelected === 'spark';
        const isSparkRJob = jobTypeSelected === 'sparkR';
        const isPySparkJob = jobTypeSelected === 'pySpark';
        const isSparkSqlJob = jobTypeSelected === 'sparkSql';
        if (clusterSelected !== '' &&
            jobIdSelected !== '' &&
            ((isSparkJob &&
                mainClassSelected.length !== 0 &&
                jarFileValidation &&
                fileValidation &&
                archieveFileValidation &&
                keyValidation === -1 &&
                valueValidation === -1 &&
                jobIdValidation &&
                duplicateKeyError === -1) ||
                (isSparkRJob &&
                    mainRSelected !== '' &&
                    mainRValidation &&
                    fileValidation &&
                    keyValidation === -1 &&
                    valueValidation === -1 &&
                    jobIdValidation &&
                    duplicateKeyError === -1) ||
                (isPySparkJob &&
                    mainPythonSelected !== '' &&
                    mainPythonValidation &&
                    additionalPythonFileValidation &&
                    jarFileValidation &&
                    fileValidation &&
                    archieveFileValidation &&
                    keyValidation === -1 &&
                    valueValidation === -1 &&
                    jobIdValidation &&
                    duplicateKeyError === -1) ||
                (isSparkSqlJob &&
                    queryFileSelected !== '' &&
                    querySourceSelected === 'queryFile' &&
                    queryFileValidation &&
                    jarFileValidation &&
                    keyValidation === -1 &&
                    valueValidation === -1 &&
                    jobIdValidation &&
                    duplicateKeyError === -1) ||
                (isSparkSqlJob &&
                    queryTextSelected !== '' &&
                    querySourceSelected === 'queryText' &&
                    jarFileValidation &&
                    keyValidation === -1 &&
                    valueValidation === -1 &&
                    jobIdValidation &&
                    duplicateKeyError === -1))) {
            setSubmitDisabled(false);
        }
        else {
            setSubmitDisabled(true);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        let jobKeys = [];
        if (Object.keys(selectedJobClone).length !== 0) {
            if (selectedJobClone.hasOwnProperty('labels')) {
                const updatedLabelDetail = Object.entries(selectedJobClone.labels).map(([k, v]) => `${k}:${v}`);
                setLabelDetail(prevLabelDetail => [
                    ...prevLabelDetail,
                    ...updatedLabelDetail
                ]);
                setLabelDetailUpdated(prevLabelDetailUpdated => [
                    ...prevLabelDetailUpdated,
                    ...updatedLabelDetail
                ]);
                for (const key in selectedJobClone) {
                    if (key.endsWith('Job')) {
                        jobKeys.push(key);
                    }
                }
                jobKeys = jobKey(selectedJobClone);
                if (selectedJobClone[jobKeys[0]].hasOwnProperty('properties')) {
                    const updatedPropertyDetail = Object.entries(selectedJobClone[jobKeys[0]].properties).map(([k, v]) => `${k}:${v}`);
                    setPropertyDetail(prevPropertyDetail => [
                        ...prevPropertyDetail,
                        ...updatedPropertyDetail
                    ]);
                    setPropertyDetailUpdated(prevPropertyDetailUpdated => [
                        ...prevPropertyDetailUpdated,
                        ...updatedPropertyDetail
                    ]);
                }
            }
        }
    }, []);
    const generateRandomHex = () => {
        if (!generationCompleted) {
            const crypto = window.crypto || window.Crypto;
            const array = new Uint32Array(1);
            crypto.getRandomValues(array);
            const hex = array[0].toString(16);
            const paddedHex = hex.padStart(8, '0');
            setHexNumber('job-' + paddedHex);
            setJobIdSelected('job-' + paddedHex);
            setGenerationCompleted(true);
        }
    };
    const createPySparkPayload = (mainPythonSelected, propertyObject, jarFileSelected, fileSelected, archieveFileSelected, argumentSelected, additionalPythonFileSelected) => {
        return {
            pysparkJob: {
                mainPythonFileUri: mainPythonSelected,
                ...(propertyObject && {
                    properties: propertyObject
                }),
                ...(jarFileSelected !== '' && {
                    jarFileUris: jarFileSelected
                }),
                ...(fileSelected !== '' && {
                    fileUris: fileSelected
                }),
                ...(archieveFileSelected !== '' && {
                    archiveUris: archieveFileSelected
                }),
                ...(argumentSelected !== '' && {
                    args: [argumentSelected]
                }),
                ...(additionalPythonFileSelected !== '' && {
                    pythonFileUris: [additionalPythonFileSelected]
                })
            }
        };
    };
    const createSparkPayload = (mainClassSelected, propertyObject, archieveFileSelected, fileSelected, jarFileSelected, argumentSelected) => {
        return {
            sparkJob: {
                mainJarFileUri: mainClassSelected,
                ...(propertyObject && {
                    properties: propertyObject
                }),
                ...(archieveFileSelected !== '' && {
                    archiveUris: archieveFileSelected
                }),
                ...(fileSelected !== '' && {
                    fileUris: [fileSelected]
                }),
                ...(jarFileSelected !== '' && {
                    jarFileUris: jarFileSelected
                }),
                ...(argumentSelected !== '' && {
                    args: [argumentSelected]
                })
            }
        };
    };
    const createSparkRPayload = (mainRSelected, propertyObject, fileSelected, argumentSelected) => {
        return {
            sparkRJob: {
                mainRFileUri: mainRSelected,
                ...(propertyObject && {
                    properties: propertyObject
                }),
                ...(fileSelected !== '' && {
                    fileUris: [fileSelected]
                }),
                ...(argumentSelected !== '' && {
                    args: [argumentSelected]
                })
            }
        };
    };
    const createSparkSqlPayload = (propertyObject, jarFileSelected, querySourceSelected, queryFileSelected, queryTextSelected) => {
        return {
            sparkSqlJob: {
                ...(propertyObject && {
                    properties: propertyObject
                }),
                ...(jarFileSelected !== '' && {
                    jarFileUris: [jarFileSelected]
                }),
                scriptVariables: {},
                ...(querySourceSelected === 'queryFile' && {
                    queryFileUri: queryFileSelected
                }),
                ...(querySourceSelected === 'queryText' && {
                    queryList: { queries: [queryTextSelected] }
                })
            }
        };
    };
    const submitJob = async () => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_11__.authApi)();
        if (credentials) {
            const labelObject = {};
            labelDetailUpdated.forEach((label) => {
                const key = label.split(':')[0];
                const value = label.split(':')[1];
                labelObject[key] = value;
            });
            const propertyObject = {};
            propertyDetailUpdated.forEach((label) => {
                const key = label.split(':')[0];
                const value = label.split(':')[1];
                propertyObject[key] = value;
            });
            const parameterObject = {};
            parameterDetailUpdated.forEach((label) => {
                const key = label.split(':')[0];
                const value = label.split(':')[1];
                parameterObject[key] = value;
            });
            const payload = {
                projectId: credentials.project_id,
                region: credentials.region_id,
                job: {
                    placement: { clusterName: clusterSelected },
                    statusHistory: [],
                    reference: { jobId: jobIdSelected, projectId: '' },
                    ...(maxRestartSelected !== '' && {
                        scheduling: { maxFailuresPerHour: maxRestartSelected }
                    }),
                    ...(labelObject && {
                        labels: labelObject
                    }),
                    ...(jobTypeSelected === 'pySpark' &&
                        createPySparkPayload(mainPythonSelected, propertyObject, jarFileSelected, fileSelected, archieveFileSelected, argumentSelected, additionalPythonFileSelected)),
                    ...(jobTypeSelected === 'spark' &&
                        createSparkPayload(mainClassSelected, propertyObject, archieveFileSelected, fileSelected, jarFileSelected, argumentSelected)),
                    ...(jobTypeSelected === 'sparkR' &&
                        createSparkRPayload(mainRSelected, propertyObject, fileSelected, argumentSelected)),
                    ...(jobTypeSelected === 'sparkSql' &&
                        createSparkSqlPayload(propertyObject, jarFileSelected, querySourceSelected, queryFileSelected, queryTextSelected))
                }
            };
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_10__.BASE_URL}/projects/${credentials.project_id}/regions/${credentials.region_id}/jobs:submit`, {
                method: 'POST',
                body: JSON.stringify(payload),
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_10__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_10__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                if (response.status === 200) {
                    response
                        .json()
                        .then((responseResult) => {
                        console.log(responseResult);
                        react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast.success(`Job ${jobIdSelected} successfully submitted`);
                    })
                        .catch((e) => {
                        console.log(e);
                    });
                }
                else {
                    throw new Error(`API failed with status: ${response.status}`);
                }
            })
                .catch((err) => {
                console.error('Error submitting job', err);
                react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast.error('Failed to submit the job');
            });
        }
    };
    const handleInputChange = (event) => {
        event.target.value.length > 0
            ? setjobIdValidation(true)
            : setjobIdValidation(false);
        setHexNumber(event.target.value);
        const newJobId = event.target.value;
        setJobIdSelected(newJobId);
    };
    const handleValidationFiles = (listOfFiles, setValuesPart, setValidationPart) => {
        if (typeof listOfFiles === 'string') {
            if (listOfFiles.startsWith('file://') ||
                listOfFiles.startsWith('gs://') ||
                listOfFiles.startsWith('hdfs://')) {
                setValidationPart(true);
            }
            else {
                setValidationPart(false);
            }
            setValuesPart(listOfFiles);
        }
        else {
            if (listOfFiles.length === 0) {
                setValidationPart(true);
            }
            else {
                listOfFiles.forEach((fileName) => {
                    if (fileName.startsWith('file://') ||
                        fileName.startsWith('gs://') ||
                        fileName.startsWith('hdfs://')) {
                        setValidationPart(true);
                    }
                    else {
                        setValidationPart(false);
                    }
                });
            }
            setValuesPart(listOfFiles);
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "scroll-comp" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-header" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: "back-arrow-icon", onClick: () => handleSubmitJobBackView() },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconLeftArrow.react, { tag: "div" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-title" }, "Submit a job")),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-container" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-label-header" }, "Cluster"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-cluster-message" }, "Choose a cluster to run your job in."),
                clusterList.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, { className: "input-style", value: "No clusters running", readOnly: true })) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Select, { placeholder: "Cluster*", onChange: handleClusterSelected, className: "select-job-style", options: clusterList, value: clusterSelected })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-label-header" }, "Job"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-cluster-message" }, "Job ID*"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, { className: "input-style", onChange: e => handleInputChange(e), type: "text", value: hexNumber }),
                !jobIdValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "ID is required"))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-cluster-message" }, "Job type*"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Select, { onChange: handleJobTypeSelected, className: "select-job-style", options: jobTypeList, value: jobTypeSelected }),
                jobTypeSelected === 'sparkSql' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-cluster-message" }, "Query source type*"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Select, { onChange: handleQuerySourceTypeSelected, className: "select-job-style", options: querySourceTypeList, value: querySourceSelected }))),
                querySourceSelected === 'queryFile' &&
                    jobTypeSelected === 'sparkSql' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-cluster-message" }, "Query file*"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, { className: "input-style", onChange: e => handleValidationFiles(e.target.value, setQueryFileSelected, setQueryFileValidation), addOnBlur: true, value: queryFileSelected }),
                    !queryFileValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "File must include a valid scheme prefix: 'file://', 'gs://', or 'hdfs://'"))),
                    queryFileValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-message" }, _utils_const__WEBPACK_IMPORTED_MODULE_10__.QUERY_FILE_MESSAGE)))),
                querySourceSelected === 'queryText' &&
                    jobTypeSelected === 'sparkSql' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-cluster-message" }, "Query text*"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, { className: "input-style", onChange: e => setQueryTextSelected(e.target.value), value: queryTextSelected }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-message" }, "The query to execute"))),
                jobTypeSelected === 'spark' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-cluster-message" }, "Main class or jar*"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, { className: "input-style", onChange: e => handleValidationFiles(e.target.value, setMainClassSelected, setMainClassValidation), onBlur: () => setMainClassActive(true), addOnBlur: true, value: mainClassSelected }),
                    mainClassSelected === '' && mainClassActive && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "Main class or jar is required"))),
                    (mainClassSelected !== '' || !mainClassActive) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-message" }, _utils_const__WEBPACK_IMPORTED_MODULE_10__.MAIN_CLASS_MESSAGE)))),
                jobTypeSelected === 'sparkR' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-cluster-message" }, "Main R file*"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, { className: "input-style", onChange: e => handleValidationFiles(e.target.value, setMainRSelected, setMainRValidation), addOnBlur: true, value: mainRSelected }),
                    !mainRValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "File must include a valid scheme prefix: 'file://', 'gs://', or 'hdfs://'"))),
                    mainRValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-message" }, _utils_const__WEBPACK_IMPORTED_MODULE_10__.QUERY_FILE_MESSAGE)))),
                jobTypeSelected === 'pySpark' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-cluster-message" }, "Main Python file*"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, { className: "input-style", onChange: e => handleValidationFiles(e.target.value, setMainPythonSelected, setMainPythonValidation), addOnBlur: true, value: mainPythonSelected }),
                    !mainPythonValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "File must include a valid scheme prefix: 'file://', 'gs://', or 'hdfs://'"))),
                    mainPythonValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-message" }, _utils_const__WEBPACK_IMPORTED_MODULE_10__.QUERY_FILE_MESSAGE)))),
                jobTypeSelected === 'pySpark' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-cluster-message" }, "Additional python files"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_tagsinput__WEBPACK_IMPORTED_MODULE_4___default()), { className: "input-style", onChange: e => handleValidationFiles(e, setAdditionalPythonFileSelected, setAdditionalPythonFileValidation), addOnBlur: true, value: additionalPythonFileSelected, inputProps: { placeholder: '' } }),
                    !additionalPythonFileValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "All files must include a valid scheme prefix: 'file://', 'gs://', or 'hdfs://'"))))),
                jobTypeSelected !== 'sparkR' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-cluster-message" }, "Jar files"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_tagsinput__WEBPACK_IMPORTED_MODULE_4___default()), { className: "select-job-style", onChange: e => handleValidationFiles(e, setJarFileSelected, setJarFileValidation), addOnBlur: true, value: jarFileSelected, inputProps: { placeholder: '' } }),
                    !jarFileValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "All files must include a valid scheme prefix: 'file://', 'gs://', or 'hdfs://'"))),
                    jarFileValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-message" }, _utils_const__WEBPACK_IMPORTED_MODULE_10__.JAR_FILE_MESSAGE)))),
                jobTypeSelected !== 'sparkSql' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-cluster-message" }, "Files"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_tagsinput__WEBPACK_IMPORTED_MODULE_4___default()), { className: "select-job-style", onChange: e => handleValidationFiles(e, setFileSelected, setFileValidation), addOnBlur: true, value: fileSelected, inputProps: { placeholder: '' } }),
                    !fileValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "All files must include a valid scheme prefix: 'file://', 'gs://', or 'hdfs://'"))),
                    fileValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-message" }, _utils_const__WEBPACK_IMPORTED_MODULE_10__.FILES_MESSAGE)))),
                (jobTypeSelected === 'spark' || jobTypeSelected === 'pySpark') && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-cluster-message" }, "Archive files"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_tagsinput__WEBPACK_IMPORTED_MODULE_4___default()), { className: "select-job-style", onChange: e => handleValidationFiles(e, setArchieveFileSelected, setArchieveFileValidation), addOnBlur: true, value: archieveFileSelected, inputProps: { placeholder: '' } }),
                    !archieveFileValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-parent" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconError.react, { tag: "div" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "error-key-missing" }, "All files must include a valid scheme prefix: 'file://', 'gs://', or 'hdfs://'"))),
                    archieveFileValidation && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-message" }, _utils_const__WEBPACK_IMPORTED_MODULE_10__.ARCHIVE_FILES_MESSAGE)))),
                jobTypeSelected !== 'sparkSql' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-cluster-message" }, "Arguments"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_tagsinput__WEBPACK_IMPORTED_MODULE_4___default()), { className: "select-job-style", onChange: e => setArgumentSelected(e), value: argumentSelected, inputProps: { placeholder: '' } }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-message" }, _utils_const__WEBPACK_IMPORTED_MODULE_10__.ARGUMENTS_MESSAGE))),
                querySourceSelected === 'queryFile' &&
                    jobTypeSelected === 'sparkSql' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-label-header" }, "Query parameters"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_labelProperties__WEBPACK_IMPORTED_MODULE_12__["default"], { labelDetail: parameterDetail, setLabelDetail: setParameterDetail, labelDetailUpdated: parameterDetailUpdated, setLabelDetailUpdated: setParameterDetailUpdated, selectedJobClone: selectedJobClone ? true : false, buttonText: "ADD PARAMETER", keyValidation: keyValidation, setKeyValidation: setKeyValidation, valueValidation: valueValidation, setValueValidation: setValueValidation, duplicateKeyError: duplicateKeyError, setDuplicateKeyError: setDuplicateKeyError }))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-cluster-message" }, "Max restarts per hour"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Input, { className: "input-style", onChange: e => setMaxRestartSelected(e.target.value), value: maxRestartSelected }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-message-with-link" },
                    _utils_const__WEBPACK_IMPORTED_MODULE_10__.MAX_RESTART_MESSAGE,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-learn-more", onClick: () => {
                            window.open(`${_utils_const__WEBPACK_IMPORTED_MODULE_10__.RESTART_JOB_URL}`, '_blank');
                        } }, "Learn more")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-label-header" }, "Properties"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_labelProperties__WEBPACK_IMPORTED_MODULE_12__["default"], { labelDetail: propertyDetail, setLabelDetail: setPropertyDetail, labelDetailUpdated: propertyDetailUpdated, setLabelDetailUpdated: setPropertyDetailUpdated, selectedJobClone: selectedJobClone ? true : false, buttonText: "ADD PROPERTY", keyValidation: keyValidation, setKeyValidation: setKeyValidation, valueValidation: valueValidation, setValueValidation: setValueValidation, duplicateKeyError: duplicateKeyError, setDuplicateKeyError: setDuplicateKeyError }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "submit-job-label-header" }, "Labels"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_labelProperties__WEBPACK_IMPORTED_MODULE_12__["default"], { labelDetail: labelDetail, setLabelDetail: setLabelDetail, labelDetailUpdated: labelDetailUpdated, setLabelDetailUpdated: setLabelDetailUpdated, selectedJobClone: selectedJobClone ? true : false, buttonText: "ADD LABEL", keyValidation: keyValidation, setKeyValidation: setKeyValidation, valueValidation: valueValidation, setValueValidation: setValueValidation, duplicateKeyError: duplicateKeyError, setDuplicateKeyError: setDuplicateKeyError }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "job-button-style-parent" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: submitDisabled
                            ? 'submit-button-disable-style'
                            : 'submit-button-style' },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", onClick: () => {
                                handleSubmitJobView();
                            } }, "SUBMIT")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "job-cancel-button-style" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", onClick: () => {
                                handleCancelJobButton();
                            } }, "CANCEL"))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_toastify__WEBPACK_IMPORTED_MODULE_6__.ToastContainer, null)))));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SubmitJob);


/***/ }),

/***/ "./lib/login/authLogin.js":
/*!********************************!*\
  !*** ./lib/login/authLogin.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthLogin: () => (/* binding */ AuthLogin)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _style_icons_signin_google_icon_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../style/icons/signin_google_icon.svg */ "./style/icons/signin_google_icon.svg");
/* harmony import */ var _handler_handler__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../handler/handler */ "./lib/handler/handler.js");
/* harmony import */ var _configSelection__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./configSelection */ "./lib/login/configSelection.js");
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../utils/utils */ "./lib/utils/utils.js");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-spinners */ "webpack/sharing/consume/default/react-spinners/react-spinners");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_spinners__WEBPACK_IMPORTED_MODULE_3__);
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */









// Create the LabIcon instance outside of the component
const IconsigninGoogle = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:signin_google_icon',
    svgstr: _style_icons_signin_google_icon_svg__WEBPACK_IMPORTED_MODULE_4__
});
const AuthLoginComponent = () => {
    const [loginState, setLoginState] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [isloginDisabled, setIsloginDisabled] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [configError, setConfigError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [loginError, setLoginError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [configLoading, setConfigLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const login = async () => {
        setIsloginDisabled(true);
        const data = await (0,_handler_handler__WEBPACK_IMPORTED_MODULE_5__.requestAPI)('login');
        if (typeof data === 'object' && data !== null) {
            const loginStatus = data.login;
            if (loginStatus === _utils_const__WEBPACK_IMPORTED_MODULE_6__.STATUS_SUCCESS) {
                setLoginState(true);
                setLoginError(false);
                localStorage.setItem('loginState', _utils_const__WEBPACK_IMPORTED_MODULE_6__.LOGIN_STATE);
            }
            else {
                setLoginState(false);
                localStorage.removeItem('loginState');
            }
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        (0,_utils_utils__WEBPACK_IMPORTED_MODULE_7__.checkConfig)(setLoginState, setConfigError, setLoginError);
        const localstorageGetInformation = localStorage.getItem('loginState');
        setLoginState(localstorageGetInformation === _utils_const__WEBPACK_IMPORTED_MODULE_6__.LOGIN_STATE);
        if (loginState) {
            setConfigLoading(false);
        }
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", null,
        configLoading && !loginState && !configError && !loginError && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "spin-loaderMain" },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement(react_spinners__WEBPACK_IMPORTED_MODULE_3__.ClipLoader, { color: "#8A8A8A", loading: true, size: 18, "aria-label": "Loading Spinner", "data-testid": "loader" }),
            "Loading Config Setup")),
        !loginError && loginState && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(_configSelection__WEBPACK_IMPORTED_MODULE_8__["default"], { loginState: loginState, configError: configError, setConfigError: setConfigError })),
        loginError && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), null,
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "login-error" }, "Please login to continue"),
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { style: { alignItems: 'center' } },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { role: "button", className: isloginDisabled
                        ? 'signin-google-icon disabled'
                        : 'signin-google-icon', onClick: isloginDisabled ? undefined : login },
                    react__WEBPACK_IMPORTED_MODULE_1___default().createElement(IconsigninGoogle.react, { tag: "div" }))))),
        configError && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "login-error" }, "Please configure gcloud with account, project-id and region"))));
};
class AuthLogin extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ReactWidget {
    constructor() {
        super();
    }
    render() {
        return react__WEBPACK_IMPORTED_MODULE_1___default().createElement(AuthLoginComponent, null);
    }
}


/***/ }),

/***/ "./lib/login/configSelection.js":
/*!**************************************!*\
  !*** ./lib/login/configSelection.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _style_icons_settings_icon_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../style/icons/settings_icon.svg */ "./style/icons/settings_icon.svg");
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../utils/utils */ "./lib/utils/utils.js");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! semantic-ui-react */ "webpack/sharing/consume/default/semantic-ui-react/semantic-ui-react");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var semantic_ui_css_semantic_min_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! semantic-ui-css/semantic.min.css */ "./node_modules/semantic-ui-css/semantic.min.css");
/* harmony import */ var _handler_handler__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../handler/handler */ "./lib/handler/handler.js");
/* harmony import */ var react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-spinners/ClipLoader */ "./node_modules/react-spinners/ClipLoader.js");
/* harmony import */ var react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-toastify */ "webpack/sharing/consume/default/react-toastify/react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */











function ConfigSelection({ loginState, configError, setConfigError }) {
    const Iconsettings = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
        name: 'launcher:settings_icon',
        svgstr: _style_icons_settings_icon_svg__WEBPACK_IMPORTED_MODULE_6__
    });
    const [projectId, setProjectId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [region, setRegion] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [projectList, setProjectList] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([{}]);
    const [regionList, setRegionList] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([{}]);
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [isLoadingUser, setIsLoadingUser] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [isLoadingProject, setIsLoadingProject] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [isLoadingRegion, setIsLoadingRegion] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [isDropdownOpen, setIsDropdownOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [regionEmpty, SetRegionEmpty] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [isSaveDisabled, setIsSaveDisabled] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [userInfo, setUserInfo] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        email: '',
        picture: ''
    });
    const handleProjectIdChange = (event, data) => {
        setRegionList([]);
        SetRegionEmpty(true);
        if (data.value === undefined) {
            regionListAPI(data);
        }
        else {
            regionListAPI(data.value);
            setProjectId(data.value);
        }
        if (projectId.length !== 0) {
            setIsSaveDisabled(false);
        }
    };
    const handleRegionChange = (event, data) => {
        setRegion(data.value);
        if (projectId) {
            setIsSaveDisabled(false);
        }
        setIsDropdownOpen(false);
    };
    const handleSave = async () => {
        setIsLoading(true);
        setIsSaveDisabled(true);
        const dataToSend = { projectId: projectId, region: region };
        try {
            const data = await (0,_handler_handler__WEBPACK_IMPORTED_MODULE_7__.requestAPI)('configuration', {
                body: JSON.stringify(dataToSend),
                method: 'POST'
            });
            if (typeof data === 'object' && data !== null) {
                const configStatus = data.config;
                setIsLoading(false);
                if (configStatus && !react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.isActive('custom-toast')) {
                    const toastifyCustomStyle = {
                        hideProgressBar: true,
                        autoClose: false,
                        theme: "dark",
                        position: react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.POSITION.BOTTOM_CENTER,
                        toastId: 'custom-toast'
                    };
                    if (configStatus.includes('Failed')) {
                        react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(configStatus, toastifyCustomStyle);
                    }
                    else {
                        react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.success(configStatus, toastifyCustomStyle);
                    }
                }
            }
        }
        catch (reason) {
            console.error(`Error on POST {dataToSend}.\n${reason}`);
        }
    };
    const displayUserInfo = async () => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_8__.authApi)();
        if (credentials) {
            fetch(_utils_const__WEBPACK_IMPORTED_MODULE_9__.USER_INFO_URL, {
                method: 'GET',
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_9__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_9__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResult) => {
                    setUserInfo(responseResult);
                    setIsLoadingUser(false);
                })
                    .catch((e) => console.log(e));
            })
                .catch((err) => {
                setIsLoadingUser(false);
                console.error('Error displaying user info', err);
                react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error('Failed to fetch user information');
            });
        }
    };
    const projectListAPI = async () => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_8__.authApi)();
        if (credentials) {
            fetch(_utils_const__WEBPACK_IMPORTED_MODULE_9__.PROJECT_LIST_URL, {
                method: 'GET',
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_9__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_9__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResult) => {
                    let transformedProjectList = [];
                    transformedProjectList = responseResult.projects.map((data) => {
                        return {
                            value: data.projectId,
                            key: data.projectId,
                            text: data.projectId
                        };
                    });
                    setProjectList(transformedProjectList);
                    setIsLoadingProject(false);
                })
                    .catch((e) => console.log(e));
            })
                .catch((err) => {
                setIsLoadingProject(false);
                console.error('Error fetching project list', err);
                react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error('Failed to fetch the projects');
            });
        }
    };
    const regionListAPI = async (projectId) => {
        try {
            const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_8__.authApi)();
            if (credentials) {
                fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_9__.REGION_URL}${projectId}/regions`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_9__.API_HEADER_CONTENT_TYPE,
                        Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_9__.API_HEADER_BEARER + credentials.access_token
                    }
                })
                    .then((response) => {
                    if (response.ok) {
                        SetRegionEmpty(true);
                        return response.json();
                    }
                    else {
                        setIsDropdownOpen(false);
                        setIsSaveDisabled(true);
                        SetRegionEmpty(false);
                        if (!react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.isActive('custom-toast-error')) {
                            react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(response.status + ' Permission Denied', {
                                position: react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.POSITION.BOTTOM_CENTER,
                                toastId: 'custom-toast-error'
                            });
                        }
                        throw new Error(`Request failed with status ${response.status}`);
                    }
                })
                    .then((responseResult) => {
                    let transformedRegionList = [];
                    transformedRegionList = responseResult.items.map((data) => {
                        return {
                            value: data.name,
                            key: data.name,
                            text: data.name
                        };
                    });
                    setRegionList(transformedRegionList);
                    setIsDropdownOpen(false);
                    SetRegionEmpty(false);
                    setIsLoadingRegion(false);
                })
                    .catch((error) => {
                    setIsLoadingRegion(false);
                    console.error('Error fetching region list:', error.message);
                });
            }
        }
        catch (error) {
            setIsLoadingRegion(false);
            console.error('Error fetching region list:');
            react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error('Failed to fetch the regions');
        }
    };
    const handleDropdownOpen = () => {
        if (regionEmpty) {
            setIsDropdownOpen(true);
        }
    };
    const fetchProjectRegion = async () => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_8__.authApi)();
        if (credentials && credentials.project_id && credentials.region_id) {
            handleProjectIdChange(Event, credentials.project_id);
            setProjectId(credentials.project_id);
            setRegion(credentials.region_id);
            setConfigError(false);
        }
        else if (credentials && credentials.config_error === 1) {
            setConfigError(true);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (loginState) {
            fetchProjectRegion();
            projectListAPI();
            displayUserInfo();
        }
        else {
            projectListAPI();
            displayUserInfo();
        }
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "Settings-component" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_toastify__WEBPACK_IMPORTED_MODULE_4__.ToastContainer, null),
        isLoadingUser && isLoadingProject && isLoadingRegion && !configError ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "spin-loaderMain" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_10___default()), { color: "#8A8A8A", loading: true, size: 20, "aria-label": "Loading Spinner", "data-testid": "loader" }),
            "Loading Config Setup")) : (!configError && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "settings-overlay" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "settings-icon" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Iconsettings.react, { tag: "div" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "settings-text" }, "Settings")),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "settings-seperator" }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "config-overlay" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "configForm" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "project-overlay" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "project-text", htmlFor: "project-id" }, "Project ID"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Select, { placeholder: projectId, className: "project-select", value: projectId, onChange: handleProjectIdChange, options: projectList })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "region-overlay" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "region-text", htmlFor: "region-id" }, "Region"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__.Select, { onClick: handleDropdownOpen, placeholder: region, className: "region-select", value: region, onChange: handleRegionChange, options: regionList, isDisabled: isDropdownOpen })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "save-overlay" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: isSaveDisabled ? 'save-button disabled' : 'save-button', disabled: isSaveDisabled, onClick: handleSave }, "Save"),
                        isLoading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "save-loader" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_10___default()), { loading: true, size: 25, "aria-label": "Loading Spinner", "data-testid": "loader" }))))),
                isDropdownOpen && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "region-loader" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_10___default()), { loading: true, size: 15, "aria-label": "Loading Spinner", "data-testid": "loader" }))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "user-info-card" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "google-header" }, "This account is managed by google.com"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "seperator" }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "user-overlay" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "user-image-overlay" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("img", { src: userInfo.picture, alt: "User Image", className: "user-image" })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "user-details" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "user-email" }, userInfo.email))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "seperator" }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "google-header" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { href: "https://policies.google.com/privacy?hl=en", target: "_blank", rel: "noopener noreferrer" }, "Privacy Policy"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "privacy-terms" }, " \u2022 "),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { href: "https://policies.google.com/terms?hl=en", target: "_blank", rel: "noopener noreferrer" }, "Terms of Service")))))))));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ConfigSelection);


/***/ }),

/***/ "./lib/sessions/listSessions.js":
/*!**************************************!*\
  !*** ./lib/sessions/listSessions.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_table__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-table */ "webpack/sharing/consume/default/react-table/react-table");
/* harmony import */ var react_table__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_table__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _style_icons_filter_icon_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../style/icons/filter_icon.svg */ "./style/icons/filter_icon.svg");
/* harmony import */ var _style_icons_succeeded_icon_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../style/icons/succeeded_icon.svg */ "./style/icons/succeeded_icon.svg");
/* harmony import */ var _style_icons_cluster_error_icon_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../style/icons/cluster_error_icon.svg */ "./style/icons/cluster_error_icon.svg");
/* harmony import */ var _style_icons_stop_icon_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../style/icons/stop_icon.svg */ "./style/icons/stop_icon.svg");
/* harmony import */ var _style_icons_stop_disable_icon_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../style/icons/stop_disable_icon.svg */ "./style/icons/stop_disable_icon.svg");
/* harmony import */ var _style_icons_delete_icon_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../style/icons/delete_icon.svg */ "./style/icons/delete_icon.svg");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-spinners */ "webpack/sharing/consume/default/react-spinners/react-spinners");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_spinners__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_globalFilter__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../utils/globalFilter */ "./lib/utils/globalFilter.js");
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/* harmony import */ var _utils_tableData__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../utils/tableData */ "./lib/utils/tableData.js");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../utils/utils */ "./lib/utils/utils.js");
/* harmony import */ var _sessionDetails__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./sessionDetails */ "./lib/sessions/sessionDetails.js");
/* harmony import */ var _utils_deletePopup__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../utils/deletePopup */ "./lib/utils/deletePopup.js");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-toastify */ "webpack/sharing/consume/default/react-toastify/react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/* harmony import */ var _utils_sessionService__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../utils/sessionService */ "./lib/utils/sessionService.js");
/* harmony import */ var _utils_paginationView__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../utils/paginationView */ "./lib/utils/paginationView.js");
/* harmony import */ var _utils_pollingTimer__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../utils/pollingTimer */ "./lib/utils/pollingTimer.js");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */





















const iconFilter = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:filter-icon',
    svgstr: _style_icons_filter_icon_svg__WEBPACK_IMPORTED_MODULE_6__
});
const iconSucceeded = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:succeeded-icon',
    svgstr: _style_icons_succeeded_icon_svg__WEBPACK_IMPORTED_MODULE_7__
});
const iconClusterError = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:cluster-error-icon',
    svgstr: _style_icons_cluster_error_icon_svg__WEBPACK_IMPORTED_MODULE_8__
});
const iconStop = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:stop-icon',
    svgstr: _style_icons_stop_icon_svg__WEBPACK_IMPORTED_MODULE_9__
});
const iconStopDisable = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:stop-disable-icon',
    svgstr: _style_icons_stop_disable_icon_svg__WEBPACK_IMPORTED_MODULE_10__
});
const iconDelete = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'launcher:delete-icon',
    svgstr: _style_icons_delete_icon_svg__WEBPACK_IMPORTED_MODULE_11__
});
function ListSessions() {
    const [sessionsList, setSessionsList] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [pollingDisable, setPollingDisable] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [sessionSelected, setSessionSelected] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [detailedSessionView, setDetailedSessionView] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [deletePopupOpen, setDeletePopupOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [selectedSessionValue, setSelectedSessionValue] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const timer = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(undefined);
    const pollingSessions = async (pollingFunction, pollingDisable) => {
        timer.current = (0,_utils_pollingTimer__WEBPACK_IMPORTED_MODULE_12__["default"])(pollingFunction, pollingDisable, timer.current);
    };
    const data = sessionsList;
    const columns = react__WEBPACK_IMPORTED_MODULE_0___default().useMemo(() => [
        {
            Header: 'Session ID',
            accessor: 'sessionID'
        },
        {
            Header: 'Status',
            accessor: 'status'
        },
        {
            Header: 'Location',
            accessor: 'location'
        },
        {
            Header: 'Creation time',
            accessor: 'creationTime'
        },
        {
            Header: 'Elapsed time',
            accessor: 'elapsedTime'
        },
        {
            Header: 'Actions',
            accessor: 'actions'
        }
    ], []);
    const listSessionsAPI = async (nextPageToken, previousSessionsList) => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_13__.authApi)();
        const pageToken = nextPageToken !== null && nextPageToken !== void 0 ? nextPageToken : '';
        if (credentials) {
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_14__.BASE_URL}/projects/${credentials.project_id}/locations/${credentials.region_id}/sessions?pageSize=50&pageToken=${pageToken}`, {
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_14__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_14__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResult) => {
                    let transformSessionListData = [];
                    if (responseResult && responseResult.sessions) {
                        let sessionsListNew = responseResult.sessions;
                        sessionsListNew.sort((a, b) => {
                            const dateA = new Date(a.createTime);
                            const dateB = new Date(b.createTime);
                            return Number(dateB) - Number(dateA);
                        });
                        transformSessionListData = sessionsListNew.map((data) => {
                            const startTimeDisplay = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_13__.jobTimeFormat)(data.createTime);
                            const startTime = new Date(data.createTime);
                            let elapsedTimeString = '';
                            if (data.state === _utils_const__WEBPACK_IMPORTED_MODULE_14__.STATUS_TERMINATED ||
                                data.state === _utils_const__WEBPACK_IMPORTED_MODULE_14__.STATUS_FAIL) {
                                elapsedTimeString = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_13__.elapsedTime)(data.stateTime, startTime);
                            }
                            return {
                                sessionID: data.name.split('/')[5],
                                status: data.state,
                                location: data.name.split('/')[3],
                                creationTime: startTimeDisplay,
                                elapsedTime: elapsedTimeString,
                                actions: renderActions(data)
                            };
                        });
                    }
                    const existingSessionsData = previousSessionsList !== null && previousSessionsList !== void 0 ? previousSessionsList : [];
                    //setStateAction never type issue
                    let allSessionsData = [
                        ...existingSessionsData,
                        ...transformSessionListData
                    ];
                    if (responseResult.nextPageToken) {
                        listSessionsAPI(responseResult.nextPageToken, allSessionsData);
                    }
                    else {
                        setSessionsList(allSessionsData);
                        setIsLoading(false);
                    }
                })
                    .catch((e) => {
                    console.log(e);
                    setIsLoading(false);
                });
            })
                .catch((err) => {
                setIsLoading(false);
                console.error('Error listing Sessions', err);
                react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error('Failed to fetch sessions');
            });
        }
    };
    const handleDeleteSession = (session) => {
        setSelectedSessionValue(session);
        setDeletePopupOpen(true);
    };
    const handleCancelDelete = () => {
        setDeletePopupOpen(false);
    };
    const handleDelete = async () => {
        await (0,_utils_sessionService__WEBPACK_IMPORTED_MODULE_15__.deleteSessionAPI)(selectedSessionValue);
        setDeletePopupOpen(false);
    };
    const { getTableProps, getTableBodyProps, headerGroups, rows, prepareRow, state, preGlobalFilteredRows, setGlobalFilter, page, canPreviousPage, canNextPage, nextPage, previousPage, setPageSize, state: { pageIndex, pageSize } } = (0,react_table__WEBPACK_IMPORTED_MODULE_1__.useTable)({ columns, data, autoResetPage: false, initialState: { pageSize: 50 } }, react_table__WEBPACK_IMPORTED_MODULE_1__.useGlobalFilter, react_table__WEBPACK_IMPORTED_MODULE_1__.usePagination);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        listSessionsAPI();
        if (!detailedSessionView) {
            pollingSessions(listSessionsAPI, pollingDisable);
        }
        return () => {
            pollingSessions(listSessionsAPI, true);
        };
    }, [pollingDisable, detailedSessionView]);
    const renderActions = (data) => {
        /*
          Extracting sessionId from sessionInfo
          Example: "projects/{project}/locations/{location}/sessions/{name}"
        */
        let sessionValue = data.name.split('/')[5];
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "actions-icon" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", "aria-disabled": data.state !== _utils_const__WEBPACK_IMPORTED_MODULE_14__.ClusterStatus.STATUS_ACTIVE, className: data.state === _utils_const__WEBPACK_IMPORTED_MODULE_14__.ClusterStatus.STATUS_ACTIVE
                    ? 'icon-buttons-style'
                    : 'icon-buttons-style-disable', title: "Terminate Session", onClick: data.state === _utils_const__WEBPACK_IMPORTED_MODULE_14__.ClusterStatus.STATUS_ACTIVE
                    ? () => (0,_utils_sessionService__WEBPACK_IMPORTED_MODULE_15__.terminateSessionAPI)(sessionValue)
                    : undefined }, data.state === _utils_const__WEBPACK_IMPORTED_MODULE_14__.ClusterStatus.STATUS_ACTIVE ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconStop.react, { tag: "div" })) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconStopDisable.react, { tag: "div" }))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: "icon-buttons-style", title: "Delete Session", onClick: () => handleDeleteSession(sessionValue) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconDelete.react, { tag: "div" }))));
    };
    const handleSessionDetails = (selectedName) => {
        pollingSessions(listSessionsAPI, true);
        setSessionSelected(selectedName);
        setDetailedSessionView(true);
    };
    const tableDataCondition = (cell) => {
        if (cell.column.Header === 'Session ID') {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { role: "button", ...cell.getCellProps(), className: "cluster-name", onClick: () => handleSessionDetails(cell.value) }, cell.value));
        }
        if (cell.column.Header === 'Status') {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { ...cell.getCellProps(), className: "clusters-table-data" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: "Status", className: "cluster-status-parent" },
                    cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_14__.STATUS_FAIL && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconClusterError.react, { tag: "div" }),
                    cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_14__.STATUS_TERMINATED && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconSucceeded.react, { tag: "div" })),
                    cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_14__.STATUS_ACTIVE && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconSucceeded.react, { tag: "div" }),
                    (cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_14__.STATUS_PROVISIONING ||
                        cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_14__.STATUS_CREATING ||
                        cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_14__.STATUS_PENDING ||
                        cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_14__.STATUS_TERMINATING ||
                        cell.value === _utils_const__WEBPACK_IMPORTED_MODULE_14__.STATUS_DELETING) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_spinners__WEBPACK_IMPORTED_MODULE_3__.ClipLoader, { color: "#8A8A8A", loading: true, size: 15, "aria-label": "Loading Spinner", "data-testid": "loader" })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-status" }, cell.value && cell.value.toLowerCase()))));
        }
        else {
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { ...cell.getCellProps(), className: "clusters-table-data" }, cell.render('Cell')));
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_toastify__WEBPACK_IMPORTED_MODULE_4__.ToastContainer, null),
        deletePopupOpen && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_deletePopup__WEBPACK_IMPORTED_MODULE_16__["default"], { onCancel: () => handleCancelDelete(), onDelete: () => handleDelete(), deletePopupOpen: deletePopupOpen, DeleteMsg: 'This will delete ' +
                selectedSessionValue +
                ' and cannot be undone.' })),
        detailedSessionView && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_sessionDetails__WEBPACK_IMPORTED_MODULE_17__["default"], { sessionSelected: sessionSelected, setDetailedSessionView: setDetailedSessionView, detailedSessionView: detailedSessionView })),
        sessionsList.length > 0 && !detailedSessionView ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "filter-cluster-overlay" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "filter-cluster-icon" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconFilter.react, { tag: "div" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "filter-cluster-text" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "filter-cluster-section" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_globalFilter__WEBPACK_IMPORTED_MODULE_18__["default"], { preGlobalFilteredRows: preGlobalFilteredRows, globalFilter: state.globalFilter, setGlobalFilter: setGlobalFilter, setPollingDisable: setPollingDisable }))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "session-list-table-parent" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_tableData__WEBPACK_IMPORTED_MODULE_19__["default"], { getTableProps: getTableProps, headerGroups: headerGroups, getTableBodyProps: getTableBodyProps, isLoading: isLoading, rows: rows, page: page, prepareRow: prepareRow, tableDataCondition: tableDataCondition, fromPage: "Sessions" }),
                sessionsList.length > 50 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_paginationView__WEBPACK_IMPORTED_MODULE_20__.PaginationView, { pageSize: pageSize, setPageSize: setPageSize, pageIndex: pageIndex, allData: sessionsList, previousPage: previousPage, nextPage: nextPage, canPreviousPage: canPreviousPage, canNextPage: canNextPage }))))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
            isLoading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "spin-loaderMain" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_spinners__WEBPACK_IMPORTED_MODULE_3__.ClipLoader, { color: "#8A8A8A", loading: true, size: 18, "aria-label": "Loading Spinner", "data-testid": "loader" }),
                "Loading Sessions")),
            !isLoading && !detailedSessionView && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "no-data-style" }, "No rows to display"))))));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ListSessions);


/***/ }),

/***/ "./lib/sessions/sessionDetails.js":
/*!****************************************!*\
  !*** ./lib/sessions/sessionDetails.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _style_icons_left_arrow_icon_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../style/icons/left_arrow_icon.svg */ "./style/icons/left_arrow_icon.svg");
/* harmony import */ var _style_icons_stop_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../style/icons/stop_cluster_icon.svg */ "./style/icons/stop_cluster_icon.svg");
/* harmony import */ var _style_icons_stop_cluster_disable_icon_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../style/icons/stop_cluster_disable_icon.svg */ "./style/icons/stop_cluster_disable_icon.svg");
/* harmony import */ var _style_icons_succeeded_icon_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../style/icons/succeeded_icon.svg */ "./style/icons/succeeded_icon.svg");
/* harmony import */ var _style_icons_cluster_error_icon_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../style/icons/cluster_error_icon.svg */ "./style/icons/cluster_error_icon.svg");
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../utils/utils */ "./lib/utils/utils.js");
/* harmony import */ var react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! react-spinners/ClipLoader */ "./node_modules/react-spinners/ClipLoader.js");
/* harmony import */ var react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _utils_viewLogs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../utils/viewLogs */ "./lib/utils/viewLogs.js");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-toastify */ "webpack/sharing/consume/default/react-toastify/react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/* harmony import */ var _utils_sessionService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../utils/sessionService */ "./lib/utils/sessionService.js");
/* harmony import */ var _utils_pollingTimer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../utils/pollingTimer */ "./lib/utils/pollingTimer.js");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */















const iconLeftArrow = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:left-arrow-icon',
    svgstr: _style_icons_left_arrow_icon_svg__WEBPACK_IMPORTED_MODULE_4__
});
const iconStopCluster = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:stop-cluster-icon',
    svgstr: _style_icons_stop_cluster_icon_svg__WEBPACK_IMPORTED_MODULE_5__
});
const iconStopClusterDisable = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:stop-cluster-disable-icon',
    svgstr: _style_icons_stop_cluster_disable_icon_svg__WEBPACK_IMPORTED_MODULE_6__
});
const iconSucceeded = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:succeeded-icon',
    svgstr: _style_icons_succeeded_icon_svg__WEBPACK_IMPORTED_MODULE_7__
});
const iconClusterError = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:cluster-error-icon',
    svgstr: _style_icons_cluster_error_icon_svg__WEBPACK_IMPORTED_MODULE_8__
});
function SessionDetails({ sessionSelected, setDetailedSessionView, detailedSessionView }) {
    const [sessionInfo, setSessionInfo] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        state: '',
        name: '',
        uuid: '',
        elapsedTime: '',
        createTime: '',
        stateTime: '',
        stateHistory: [{ stateStartTime: '' }],
        runtimeConfig: { properties: [] },
        environmentConfig: {
            executionConfig: []
        }
    });
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [labelDetail, setLabelDetail] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(['']);
    const timer = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(undefined);
    const pollingSessionDetails = async (pollingFunction, pollingDisable) => {
        timer.current = (0,_utils_pollingTimer__WEBPACK_IMPORTED_MODULE_9__["default"])(pollingFunction, pollingDisable, timer.current);
    };
    const handleDetailedView = () => {
        pollingSessionDetails(getSessionDetails, true);
        setDetailedSessionView(false);
    };
    const getSessionDetails = async () => {
        const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_10__.authApi)();
        if (credentials) {
            fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_11__.BASE_URL}/projects/${credentials.project_id}/locations/${credentials.region_id}/sessions/${sessionSelected}`, {
                method: 'GET',
                headers: {
                    'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_11__.API_HEADER_CONTENT_TYPE,
                    Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_11__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResult) => {
                    setSessionInfo(responseResult);
                    const labelValue = [];
                    if (responseResult.labels) {
                        for (const [key, value] of Object.entries(responseResult.labels)) {
                            labelValue.push(`${key}:${value}`);
                        }
                    }
                    setLabelDetail(labelValue);
                    setIsLoading(false);
                })
                    .catch((e) => {
                    console.log(e);
                    setIsLoading(false);
                });
            })
                .catch((err) => {
                setIsLoading(false);
                console.error('Error loading session details', err);
                react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.error(`Failed to fetch session details ${sessionSelected}`);
            });
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        getSessionDetails();
        pollingSessionDetails(getSessionDetails, false);
        return () => {
            pollingSessionDetails(getSessionDetails, true);
        };
    }, []);
    const createTimeDisplay = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_10__.jobTimeFormat)(sessionInfo.createTime);
    const parts = createTimeDisplay.split(',');
    const createTimeString = parts.slice(0, 2).join(',');
    const sessionStartTime = new Date(sessionInfo.createTime);
    let elapsedTimeString = '';
    if (sessionInfo.state === _utils_const__WEBPACK_IMPORTED_MODULE_11__.STATUS_TERMINATED ||
        sessionInfo.state === _utils_const__WEBPACK_IMPORTED_MODULE_11__.STATUS_FAIL) {
        const sessionStateTime = new Date(sessionInfo.stateTime); // Convert string to Date
        elapsedTimeString = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_10__.elapsedTime)(sessionStateTime, sessionStartTime);
    }
    const sessionActiveTime = sessionInfo.stateHistory &&
        sessionInfo.stateHistory.length > 1 &&
        sessionInfo.stateHistory[1].stateStartTime
        ? new Date(sessionInfo.stateHistory[1].stateStartTime)
        : '';
    let runTimeString = '';
    if (sessionActiveTime !== '') {
        const sessionInfoStateTime = new Date(sessionInfo.stateTime);
        runTimeString = (0,_utils_utils__WEBPACK_IMPORTED_MODULE_10__.elapsedTime)(sessionInfoStateTime, sessionActiveTime);
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_toastify__WEBPACK_IMPORTED_MODULE_2__.ToastContainer, null),
        sessionInfo.name !== '' ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "scroll-comp" }, detailedSessionView && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-header" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: "back-arrow-icon", onClick: () => handleDetailedView() },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconLeftArrow.react, { tag: "div" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-title" }, "Session details"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: sessionInfo.state === _utils_const__WEBPACK_IMPORTED_MODULE_11__.STATUS_ACTIVE
                        ? 'action-cluster-section'
                        : 'action-cluster-section disabled', onClick: () => sessionInfo.state === _utils_const__WEBPACK_IMPORTED_MODULE_11__.STATUS_ACTIVE &&
                        (0,_utils_sessionService__WEBPACK_IMPORTED_MODULE_12__.terminateSessionAPI)(sessionInfo.name.split('/')[5]) },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-icon" }, sessionInfo.state === _utils_const__WEBPACK_IMPORTED_MODULE_11__.STATUS_ACTIVE ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconStopCluster.react, { tag: "div" })) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconStopClusterDisable.react, { tag: "div" }))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-text" }, "TERMINATE")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_utils_viewLogs__WEBPACK_IMPORTED_MODULE_13__["default"], { sessionInfo: sessionInfo })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-container" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Name"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "session-details-value" }, sessionInfo.name.split('/')[5])),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "UUID"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "session-details-value" }, sessionInfo.uuid)),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Status"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "session-detail-status-parent" },
                        sessionInfo.state === _utils_const__WEBPACK_IMPORTED_MODULE_11__.STATUS_ACTIVE && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconSucceeded.react, { tag: "div" })),
                        sessionInfo.state === _utils_const__WEBPACK_IMPORTED_MODULE_11__.STATUS_TERMINATED && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconSucceeded.react, { tag: "div" })),
                        sessionInfo.state === _utils_const__WEBPACK_IMPORTED_MODULE_11__.STATUS_ERROR && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconClusterError.react, { tag: "div" })),
                        sessionInfo.state === _utils_const__WEBPACK_IMPORTED_MODULE_11__.STATUS_FAIL && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconClusterError.react, { tag: "div" })),
                        (sessionInfo.state === _utils_const__WEBPACK_IMPORTED_MODULE_11__.STATUS_PROVISIONING ||
                            sessionInfo.state === _utils_const__WEBPACK_IMPORTED_MODULE_11__.STATUS_CREATING ||
                            sessionInfo.state === _utils_const__WEBPACK_IMPORTED_MODULE_11__.STATUS_STARTING ||
                            sessionInfo.state === _utils_const__WEBPACK_IMPORTED_MODULE_11__.STATUS_STOPPING ||
                            sessionInfo.state === _utils_const__WEBPACK_IMPORTED_MODULE_11__.STATUS_TERMINATING ||
                            sessionInfo.state === _utils_const__WEBPACK_IMPORTED_MODULE_11__.STATUS_DELETING) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_14___default()), { color: "#8A8A8A", loading: true, size: 15, "aria-label": "Loading Spinner", "data-testid": "loader" }))),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-status" }, sessionInfo.state === _utils_const__WEBPACK_IMPORTED_MODULE_11__.STATUS_CREATING
                            ? _utils_const__WEBPACK_IMPORTED_MODULE_11__.STATUS_PROVISIONING
                            : sessionInfo.state.toLowerCase()))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Create time"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "session-details-value" }, createTimeString))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-header" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-title" }, "Details")),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-container" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Elapsed time"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "session-details-value" }, elapsedTimeString)),
                (sessionInfo.state === _utils_const__WEBPACK_IMPORTED_MODULE_11__.STATUS_ACTIVE ||
                    sessionInfo.state === _utils_const__WEBPACK_IMPORTED_MODULE_11__.STATUS_TERMINATED) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Run time"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "session-details-value" }, runTimeString))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Properties")),
                Object.entries(sessionInfo.runtimeConfig.properties).map(([key, value]) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details", key: key },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "session-details-label" }, key),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "session-details-value" }, value)))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Environment config")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "session-details-label" }, "Execution config")),
                Object.entries(sessionInfo.environmentConfig.executionConfig).map(([key, value]) => {
                    let label;
                    if (key === _utils_const__WEBPACK_IMPORTED_MODULE_11__.SERVICE_ACCOUNT_KEY) {
                        label = _utils_const__WEBPACK_IMPORTED_MODULE_11__.SERVICE_ACCOUNT_LABEL;
                    }
                    else if (key === _utils_const__WEBPACK_IMPORTED_MODULE_11__.NETWORK_KEY) {
                        label = _utils_const__WEBPACK_IMPORTED_MODULE_11__.NETWORK_LABEL;
                    }
                    else if (key === _utils_const__WEBPACK_IMPORTED_MODULE_11__.SUBNETWORK_KEY) {
                        label = _utils_const__WEBPACK_IMPORTED_MODULE_11__.SUBNETWORK_LABEL;
                    }
                    else {
                        label = '';
                    }
                    if (key === _utils_const__WEBPACK_IMPORTED_MODULE_11__.SERVICE_ACCOUNT_KEY ||
                        key === _utils_const__WEBPACK_IMPORTED_MODULE_11__.NETWORK_KEY ||
                        key === _utils_const__WEBPACK_IMPORTED_MODULE_11__.SUBNETWORK_KEY) {
                        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details", key: key },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "session-env-details-label" }, label),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "session-env-details-value" }, value)));
                    }
                }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "session-env-details-label" }, "Network tags"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "session-env-details-value" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "row-details" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-details-label" }, "Labels"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "session-label-style-parent" }, labelDetail.length > 0
                        ? labelDetail.map(label => {
                            /*
                               Extracting key, value from label
                                  Example: "{client:dataproc_plugin}"
                            */
                            const labelParts = label.split(':');
                            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: label, className: "job-label-style" },
                                labelParts[0],
                                " : ",
                                labelParts[1]));
                        })
                        : 'None'))))))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "loader-full-style" }, isLoading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "session-loader" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_14___default()), { color: "#8A8A8A", loading: true, size: 20, "aria-label": "Loading Spinner", "data-testid": "loader" }),
            "Loading Session Details"))))));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SessionDetails);


/***/ }),

/***/ "./lib/utils/batchService.js":
/*!***********************************!*\
  !*** ./lib/utils/batchService.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   deleteBatchAPI: () => (/* binding */ deleteBatchAPI)
/* harmony export */ });
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/utils */ "./lib/utils/utils.js");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-toastify */ "webpack/sharing/consume/default/react-toastify/react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */




const deleteBatchAPI = async (selectedBatch) => {
    const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__.authApi)();
    if (credentials) {
        fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_3__.BASE_URL}/projects/${credentials.project_id}/locations/${credentials.region_id}/batches/${selectedBatch}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_3__.API_HEADER_CONTENT_TYPE,
                Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_3__.API_HEADER_BEARER + credentials.access_token
            }
        })
            .then((response) => {
            response
                .json()
                .then((responseResult) => {
                console.log(responseResult);
            })
                .catch((e) => console.log(e));
        })
            .catch((err) => {
            console.error('Error deleting batches', err);
            react_toastify__WEBPACK_IMPORTED_MODULE_0__.toast.error(`Failed to delete the batch ${selectedBatch}`);
        });
    }
};


/***/ }),

/***/ "./lib/utils/clusterServices.js":
/*!**************************************!*\
  !*** ./lib/utils/clusterServices.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   deleteClusterApi: () => (/* binding */ deleteClusterApi),
/* harmony export */   startClusterApi: () => (/* binding */ startClusterApi),
/* harmony export */   startStopAPI: () => (/* binding */ startStopAPI),
/* harmony export */   stopClusterApi: () => (/* binding */ stopClusterApi)
/* harmony export */ });
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-toastify */ "webpack/sharing/consume/default/react-toastify/react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/utils */ "./lib/utils/utils.js");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */



const deleteClusterApi = async (selectedcluster) => {
    const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__.authApi)();
    if (credentials) {
        fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_2__.BASE_URL}/projects/${credentials.project_id}/regions/${credentials.region_id}/clusters/${selectedcluster}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_2__.API_HEADER_CONTENT_TYPE,
                Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_2__.API_HEADER_BEARER + credentials.access_token
            }
        })
            .then((response) => {
            response
                .json()
                .then((responseResult) => {
                console.log(responseResult);
            })
                .catch((e) => console.log(e));
        })
            .catch((err) => {
            console.error('Error deleting cluster', err);
        });
    }
};
const startStopAPI = async (selectedcluster, operation) => {
    const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_1__.authApi)();
    if (credentials) {
        fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_2__.BASE_URL}/projects/${credentials.project_id}/regions/${credentials.region_id}/clusters/${selectedcluster}:${operation}`, {
            method: 'POST',
            headers: {
                'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_2__.API_HEADER_CONTENT_TYPE,
                Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_2__.API_HEADER_BEARER + credentials.access_token
            }
        })
            .then((response) => {
            response
                .json()
                .then((responseResult) => {
                console.log(responseResult);
            })
                .catch((e) => console.log(e));
        })
            .catch((err) => {
            console.error(`Error ${operation} cluster`, err);
            react_toastify__WEBPACK_IMPORTED_MODULE_0__.toast.error(`Failed to ${operation} the cluster ${selectedcluster}`);
        });
    }
};
const startClusterApi = async (selectedcluster) => {
    startStopAPI(selectedcluster, 'start');
};
const stopClusterApi = async (selectedcluster) => {
    startStopAPI(selectedcluster, 'stop');
};


/***/ }),

/***/ "./lib/utils/const.js":
/*!****************************!*\
  !*** ./lib/utils/const.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   API_HEADER_BEARER: () => (/* binding */ API_HEADER_BEARER),
/* harmony export */   API_HEADER_CONTENT_TYPE: () => (/* binding */ API_HEADER_CONTENT_TYPE),
/* harmony export */   ARCHIVE_FILES_MESSAGE: () => (/* binding */ ARCHIVE_FILES_MESSAGE),
/* harmony export */   ARGUMENTS_MESSAGE: () => (/* binding */ ARGUMENTS_MESSAGE),
/* harmony export */   ARTIFACT_REGISTERY: () => (/* binding */ ARTIFACT_REGISTERY),
/* harmony export */   BASE_URL: () => (/* binding */ BASE_URL),
/* harmony export */   BASE_URL_META: () => (/* binding */ BASE_URL_META),
/* harmony export */   BASE_URL_NETWORKS: () => (/* binding */ BASE_URL_NETWORKS),
/* harmony export */   CATALOG_SEARCH: () => (/* binding */ CATALOG_SEARCH),
/* harmony export */   COLUMN_API: () => (/* binding */ COLUMN_API),
/* harmony export */   CONTAINER_REGISTERY: () => (/* binding */ CONTAINER_REGISTERY),
/* harmony export */   CREATE_BATCH_URL: () => (/* binding */ CREATE_BATCH_URL),
/* harmony export */   CREATE_CLUSTER_URL: () => (/* binding */ CREATE_CLUSTER_URL),
/* harmony export */   CUSTOM_CONTAINERS: () => (/* binding */ CUSTOM_CONTAINERS),
/* harmony export */   CUSTOM_CONTAINERS_MESSAGE: () => (/* binding */ CUSTOM_CONTAINERS_MESSAGE),
/* harmony export */   CUSTOM_CONTAINER_MESSAGE: () => (/* binding */ CUSTOM_CONTAINER_MESSAGE),
/* harmony export */   ClusterStatus: () => (/* binding */ ClusterStatus),
/* harmony export */   DCU_HOURS: () => (/* binding */ DCU_HOURS),
/* harmony export */   DEFAULT_LABEL_DETAIL: () => (/* binding */ DEFAULT_LABEL_DETAIL),
/* harmony export */   FILES_MESSAGE: () => (/* binding */ FILES_MESSAGE),
/* harmony export */   GB_MONTHS: () => (/* binding */ GB_MONTHS),
/* harmony export */   JAR_FILE_MESSAGE: () => (/* binding */ JAR_FILE_MESSAGE),
/* harmony export */   LABEL_TEXT: () => (/* binding */ LABEL_TEXT),
/* harmony export */   LOGIN_STATE: () => (/* binding */ LOGIN_STATE),
/* harmony export */   MAIN_CLASS_MESSAGE: () => (/* binding */ MAIN_CLASS_MESSAGE),
/* harmony export */   MAX_RESTART_MESSAGE: () => (/* binding */ MAX_RESTART_MESSAGE),
/* harmony export */   METASTORE_MESSAGE: () => (/* binding */ METASTORE_MESSAGE),
/* harmony export */   MONTH_NAMES: () => (/* binding */ MONTH_NAMES),
/* harmony export */   NETWORK_KEY: () => (/* binding */ NETWORK_KEY),
/* harmony export */   NETWORK_LABEL: () => (/* binding */ NETWORK_LABEL),
/* harmony export */   POLLING_TIME_LIMIT: () => (/* binding */ POLLING_TIME_LIMIT),
/* harmony export */   PROJECT_LIST_URL: () => (/* binding */ PROJECT_LIST_URL),
/* harmony export */   PYSPARK: () => (/* binding */ PYSPARK),
/* harmony export */   QUERY_DATABASE: () => (/* binding */ QUERY_DATABASE),
/* harmony export */   QUERY_FILE_MESSAGE: () => (/* binding */ QUERY_FILE_MESSAGE),
/* harmony export */   QUERY_TABLE: () => (/* binding */ QUERY_TABLE),
/* harmony export */   REGION_URL: () => (/* binding */ REGION_URL),
/* harmony export */   RESTART_JOB_URL: () => (/* binding */ RESTART_JOB_URL),
/* harmony export */   SECURITY_KEY: () => (/* binding */ SECURITY_KEY),
/* harmony export */   SELF_MANAGED_CLUSTER: () => (/* binding */ SELF_MANAGED_CLUSTER),
/* harmony export */   SERVICE_ACCOUNT: () => (/* binding */ SERVICE_ACCOUNT),
/* harmony export */   SERVICE_ACCOUNT_KEY: () => (/* binding */ SERVICE_ACCOUNT_KEY),
/* harmony export */   SERVICE_ACCOUNT_LABEL: () => (/* binding */ SERVICE_ACCOUNT_LABEL),
/* harmony export */   SPARK: () => (/* binding */ SPARK),
/* harmony export */   SPARKR: () => (/* binding */ SPARKR),
/* harmony export */   SPARKSQL: () => (/* binding */ SPARKSQL),
/* harmony export */   SPARK_HISTORY_SERVER: () => (/* binding */ SPARK_HISTORY_SERVER),
/* harmony export */   STATUS_ACTIVE: () => (/* binding */ STATUS_ACTIVE),
/* harmony export */   STATUS_CANCELLED: () => (/* binding */ STATUS_CANCELLED),
/* harmony export */   STATUS_CREATING: () => (/* binding */ STATUS_CREATING),
/* harmony export */   STATUS_DELETING: () => (/* binding */ STATUS_DELETING),
/* harmony export */   STATUS_DONE: () => (/* binding */ STATUS_DONE),
/* harmony export */   STATUS_ERROR: () => (/* binding */ STATUS_ERROR),
/* harmony export */   STATUS_FAIL: () => (/* binding */ STATUS_FAIL),
/* harmony export */   STATUS_PENDING: () => (/* binding */ STATUS_PENDING),
/* harmony export */   STATUS_PROVISIONING: () => (/* binding */ STATUS_PROVISIONING),
/* harmony export */   STATUS_RUNNING: () => (/* binding */ STATUS_RUNNING),
/* harmony export */   STATUS_SETUP_DONE: () => (/* binding */ STATUS_SETUP_DONE),
/* harmony export */   STATUS_STARTING: () => (/* binding */ STATUS_STARTING),
/* harmony export */   STATUS_STOPPED: () => (/* binding */ STATUS_STOPPED),
/* harmony export */   STATUS_STOPPING: () => (/* binding */ STATUS_STOPPING),
/* harmony export */   STATUS_SUCCESS: () => (/* binding */ STATUS_SUCCESS),
/* harmony export */   STATUS_TERMINATED: () => (/* binding */ STATUS_TERMINATED),
/* harmony export */   STATUS_TERMINATING: () => (/* binding */ STATUS_TERMINATING),
/* harmony export */   SUBNETWORK_KEY: () => (/* binding */ SUBNETWORK_KEY),
/* harmony export */   SUBNETWORK_LABEL: () => (/* binding */ SUBNETWORK_LABEL),
/* harmony export */   TITLE_LAUNCHER_CATEGORY: () => (/* binding */ TITLE_LAUNCHER_CATEGORY),
/* harmony export */   USER_INFO_URL: () => (/* binding */ USER_INFO_URL),
/* harmony export */   VIEW_LOGS_BATCH_URL: () => (/* binding */ VIEW_LOGS_BATCH_URL),
/* harmony export */   VIEW_LOGS_CLUSTER_URL: () => (/* binding */ VIEW_LOGS_CLUSTER_URL),
/* harmony export */   VIEW_LOGS_SESSION_URL: () => (/* binding */ VIEW_LOGS_SESSION_URL),
/* harmony export */   VIEW_LOGS_URL: () => (/* binding */ VIEW_LOGS_URL)
/* harmony export */ });
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const CREATE_CLUSTER_URL = 'https://console.cloud.google.com/dataproc/clusters';
const CREATE_BATCH_URL = 'https://console.cloud.google.com/dataproc/batches/create';
const BASE_URL = 'https://dataproc.googleapis.com/v1';
const BASE_URL_NETWORKS = 'https://compute.googleapis.com/compute/v1';
const BASE_URL_META = 'https://metastore.googleapis.com/v1';
const VIEW_LOGS_URL = 'https://console.cloud.google.com/logs';
const POLLING_TIME_LIMIT = 10000;
const API_HEADER_CONTENT_TYPE = 'application/json';
var ClusterStatus;
(function (ClusterStatus) {
    ClusterStatus["STATUS_RUNNING"] = "RUNNING";
    ClusterStatus["STATUS_STOPPED"] = "STOPPED";
    ClusterStatus["STATUS_ACTIVE"] = "ACTIVE";
})(ClusterStatus || (ClusterStatus = {}));
const STATUS_RUNNING = 'RUNNING';
const STATUS_ERROR = 'ERROR';
const STATUS_DONE = 'DONE';
const STATUS_CANCELLED = 'CANCELLED';
const STATUS_SUCCESS = 'SUCCEEDED';
const STATUS_FAIL = 'FAILED';
const STATUS_STOPPED = 'STOPPED';
const STATUS_STARTING = 'STARTING';
const STATUS_STOPPING = 'STOPPING';
const STATUS_DELETING = 'DELETING';
const STATUS_SETUP_DONE = 'SETUP_DONE';
const STATUS_CREATING = 'CREATING';
const STATUS_PENDING = 'PENDING';
const STATUS_PROVISIONING = 'Provisioning';
const STATUS_ACTIVE = 'ACTIVE';
const STATUS_TERMINATED = 'TERMINATED';
const STATUS_TERMINATING = 'TERMINATING';
const LABEL_TEXT = 'labels';
const API_HEADER_BEARER = 'Bearer ';
const SERVICE_ACCOUNT_KEY = 'serviceAccount';
const SERVICE_ACCOUNT_LABEL = 'Service account';
const NETWORK_KEY = 'networkUri';
const NETWORK_LABEL = 'Network';
const SUBNETWORK_KEY = 'subnetworkUri';
const SUBNETWORK_LABEL = 'Sub network';
const PROJECT_LIST_URL = 'https://cloudresourcemanager.googleapis.com/v1/projects';
const USER_INFO_URL = 'https://www.googleapis.com/oauth2/v2/userinfo';
const REGION_URL = 'https://compute.googleapis.com/compute/v1/projects/';
const LOGIN_STATE = '1';
const QUERY_TABLE = 'system=dataproc_metastore AND type=TABLE parent=';
const QUERY_DATABASE = 'system=dataproc_metastore AND type=DATABASE parent=';
const CATALOG_SEARCH = 'https://datacatalog.googleapis.com/v1/catalog:search';
const COLUMN_API = 'https://datacatalog.googleapis.com/v1/';
const MONTH_NAMES = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
];
const QUERY_FILE_MESSAGE = 'Can be a GCS file with the gs:// prefix, an HDFS file on the cluster with the hdfs:// prefix, or a local file on the cluster with the file:// prefix';
const MAIN_CLASS_MESSAGE = 'The fully qualified name of a class in a provided or standard jar file, for example, com.example.wordcount, or a provided jar file to use the main class of that jar file';
const JAR_FILE_MESSAGE = 'Jar files are included in the CLASSPATH. Can be a GCS file with the gs:// prefix, an HDFS file on the cluster with the hdfs:// prefix, or a local file on the cluster with the file:// prefix.';
const FILES_MESSAGE = 'Files are included in the working directory of each executor. Can be a GCS file with the gs:// prefix, an HDFS file on the cluster with the hdfs:// prefix, or a local file on the cluster with the file:// prefix.';
const ARCHIVE_FILES_MESSAGE = 'Archive files are extracted in the Spark working directory. Can be a GCS file with the gs:// prefix, an HDFS file on the cluster with the hdfs:// prefix, or a local file on the cluster with the file:// prefix. Supported file types: .jar, .tar, .tar.gz, .tgz, .zip';
const ARGUMENTS_MESSAGE = 'Additional arguments to pass to the main class. Press Return after each argument.';
const MAX_RESTART_MESSAGE = 'Leave blank if you do not want to allow automatic restarts on job failure. ';
const VIEW_LOGS_CLUSTER_URL = 'https://console.cloud.google.com/logs/query;query=resource.type="cloud_dataproc_cluster" resource.labels.cluster_name=';
const VIEW_LOGS_SESSION_URL = 'https://console.cloud.google.com/logs/query;query=resource.type="cloud_dataproc_session"';
const VIEW_LOGS_BATCH_URL = 'https://console.cloud.google.com/logs/query;query=resource.type="cloud_dataproc_batch"';
const RESTART_JOB_URL = 'https://cloud.google.com/dataproc/docs/concepts/jobs/restartable-jobs';
const SELF_MANAGED_CLUSTER = 'https://cloud.google.com/dataproc-metastore/docs/attach-dataproc';
const SECURITY_KEY = 'https://console.cloud.google.com/security/kms/keyrings';
const SERVICE_ACCOUNT = 'https://cloud.google.com/compute/docs/access/service-accounts';
const CUSTOM_CONTAINERS = 'https://cloud.google.com/dataproc-serverless/docs/guides/custom-containers';
const CUSTOM_CONTAINERS_MESSAGE = 'Specify a custom container image to add Java or Python dependencies not provided by the default container image. You must host your custom container on Container Registry or Artifact Registry .';
const CONTAINER_REGISTERY = 'https://console.cloud.google.com/gcr';
const ARTIFACT_REGISTERY = 'https://console.cloud.google.com/artifacts';
const METASTORE_MESSAGE = 'We recommend this option to persist table metadata when the batch finishes processing. A metastore can be shared across many serverless batches in different projects and GCP regions.';
const CUSTOM_CONTAINER_MESSAGE = ' Specify a custom container image to add Java or Python dependencies not provided by the default container image. You must host your custom container on';
const SPARK = 'Spark';
const SPARKSQL = 'SparkSQL';
const SPARKR = 'SparkR';
const PYSPARK = 'PySpark';
const DCU_HOURS = 3600000;
const GB_MONTHS = 2592000;
const TITLE_LAUNCHER_CATEGORY = 'Dataproc Jobs and Sessions';
const SPARK_HISTORY_SERVER = 'Spark History Server';
const DEFAULT_LABEL_DETAIL = 'client:dataproc-jupyter-plugin';


/***/ }),

/***/ "./lib/utils/deletePopup.js":
/*!**********************************!*\
  !*** ./lib/utils/deletePopup.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! semantic-ui-react */ "webpack/sharing/consume/default/semantic-ui-react/semantic-ui-react");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__);
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


function DeletePopup({ onCancel, onDelete, deletePopupOpen, DeleteMsg }) {
    const modalStyle = {
        width: 'auto',
        backgroundColor: 'white' // Set the desired background color
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__.Modal, { open: deletePopupOpen, onClose: onCancel, style: modalStyle },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "popup-main" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "popup-header" }, "Confirm deletion"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "popup-text" }, DeleteMsg),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "popup-buttons" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: "popup-button-style", onClick: onCancel }, "CANCEL"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: "popup-button-style", onClick: onDelete }, "DELETE")))));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DeletePopup);


/***/ }),

/***/ "./lib/utils/errorPopup.js":
/*!*********************************!*\
  !*** ./lib/utils/errorPopup.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! semantic-ui-react */ "webpack/sharing/consume/default/semantic-ui-react/semantic-ui-react");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__);
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


function ErrorPopup({ onCancel, errorPopupOpen, DeleteMsg }) {
    const modalStyle = {
        width: 'auto',
        backgroundColor: 'white' // Set the desired background color
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__.Modal, { open: errorPopupOpen, onClose: onCancel, style: modalStyle },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__.Modal.Header, null, "Error"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__.Modal.Content, null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, DeleteMsg)),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__.Modal.Actions, null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__.Button, { onClick: onCancel }, "Close"))));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ErrorPopup);


/***/ }),

/***/ "./lib/utils/globalFilter.js":
/*!***********************************!*\
  !*** ./lib/utils/globalFilter.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

function GlobalFilter({ globalFilter, setGlobalFilter, setPollingDisable }) {
    const [value, setValue] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(globalFilter);
    const onChange = (value) => {
        setGlobalFilter(value || undefined);
    };
    if (value !== undefined) {
        if (value.length !== 0) {
            setPollingDisable(true);
        }
        else {
            setPollingDisable(false);
        }
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { value: value || '', onChange: e => {
                setValue(e.target.value);
                onChange(e.target.value);
            }, placeholder: 'Filter Table', "aria-label": "filterd value", className: "filter-section-part" })));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GlobalFilter);


/***/ }),

/***/ "./lib/utils/jobServices.js":
/*!**********************************!*\
  !*** ./lib/utils/jobServices.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   deleteJobApi: () => (/* binding */ deleteJobApi),
/* harmony export */   stopJobApi: () => (/* binding */ stopJobApi)
/* harmony export */ });
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-toastify */ "webpack/sharing/consume/default/react-toastify/react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _const__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./const */ "./lib/utils/const.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils */ "./lib/utils/utils.js");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */



const stopJobApi = async (jobId) => {
    const credentials = await (0,_utils__WEBPACK_IMPORTED_MODULE_1__.authApi)();
    if (credentials) {
        fetch(`${_const__WEBPACK_IMPORTED_MODULE_2__.BASE_URL}/projects/${credentials.project_id}/regions/${credentials.region_id}/jobs/${jobId}:cancel`, {
            method: 'POST',
            headers: {
                'Content-Type': _const__WEBPACK_IMPORTED_MODULE_2__.API_HEADER_CONTENT_TYPE,
                Authorization: _const__WEBPACK_IMPORTED_MODULE_2__.API_HEADER_BEARER + credentials.access_token
            }
        })
            .then((response) => {
            response
                .json()
                .then((responseResult) => {
                console.log(responseResult);
            })
                .catch((e) => console.log(e));
        })
            .catch((err) => {
            console.error('Error to  stop job', err);
            react_toastify__WEBPACK_IMPORTED_MODULE_0__.toast.error(`Failed to stop job ${jobId}`);
        });
    }
};
const deleteJobApi = async (jobId) => {
    const credentials = await (0,_utils__WEBPACK_IMPORTED_MODULE_1__.authApi)();
    if (credentials) {
        fetch(`${_const__WEBPACK_IMPORTED_MODULE_2__.BASE_URL}/projects/${credentials.project_id}/regions/${credentials.region_id}/jobs/${jobId}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': _const__WEBPACK_IMPORTED_MODULE_2__.API_HEADER_CONTENT_TYPE,
                Authorization: _const__WEBPACK_IMPORTED_MODULE_2__.API_HEADER_BEARER + credentials.access_token
            }
        })
            .then((response) => {
            response
                .json()
                .then((responseResult) => {
                console.log(responseResult);
            })
                .catch((e) => console.log(e));
        })
            .catch((err) => {
            console.error('Error Deleting Job', err);
            react_toastify__WEBPACK_IMPORTED_MODULE_0__.toast.error(`Failed to delete the job ${jobId}`);
        });
    }
};


/***/ }),

/***/ "./lib/utils/paginationView.js":
/*!*************************************!*\
  !*** ./lib/utils/paginationView.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PaginationView: () => (/* binding */ PaginationView)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

const PaginationView = ({ pageSize, setPageSize, pageIndex, allData, previousPage, nextPage, canPreviousPage, canNextPage }) => {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "pagination-parent-view" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null, "Rows per page: "),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { className: "page-size-selection", value: pageSize, onChange: e => {
                setPageSize(Number(e.target.value));
            } }, [50, 100, 200].map(pageSize => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { key: pageSize, value: pageSize }, pageSize)))),
        (pageIndex + 1) * pageSize > allData.length ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "page-display-part" },
            pageIndex * pageSize + 1,
            " -",
            ' ',
            " ",
            allData.length,
            " of ",
            allData.length)) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "page-display-part" },
            pageIndex * pageSize + 1,
            " -",
            ' ',
            " ",
            (pageIndex + 1) * pageSize,
            " of",
            ' ',
            allData.length)),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: !canPreviousPage ? 'page-move-button disabled' : 'page-move-button', onClick: () => previousPage() }, '<'),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", onClick: () => nextPage(), className: !canNextPage ? 'page-move-button disabled' : 'page-move-button' }, '>')));
};


/***/ }),

/***/ "./lib/utils/pollingTimer.js":
/*!***********************************!*\
  !*** ./lib/utils/pollingTimer.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _const__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./const */ "./lib/utils/const.js");

const PollingTimer = (pollingFunction, pollingDisable, interval) => {
    if (pollingDisable) {
        clearInterval(interval);
    }
    else {
        interval = setInterval(pollingFunction, _const__WEBPACK_IMPORTED_MODULE_0__.POLLING_TIME_LIMIT);
        return interval;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PollingTimer);


/***/ }),

/***/ "./lib/utils/sessionService.js":
/*!*************************************!*\
  !*** ./lib/utils/sessionService.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   deleteSessionAPI: () => (/* binding */ deleteSessionAPI),
/* harmony export */   terminateSessionAPI: () => (/* binding */ terminateSessionAPI)
/* harmony export */ });
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/* harmony import */ var _utils_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/utils */ "./lib/utils/utils.js");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-toastify */ "webpack/sharing/consume/default/react-toastify/react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */




const deleteSessionAPI = async (selectedSession) => {
    const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__.authApi)();
    if (credentials) {
        fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_3__.BASE_URL}/projects/${credentials.project_id}/locations/${credentials.region_id}/sessions/${selectedSession}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_3__.API_HEADER_CONTENT_TYPE,
                Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_3__.API_HEADER_BEARER + credentials.access_token
            }
        })
            .then((response) => {
            console.log(response);
        })
            .catch((err) => {
            console.error('Error deleting session', err);
            react_toastify__WEBPACK_IMPORTED_MODULE_0__.toast.error(`Failed to delete the session ${selectedSession}`);
        });
    }
};
const terminateSessionAPI = async (selectedSession) => {
    const credentials = await (0,_utils_utils__WEBPACK_IMPORTED_MODULE_2__.authApi)();
    if (credentials) {
        fetch(`${_utils_const__WEBPACK_IMPORTED_MODULE_3__.BASE_URL}/projects/${credentials.project_id}/locations/${credentials.region_id}/sessions/${selectedSession}:terminate`, {
            method: 'POST',
            headers: {
                'Content-Type': _utils_const__WEBPACK_IMPORTED_MODULE_3__.API_HEADER_CONTENT_TYPE,
                Authorization: _utils_const__WEBPACK_IMPORTED_MODULE_3__.API_HEADER_BEARER + credentials.access_token
            }
        })
            .then((response) => {
            response
                .json()
                .then((responseResult) => {
                console.log(responseResult);
            })
                .catch((e) => console.log(e));
        })
            .catch((err) => {
            console.error('Error terminating session', err);
            react_toastify__WEBPACK_IMPORTED_MODULE_0__.toast.error(`Failed to terminate session ${selectedSession}`);
        });
    }
};


/***/ }),

/***/ "./lib/utils/statusDisplay.js":
/*!************************************!*\
  !*** ./lib/utils/statusDisplay.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   statusDisplay: () => (/* binding */ statusDisplay)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-spinners */ "webpack/sharing/consume/default/react-spinners/react-spinners");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_spinners__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_const__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../utils/const */ "./lib/utils/const.js");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _style_icons_stop_icon_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../style/icons/stop_icon.svg */ "./style/icons/stop_icon.svg");
/* harmony import */ var _style_icons_cluster_running_icon_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../style/icons/cluster_running_icon.svg */ "./style/icons/cluster_running_icon.svg");
/* harmony import */ var _style_icons_cluster_error_icon_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../style/icons/cluster_error_icon.svg */ "./style/icons/cluster_error_icon.svg");
/* harmony import */ var _style_icons_succeeded_icon_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../style/icons/succeeded_icon.svg */ "./style/icons/succeeded_icon.svg");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */








const statusDisplay = (statusMsg) => {
    const iconClusterRunning = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
        name: 'launcher:cluster-running-icon',
        svgstr: _style_icons_cluster_running_icon_svg__WEBPACK_IMPORTED_MODULE_3__
    });
    const iconClusterError = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
        name: 'launcher:cluster-error-icon',
        svgstr: _style_icons_cluster_error_icon_svg__WEBPACK_IMPORTED_MODULE_4__
    });
    const iconSucceeded = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
        name: 'launcher:succeeded-icon',
        svgstr: _style_icons_succeeded_icon_svg__WEBPACK_IMPORTED_MODULE_5__
    });
    const iconStop = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
        name: 'launcher:stop-icon',
        svgstr: _style_icons_stop_icon_svg__WEBPACK_IMPORTED_MODULE_6__
    });
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-detail-status-parent" },
        statusMsg === _utils_const__WEBPACK_IMPORTED_MODULE_7__.STATUS_CANCELLED && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconStop.react, { tag: "div" }),
        statusMsg === _utils_const__WEBPACK_IMPORTED_MODULE_7__.STATUS_RUNNING && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconClusterRunning.react, { tag: "div" }),
        statusMsg === _utils_const__WEBPACK_IMPORTED_MODULE_7__.STATUS_SUCCESS && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconSucceeded.react, { tag: "div" }),
        statusMsg === _utils_const__WEBPACK_IMPORTED_MODULE_7__.STATUS_FAIL && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconClusterError.react, { tag: "div" }),
        (statusMsg === _utils_const__WEBPACK_IMPORTED_MODULE_7__.STATUS_PROVISIONING ||
            statusMsg === _utils_const__WEBPACK_IMPORTED_MODULE_7__.STATUS_CREATING ||
            statusMsg === _utils_const__WEBPACK_IMPORTED_MODULE_7__.STATUS_STARTING ||
            statusMsg === _utils_const__WEBPACK_IMPORTED_MODULE_7__.STATUS_STOPPING ||
            statusMsg === _utils_const__WEBPACK_IMPORTED_MODULE_7__.STATUS_PENDING ||
            statusMsg === _utils_const__WEBPACK_IMPORTED_MODULE_7__.STATUS_DELETING) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_spinners__WEBPACK_IMPORTED_MODULE_1__.ClipLoader, { color: "#8A8A8A", loading: true, size: 15, "aria-label": "Loading Spinner", "data-testid": "loader" })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "cluster-status" }, statusMsg.toLowerCase())));
};


/***/ }),

/***/ "./lib/utils/tableData.js":
/*!********************************!*\
  !*** ./lib/utils/tableData.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-spinners */ "webpack/sharing/consume/default/react-spinners/react-spinners");
/* harmony import */ var react_spinners__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_spinners__WEBPACK_IMPORTED_MODULE_1__);
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


function TableData({ getTableProps, headerGroups, getTableBodyProps, isLoading, rows, page, prepareRow, tableDataCondition, fromPage }) {
    const displayData = page ? page : rows;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("table", { ...getTableProps(), className: "clusters-list-table" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("thead", null, headerGroups.map((headerGroup) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tr", { ...headerGroup.getHeaderGroupProps(), className: "cluster-list-table-header" }, headerGroup.headers.map((column) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", { ...column.getHeaderProps(), className: "clusters-table-header" }, column.render('Header')))))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tbody", { ...getTableBodyProps(), className: "clusters-table-body" }, isLoading ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "spin-loader" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(react_spinners__WEBPACK_IMPORTED_MODULE_1__.ClipLoader, { color: "#8A8A8A", loading: true, size: 18, "aria-label": "Loading Spinner", "data-testid": "loader" }),
            "Loading ",
            fromPage)) : (displayData.map((row) => {
            prepareRow(row);
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tr", { ...row.getRowProps(), className: "cluster-list-data-parent" }, row.cells.map((cell) => {
                return tableDataCondition(cell);
            })));
        })))));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TableData);


/***/ }),

/***/ "./lib/utils/utils.js":
/*!****************************!*\
  !*** ./lib/utils/utils.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BatchTypeValue: () => (/* binding */ BatchTypeValue),
/* harmony export */   authApi: () => (/* binding */ authApi),
/* harmony export */   checkConfig: () => (/* binding */ checkConfig),
/* harmony export */   convertToDCUHours: () => (/* binding */ convertToDCUHours),
/* harmony export */   convertToGBMonths: () => (/* binding */ convertToGBMonths),
/* harmony export */   elapsedTime: () => (/* binding */ elapsedTime),
/* harmony export */   iconDisplay: () => (/* binding */ iconDisplay),
/* harmony export */   jobTimeFormat: () => (/* binding */ jobTimeFormat),
/* harmony export */   jobTypeDisplay: () => (/* binding */ jobTypeDisplay),
/* harmony export */   jobTypeValue: () => (/* binding */ jobTypeValue),
/* harmony export */   jobTypeValueArguments: () => (/* binding */ jobTypeValueArguments),
/* harmony export */   statusMessage: () => (/* binding */ statusMessage),
/* harmony export */   statusMessageBatch: () => (/* binding */ statusMessageBatch),
/* harmony export */   statusValue: () => (/* binding */ statusValue)
/* harmony export */ });
/* harmony import */ var _handler_handler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../handler/handler */ "./lib/handler/handler.js");
/* harmony import */ var _const__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./const */ "./lib/utils/const.js");
/* harmony import */ var _style_icons_pyspark_logo_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../style/icons/pyspark_logo.svg */ "./style/icons/pyspark_logo.svg");
/* harmony import */ var _style_icons_python_logo_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../style/icons/python_logo.svg */ "./style/icons/python_logo.svg");
/* harmony import */ var _style_icons_sparkr_logo_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../style/icons/sparkr_logo.svg */ "./style/icons/sparkr_logo.svg");
/* harmony import */ var _style_icons_scala_logo_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../style/icons/scala_logo.svg */ "./style/icons/scala_logo.svg");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__);
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */







const authApi = async () => {
    try {
        const data = await (0,_handler_handler__WEBPACK_IMPORTED_MODULE_1__.requestAPI)('credentials');
        if (typeof data === 'object' && data !== null) {
            const credentials = {
                access_token: data.access_token,
                project_id: data.project_id,
                region_id: data.region_id,
                config_error: data.config_error,
                login_error: data.login_error
            };
            return credentials;
        }
        else {
            console.error('Invalid data format.');
        }
    }
    catch (reason) {
        console.error(`Error on GET credentials.\n${reason}`);
    }
};
const jobTimeFormat = (startTime) => {
    const date = new Date(startTime);
    const formattedDate = date.toLocaleString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
        hour: 'numeric',
        minute: 'numeric',
        second: 'numeric',
        hour12: true
    });
    return formattedDate;
};
const jobTypeValue = (data) => {
    const result = Object.keys(data).filter(key => key.endsWith('Job'));
    const jobTypeName = result[0].split('Job')[0];
    switch (jobTypeName) {
        case 'spark':
            return _const__WEBPACK_IMPORTED_MODULE_2__.SPARK;
        case 'sparkR':
            return _const__WEBPACK_IMPORTED_MODULE_2__.SPARKR;
        case 'sparkSql':
            return _const__WEBPACK_IMPORTED_MODULE_2__.SPARKSQL;
        case 'pyspark':
            return _const__WEBPACK_IMPORTED_MODULE_2__.PYSPARK;
        default:
            return jobTypeName;
    }
};
const jobTypeValueArguments = (data) => {
    const result = Object.keys(data).filter(key => key.endsWith('Job'));
    return result[0].split('Job')[0];
};
const BatchTypeValue = (data) => {
    const result = Object.keys(data).filter(key => key.endsWith('Batch'));
    const batchTypeName = result[0].split('Batch')[0];
    switch (batchTypeName) {
        case 'spark':
            return _const__WEBPACK_IMPORTED_MODULE_2__.SPARK;
        case 'sparkR':
            return _const__WEBPACK_IMPORTED_MODULE_2__.SPARKR;
        case 'sparkSql':
            return _const__WEBPACK_IMPORTED_MODULE_2__.SPARKSQL;
        case 'pyspark':
            return _const__WEBPACK_IMPORTED_MODULE_2__.PYSPARK;
        default:
            return batchTypeName;
    }
};
const jobTypeDisplay = (data) => {
    switch (data) {
        case 'spark':
            return 'Spark';
        case 'sparkR':
            return 'SparkR';
        case 'sparkSql':
            return 'Spark SQL';
        case 'pyspark':
            return 'PySpark';
        case 'hive':
            return 'Hive';
        default:
            return data;
    }
};
const elapsedTime = (endTime, jobStartTime) => {
    const jobEndTime = new Date(endTime);
    const elapsedMilliseconds = jobEndTime.getTime() - jobStartTime.getTime();
    const elapsedSeconds = Math.round(elapsedMilliseconds / 1000) % 60;
    const elapsedMinutes = Math.floor(elapsedMilliseconds / (1000 * 60)) % 60;
    const elapsedHours = Math.floor(elapsedMilliseconds / (1000 * 60 * 60));
    let elapsedTimeString = '';
    if (elapsedHours > 0) {
        elapsedTimeString += `${elapsedHours} hr `;
    }
    if (elapsedMinutes > 0) {
        elapsedTimeString += `${elapsedMinutes} min `;
    }
    if (elapsedSeconds > 0) {
        elapsedTimeString += `${elapsedSeconds} sec `;
    }
    return elapsedTimeString;
};
const statusMessage = (data) => {
    if (data.status.state === _const__WEBPACK_IMPORTED_MODULE_2__.STATUS_DONE) {
        return _const__WEBPACK_IMPORTED_MODULE_2__.STATUS_SUCCESS;
    }
    else if (data.status.state === _const__WEBPACK_IMPORTED_MODULE_2__.STATUS_ERROR) {
        return _const__WEBPACK_IMPORTED_MODULE_2__.STATUS_FAIL;
    }
    else if (data.status.state === _const__WEBPACK_IMPORTED_MODULE_2__.STATUS_SETUP_DONE) {
        return _const__WEBPACK_IMPORTED_MODULE_2__.STATUS_STARTING;
    }
    else {
        return data.status.state;
    }
};
const statusValue = (data) => {
    if (data.status.state === _const__WEBPACK_IMPORTED_MODULE_2__.STATUS_CREATING) {
        return _const__WEBPACK_IMPORTED_MODULE_2__.STATUS_PROVISIONING;
    }
    else {
        return data.status.state;
    }
};
const checkConfig = async (setLoginState, setConfigError, setLoginError) => {
    const credentials = await authApi();
    if (credentials) {
        if (credentials.access_token === '') {
            localStorage.removeItem('loginState');
            if (credentials.config_error === 1) {
                setConfigError(true);
            }
            if (credentials.login_error === 1) {
                setLoginError(true);
            }
        }
        else {
            setLoginState(true);
        }
    }
};
const statusMessageBatch = (data) => {
    if (data.state === _const__WEBPACK_IMPORTED_MODULE_2__.STATUS_DONE) {
        return _const__WEBPACK_IMPORTED_MODULE_2__.STATUS_SUCCESS;
    }
    else if (data.state === _const__WEBPACK_IMPORTED_MODULE_2__.STATUS_ERROR) {
        return _const__WEBPACK_IMPORTED_MODULE_2__.STATUS_FAIL;
    }
    else if (data.state === _const__WEBPACK_IMPORTED_MODULE_2__.STATUS_SETUP_DONE) {
        return _const__WEBPACK_IMPORTED_MODULE_2__.STATUS_STARTING;
    }
    else {
        return data.state;
    }
};
const convertToDCUHours = (milliDcu) => {
    return `~ ${(Number(milliDcu) / _const__WEBPACK_IMPORTED_MODULE_2__.DCU_HOURS).toFixed(3)} DCU-hours`;
};
const convertToGBMonths = (milliDcu) => {
    return `~ ${(Number(milliDcu) / _const__WEBPACK_IMPORTED_MODULE_2__.GB_MONTHS).toFixed(3)} GB-months`;
};
const iconPysparkLogo = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'launcher:pyspark-logo-icon',
    svgstr: _style_icons_pyspark_logo_svg__WEBPACK_IMPORTED_MODULE_3__
});
const iconPythonLogo = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'launcher:python-logo-icon',
    svgstr: _style_icons_python_logo_svg__WEBPACK_IMPORTED_MODULE_4__
});
const iconSparkRLogo = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'launcher:sparkr-logo-icon',
    svgstr: _style_icons_sparkr_logo_svg__WEBPACK_IMPORTED_MODULE_5__
});
const iconScalaLogo = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'launcher:scala-logo-icon',
    svgstr: _style_icons_scala_logo_svg__WEBPACK_IMPORTED_MODULE_6__
});
const iconDisplay = (kernelType) => {
    if ((kernelType === null || kernelType === void 0 ? void 0 : kernelType.name.includes('spylon')) ||
        (kernelType === null || kernelType === void 0 ? void 0 : kernelType.name.includes('apache'))) {
        return iconScalaLogo;
    }
    else if (kernelType === null || kernelType === void 0 ? void 0 : kernelType.name.includes('ir')) {
        return iconSparkRLogo;
    }
    else if ((kernelType === null || kernelType === void 0 ? void 0 : kernelType.name.includes('pyspark')) ||
        (kernelType === null || kernelType === void 0 ? void 0 : kernelType.resources.endpointParentResource.includes('/sessions'))) {
        return iconPysparkLogo;
    }
    else {
        return iconPythonLogo;
    }
};


/***/ }),

/***/ "./lib/utils/viewLogs.js":
/*!*******************************!*\
  !*** ./lib/utils/viewLogs.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _style_icons_view_logs_icon_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../style/icons/view_logs_icon.svg */ "./style/icons/view_logs_icon.svg");
/* harmony import */ var _const__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./const */ "./lib/utils/const.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./utils */ "./lib/utils/utils.js");
/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */





const iconViewLogs = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'launcher:view-logs-icon',
    svgstr: _style_icons_view_logs_icon_svg__WEBPACK_IMPORTED_MODULE_2__
});
function ViewLogs({ clusterInfo, projectName, clusterName, setErrorView, batchInfoResponse, sessionInfo }) {
    var _a, _b, _c, _d;
    const handleJobDetailsViewLogs = async (clusterName) => {
        const credentials = await (0,_utils__WEBPACK_IMPORTED_MODULE_3__.authApi)();
        if (credentials) {
            fetch(`${_const__WEBPACK_IMPORTED_MODULE_4__.BASE_URL}/projects/${credentials.project_id}/regions/${credentials.region_id}/clusters/${clusterName}`, {
                method: 'GET',
                headers: {
                    'Content-Type': _const__WEBPACK_IMPORTED_MODULE_4__.API_HEADER_CONTENT_TYPE,
                    Authorization: _const__WEBPACK_IMPORTED_MODULE_4__.API_HEADER_BEARER + credentials.access_token
                }
            })
                .then((response) => {
                response
                    .json()
                    .then((responseResult) => {
                    if (responseResult.error && responseResult.error.code === 404) {
                        setErrorView(true);
                    }
                    else {
                        window.open(responseResult.config.endpointConfig.httpPorts[_const__WEBPACK_IMPORTED_MODULE_4__.SPARK_HISTORY_SERVER]);
                    }
                })
                    .catch((e) => {
                    console.error(e);
                });
            })
                .catch((err) => {
                console.error('Error listing clusters Details', err);
            });
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: (((_a = batchInfoResponse === null || batchInfoResponse === void 0 ? void 0 : batchInfoResponse.runtimeInfo) === null || _a === void 0 ? void 0 : _a.endpoints) &&
                ((_b = batchInfoResponse === null || batchInfoResponse === void 0 ? void 0 : batchInfoResponse.runtimeInfo) === null || _b === void 0 ? void 0 : _b.endpoints[_const__WEBPACK_IMPORTED_MODULE_4__.SPARK_HISTORY_SERVER])) ||
                (((_c = sessionInfo === null || sessionInfo === void 0 ? void 0 : sessionInfo.runtimeInfo) === null || _c === void 0 ? void 0 : _c.endpoints) &&
                    ((_d = sessionInfo === null || sessionInfo === void 0 ? void 0 : sessionInfo.runtimeInfo) === null || _d === void 0 ? void 0 : _d.endpoints[_const__WEBPACK_IMPORTED_MODULE_4__.SPARK_HISTORY_SERVER])) ||
                (clusterName) ||
                (clusterInfo)
                ? 'action-cluster-section'
                : 'action-disabled action-cluster-section', onClick: () => {
                var _a, _b, _c, _d;
                if (clusterInfo) {
                    window.open(`${_const__WEBPACK_IMPORTED_MODULE_4__.VIEW_LOGS_CLUSTER_URL}"${clusterInfo.clusterName}" resource.labels.cluster_uuid="${clusterInfo.clusterUuid}"?project=${projectName}`, '_blank');
                }
                else if (batchInfoResponse &&
                    ((_a = batchInfoResponse === null || batchInfoResponse === void 0 ? void 0 : batchInfoResponse.runtimeInfo) === null || _a === void 0 ? void 0 : _a.endpoints) &&
                    ((_b = batchInfoResponse === null || batchInfoResponse === void 0 ? void 0 : batchInfoResponse.runtimeInfo) === null || _b === void 0 ? void 0 : _b.endpoints[_const__WEBPACK_IMPORTED_MODULE_4__.SPARK_HISTORY_SERVER])) {
                    window.open(batchInfoResponse.runtimeInfo.endpoints[_const__WEBPACK_IMPORTED_MODULE_4__.SPARK_HISTORY_SERVER], '_blank');
                }
                else if (sessionInfo &&
                    ((_c = sessionInfo === null || sessionInfo === void 0 ? void 0 : sessionInfo.runtimeInfo) === null || _c === void 0 ? void 0 : _c.endpoints) &&
                    ((_d = sessionInfo === null || sessionInfo === void 0 ? void 0 : sessionInfo.runtimeInfo) === null || _d === void 0 ? void 0 : _d.endpoints[_const__WEBPACK_IMPORTED_MODULE_4__.SPARK_HISTORY_SERVER])) {
                    window.open(sessionInfo.runtimeInfo.endpoints[_const__WEBPACK_IMPORTED_MODULE_4__.SPARK_HISTORY_SERVER], '_blank');
                }
                else if (clusterName) {
                    handleJobDetailsViewLogs(clusterName);
                }
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-icon" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconViewLogs.react, { tag: "div" })),
            clusterInfo ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-text" }, "VIEW CLOUD LOGS")) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-text" }, "VIEW SPARK LOGS"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { role: "button", className: "action-cluster-section", onClick: () => {
                /*
                  Extracting project, location, session_id from sessionInfo.name
                  Example: "projects/{project}/locations/{location}/sessionTemplates/{session_id}"
                  */
                const sessionValueUri = sessionInfo.name.split('/');
                if (sessionInfo) {
                    window.open(`${_const__WEBPACK_IMPORTED_MODULE_4__.VIEW_LOGS_SESSION_URL} resource.labels.project_id="${sessionValueUri[1]}" resource.labels.location="${sessionValueUri[3]}" resource.labels.session_id="${sessionValueUri[5]}";cursorTimestamp=${sessionInfo.createTime};?project=${sessionValueUri[1]}`, '_blank');
                }
                else {
                    /*
                    Extracting project, location, batch_id from batchInfoResponse.name
                    Example: "projects/{project}/locations/{location}/batches/{batch_id}"
                    */
                    const batchValueUri = batchInfoResponse.name.split('/');
                    window.open(`${_const__WEBPACK_IMPORTED_MODULE_4__.VIEW_LOGS_BATCH_URL} resource.labels.project_id="${batchValueUri[1]}" resource.labels.location="${batchValueUri[3]}" resource.labels.batch_id="${batchValueUri[5]}";cursorTimestamp=${batchInfoResponse.createTime};?project=${batchValueUri[1]}`, '_blank');
                }
            } }, !clusterInfo && !clusterName && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-icon" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(iconViewLogs.react, { tag: "div" })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "action-cluster-text" }, "VIEW CLOUD LOGS"))))));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ViewLogs);


/***/ }),

/***/ "data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAAVgAA8AAAAACFAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAABWAAAABwAAAAchGgaq0dERUYAAAF0AAAAHAAAAB4AJwAPT1MvMgAAAZAAAABDAAAAVnW4TJdjbWFwAAAB1AAAAEsAAAFS8CcaqmN2dCAAAAIgAAAABAAAAAQAEQFEZ2FzcAAAAiQAAAAIAAAACP//AANnbHlmAAACLAAAAQoAAAGkrRHP9WhlYWQAAAM4AAAAMAAAADYPK8YyaGhlYQAAA2gAAAAdAAAAJANCAb1obXR4AAADiAAAACIAAAAiCBkAOGxvY2EAAAOsAAAAFAAAABQBnAIybWF4cAAAA8AAAAAfAAAAIAEVAF5uYW1lAAAD4AAAATAAAAKMFGlj5HBvc3QAAAUQAAAARgAAAHJoedjqd2ViZgAABVgAAAAGAAAABrO7W5UAAAABAAAAANXulPUAAAAA1r4hgAAAAADXu2Q1eNpjYGRgYOABYjEgZmJgBEIOIGYB8xgAA/YAN3jaY2BktGOcwMDKwMI4jTGNgYHBHUp/ZZBkaGFgYGJgZWbACgLSXFMYHFT/fLjFeOD/AQY9xjMMbkBhRpAcAN48DQYAeNpjYGBgZoBgGQZGBhDwAfIYwXwWBgMgzQGETAwMqn8+8H649f8/lHX9//9b7Pzf+fWgusCAkY0BzmUE6gHpQwGMDMMeAACbxg7SAAARAUQAAAAB//8AAnjadZBPSsNAGMXfS+yMqYgOhpSuSlKadmUhiVEhEMQzFF22m17BbbvzCh5BXCUn6EG8gjeQ4DepwYo4i+/ffL95j4EDA+CFC7jQuKyIeVHrI3wkleq9F7XrSInKteOeHdda8bOoaeepSc00NWPz/LRec9G8GabyGtEdF7h19z033GAMTK7zbM42xNEZpzYof0RtQ5CUHAQJ73OtVyutc+3b7Ou//b8XNlsPx3jgjUifABdhEohKJJL5iM5p39uqc7X1+sRQSqmGrUVhlsJ4lpmEUVwyT8SUYtg0P9DyNzPADDs+tjrGV6KRCRfsui3eHcL4/p8ZXvfMlcnEU+CLv7hDykOP+AKTPTxbAAB42mNgZGBgAGKuf5KP4vltvjLIMzGAwLV9ig0g+vruFFMQzdjACOJzMIClARh0CTJ42mNgZGBgPPD/AJD8wgAEjA0MjAyogAMAbOQEAQAAAAC7ABEAAAAAAKoAAAH0AAABgAAAAUAACAFAAAgAwAAXAAAAAAAAACoAKgAqADIAbACGAKAAugDSeNpjYGRgYOBkUGFgYgABEMkFhAwM/xn0QAIADdUBdAB42qWQvUoDQRSFv3GjaISUQaymSmGxJoGAsRC0iPYLsU50Y6IxrvlRtPCJJKUPIBb+PIHv4EN4djKuKAqCDHfmu+feOdwZoMCUAJNbAlYUMzaUlM14jjxbngOq7HnOia89z1Pk1vMCa9x7ztPkzfMyJbPj+ZGi6Xp+omxuPD+zaD7meaFg7mb8GrBqHmhwxoAxlm0uiRkpP9X5m26pKRoMxTGR1D49Dv/Yb/91o6l8qL6eu5n2hZQzn68utR9m3FU2cB4t9cdSLG2utI+44Eh/P9bqKO+oJ/WxmXssj77YkrjasZQD6SFddythk3Wtzrf+UF2p076Udla1VNzsERP3kkjVRKel7mp1udXYcHtZSlV7RfmJe1GiFWveluaeKD5/MuJcSk8Tpm/vvwPIbmJleNpjYGKAAFYG7ICTgYGRiZGZkYWRlZGNkZ2Rg5GTLT2nsiDDEEIZsZfmZRqZujmDaDcDAxcI7WIOpS2gtCWUdgQAZkcSmQAAAAFblbO6AAA=":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAAVgAA8AAAAACFAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAABWAAAABwAAAAchGgaq0dERUYAAAF0AAAAHAAAAB4AJwAPT1MvMgAAAZAAAABDAAAAVnW4TJdjbWFwAAAB1AAAAEsAAAFS8CcaqmN2dCAAAAIgAAAABAAAAAQAEQFEZ2FzcAAAAiQAAAAIAAAACP//AANnbHlmAAACLAAAAQoAAAGkrRHP9WhlYWQAAAM4AAAAMAAAADYPK8YyaGhlYQAAA2gAAAAdAAAAJANCAb1obXR4AAADiAAAACIAAAAiCBkAOGxvY2EAAAOsAAAAFAAAABQBnAIybWF4cAAAA8AAAAAfAAAAIAEVAF5uYW1lAAAD4AAAATAAAAKMFGlj5HBvc3QAAAUQAAAARgAAAHJoedjqd2ViZgAABVgAAAAGAAAABrO7W5UAAAABAAAAANXulPUAAAAA1r4hgAAAAADXu2Q1eNpjYGRgYOABYjEgZmJgBEIOIGYB8xgAA/YAN3jaY2BktGOcwMDKwMI4jTGNgYHBHUp/ZZBkaGFgYGJgZWbACgLSXFMYHFT/fLjFeOD/AQY9xjMMbkBhRpAcAN48DQYAeNpjYGBgZoBgGQZGBhDwAfIYwXwWBgMgzQGETAwMqn8+8H649f8/lHX9//9b7Pzf+fWgusCAkY0BzmUE6gHpQwGMDMMeAACbxg7SAAARAUQAAAAB//8AAnjadZBPSsNAGMXfS+yMqYgOhpSuSlKadmUhiVEhEMQzFF22m17BbbvzCh5BXCUn6EG8gjeQ4DepwYo4i+/ffL95j4EDA+CFC7jQuKyIeVHrI3wkleq9F7XrSInKteOeHdda8bOoaeepSc00NWPz/LRec9G8GabyGtEdF7h19z033GAMTK7zbM42xNEZpzYof0RtQ5CUHAQJ73OtVyutc+3b7Ou//b8XNlsPx3jgjUifABdhEohKJJL5iM5p39uqc7X1+sRQSqmGrUVhlsJ4lpmEUVwyT8SUYtg0P9DyNzPADDs+tjrGV6KRCRfsui3eHcL4/p8ZXvfMlcnEU+CLv7hDykOP+AKTPTxbAAB42mNgZGBgAGKuf5KP4vltvjLIMzGAwLV9ig0g+vruFFMQzdjACOJzMIClARh0CTJ42mNgZGBgPPD/AJD8wgAEjA0MjAyogAMAbOQEAQAAAAC7ABEAAAAAAKoAAAH0AAABgAAAAUAACAFAAAgAwAAXAAAAAAAAACoAKgAqADIAbACGAKAAugDSeNpjYGRgYOBkUGFgYgABEMkFhAwM/xn0QAIADdUBdAB42qWQvUoDQRSFv3GjaISUQaymSmGxJoGAsRC0iPYLsU50Y6IxrvlRtPCJJKUPIBb+PIHv4EN4djKuKAqCDHfmu+feOdwZoMCUAJNbAlYUMzaUlM14jjxbngOq7HnOia89z1Pk1vMCa9x7ztPkzfMyJbPj+ZGi6Xp+omxuPD+zaD7meaFg7mb8GrBqHmhwxoAxlm0uiRkpP9X5m26pKRoMxTGR1D49Dv/Yb/91o6l8qL6eu5n2hZQzn68utR9m3FU2cB4t9cdSLG2utI+44Eh/P9bqKO+oJ/WxmXssj77YkrjasZQD6SFddythk3Wtzrf+UF2p076Udla1VNzsERP3kkjVRKel7mp1udXYcHtZSlV7RfmJe1GiFWveluaeKD5/MuJcSk8Tpm/vvwPIbmJleNpjYGKAAFYG7ICTgYGRiZGZkYWRlZGNkZ2Rg5GTLT2nsiDDEEIZsZfmZRqZujmDaDcDAxcI7WIOpS2gtCWUdgQAZkcSmQAAAAFblbO6AAA= ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAAVgAA8AAAAACFAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAABWAAAABwAAAAchGgaq0dERUYAAAF0AAAAHAAAAB4AJwAPT1MvMgAAAZAAAABDAAAAVnW4TJdjbWFwAAAB1AAAAEsAAAFS8CcaqmN2dCAAAAIgAAAABAAAAAQAEQFEZ2FzcAAAAiQAAAAIAAAACP//AANnbHlmAAACLAAAAQoAAAGkrRHP9WhlYWQAAAM4AAAAMAAAADYPK8YyaGhlYQAAA2gAAAAdAAAAJANCAb1obXR4AAADiAAAACIAAAAiCBkAOGxvY2EAAAOsAAAAFAAAABQBnAIybWF4cAAAA8AAAAAfAAAAIAEVAF5uYW1lAAAD4AAAATAAAAKMFGlj5HBvc3QAAAUQAAAARgAAAHJoedjqd2ViZgAABVgAAAAGAAAABrO7W5UAAAABAAAAANXulPUAAAAA1r4hgAAAAADXu2Q1eNpjYGRgYOABYjEgZmJgBEIOIGYB8xgAA/YAN3jaY2BktGOcwMDKwMI4jTGNgYHBHUp/ZZBkaGFgYGJgZWbACgLSXFMYHFT/fLjFeOD/AQY9xjMMbkBhRpAcAN48DQYAeNpjYGBgZoBgGQZGBhDwAfIYwXwWBgMgzQGETAwMqn8+8H649f8/lHX9//9b7Pzf+fWgusCAkY0BzmUE6gHpQwGMDMMeAACbxg7SAAARAUQAAAAB//8AAnjadZBPSsNAGMXfS+yMqYgOhpSuSlKadmUhiVEhEMQzFF22m17BbbvzCh5BXCUn6EG8gjeQ4DepwYo4i+/ffL95j4EDA+CFC7jQuKyIeVHrI3wkleq9F7XrSInKteOeHdda8bOoaeepSc00NWPz/LRec9G8GabyGtEdF7h19z033GAMTK7zbM42xNEZpzYof0RtQ5CUHAQJ73OtVyutc+3b7Ou//b8XNlsPx3jgjUifABdhEohKJJL5iM5p39uqc7X1+sRQSqmGrUVhlsJ4lpmEUVwyT8SUYtg0P9DyNzPADDs+tjrGV6KRCRfsui3eHcL4/p8ZXvfMlcnEU+CLv7hDykOP+AKTPTxbAAB42mNgZGBgAGKuf5KP4vltvjLIMzGAwLV9ig0g+vruFFMQzdjACOJzMIClARh0CTJ42mNgZGBgPPD/AJD8wgAEjA0MjAyogAMAbOQEAQAAAAC7ABEAAAAAAKoAAAH0AAABgAAAAUAACAFAAAgAwAAXAAAAAAAAACoAKgAqADIAbACGAKAAugDSeNpjYGRgYOBkUGFgYgABEMkFhAwM/xn0QAIADdUBdAB42qWQvUoDQRSFv3GjaISUQaymSmGxJoGAsRC0iPYLsU50Y6IxrvlRtPCJJKUPIBb+PIHv4EN4djKuKAqCDHfmu+feOdwZoMCUAJNbAlYUMzaUlM14jjxbngOq7HnOia89z1Pk1vMCa9x7ztPkzfMyJbPj+ZGi6Xp+omxuPD+zaD7meaFg7mb8GrBqHmhwxoAxlm0uiRkpP9X5m26pKRoMxTGR1D49Dv/Yb/91o6l8qL6eu5n2hZQzn68utR9m3FU2cB4t9cdSLG2utI+44Eh/P9bqKO+oJ/WxmXssj77YkrjasZQD6SFddythk3Wtzrf+UF2p076Udla1VNzsERP3kkjVRKel7mp1udXYcHtZSlV7RfmJe1GiFWveluaeKD5/MuJcSk8Tpm/vvwPIbmJleNpjYGKAAFYG7ICTgYGRiZGZkYWRlZGNkZ2Rg5GTLT2nsiDDEEIZsZfmZRqZujmDaDcDAxcI7WIOpS2gtCWUdgQAZkcSmQAAAAFblbO6AAA=";

/***/ }),

/***/ "data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAAoUAA4AAAAAEPQAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABPUy8yAAABRAAAAEQAAABWPeFJAWNtYXAAAAGIAAAAOgAAAUrQEhm3Y3Z0IAAAAcQAAAAUAAAAHAZJ/5RmcGdtAAAB2AAABPkAAAmRigp4O2dhc3AAAAbUAAAACAAAAAgAAAAQZ2x5ZgAABtwAAACuAAAAtt9nBHZoZWFkAAAHjAAAADUAAAA2ASs8e2hoZWEAAAfEAAAAIAAAACQHUwNNaG10eAAAB+QAAAAMAAAADAspAABsb2NhAAAH8AAAAAgAAAAIADgAW21heHAAAAf4AAAAIAAAACAApgm8bmFtZQAACBgAAAF3AAACzcydGhxwb3N0AAAJkAAAACoAAAA7rr1AmHByZXAAAAm8AAAAVgAAAFaSoZr/eJxjYGTewTiBgZWBg6mKaQ8DA0MPhGZ8wGDIyMTAwMTAysyAFQSkuaYwOLxgeMHIHPQ/iyGKmZvBHyjMCJIDAPe9C2B4nGNgYGBmgGAZBkYGEHAB8hjBfBYGDSDNBqQZGZgYGF4w/v8PUvCCAURLMELVAwEjG8OIBwBk5AavAAB4nGNgQANGDEbM3P83gjAAELQD4XicnVXZdtNWFJU8ZHASOmSgoA7X3DhQ68qEKRgwaSrFdiEdHAitBB2kDHTkncc+62uOQrtWH/m07n09JLR0rbYsls++R1tn2DrnRhwjKn0aiGvUoZKXA6msPZZK90lc13Uvj5UMBnFdthJPSZuonSRKat3sUC7xWOsqWSdYJ+PlIFZPVZ5noAziFB5lSUQbRBuplyZJ4onjJ4kWZxAfJUkgJaMQp9LIUEI1GsRS1aFM6dCr1xNx00DKRqMedVhU90PFJ8c1p9SsA0YqVznCFevVRr4bpwMve5DEOsGzrYcxHnisfpQqkIqR6cg/dkpOlIaBVHHUoVbi6DCTX/eRTCrNQKaMYkWl7oG43f102xYxPXQ6vi5KlUaqurnOKJrt0fGogygP2cbppNzQ2fbw5RlTVKtdcbPtQGYNXErJbHSfRAAdJlLj6QFONZwCqRn1R8XZ588BEslclKo8VTKHegOZMzt7cTHtbiersnCknwcyb3Z2452HQ6dXh3/R+hdM4cxHj+Jifj5C+lBqfiJOJKVGWMzyp4YfcVcgQrkxiAsXyuBThDl0RdrZZl3jtTH2hs/5SqlhPQna6KP4fgr9TiQrHGdRo/VInM1j13Wt3GdQS7W7Fzsyr0OVIu7vCwuuM+eEYZ4WC1VfnvneBTT/Bohn/EDeNIVL+5YpSrRvm6JMu2iKCu0SVKVdNsUU7YoppmnPmmKG9h1TzNKeMzLj/8vc55H7HN7xkJv2XeSmfQ+5ad9HbtoPkJtWITdtHblpLyA3rUZu2lWjOnYEGgZpF1IVQdA0svph3Fab9UDWjDR8aWDyLmLI+upER521tcofxX914gsHcmmip7siF5viLq/bFj483e6rj5pG3bDV+MaR8jAeRnocmtBZ+c3hv+1N3S6a7jKqMugBFUwKwABl7UAC0zrbCaT1mqf48gdgXIZ4zkpDtVSfO4am7+V5X/exOfG+x+3GLrdcd3kJWdYNcmP28N9SZKrrH+UtrVQnR6wrJ49VaxhDKrwour6SlHu0tRu/KKmy8l6U1srnk5CbPYMbQlu27mGwI0xpyiUeXlOlKD3UUo6yQyxvKco84JSLC1qGxLgOdQ9qa8TpoXoYGwshhqG0vRBwSCldFd+0ynfxHqtr2Oj4xRXh6XpyEhGf4ir7UfBU10b96A7avGbdMoMpVaqn+4xPsa/b9lFZaaSOsxe3VAfXNOsaORXTT+Rr4HRvOGjdAz1UfDRBI1U1x+jGKGM0ljXl3wR0MVZ+w2jVYvs93E+dpFWsuUuY7JsT9+C0u/0q+7WcW0bW/dcGvW3kip8jMb8tCvw7B2K3ZA3UO5OBGAvIWdAYxhYmdxiug23EbfY/Jqf/34aFRXJXOxq7eerD1ZNRJXfZ8rjLTXZZ16M2R9VOGvsIjS0PN+bY4XIstsRgQbb+wf8x7gF3aVEC4NDIZZiI2nShnurh6h6rsW04VxIBds2x43QAegAuQd8cu9bzCYD13CPnLsB9cgh2yCH4lByCz8i5BfA5OQRfkEMwIIdgl5w7AA/IIXhIDsEeOQSPyNkE+JIcgq/IIYjJIUjIuQ3wmByCJ+QQfE0OwTdGrk5k/pYH2QD6zqKbQKmdGhzaOGRGrk3Y+zxY9oFFZB9aROqRkesT6lMeLPV7i0j9wSJSfzRyY0L9iQdL/dkiUn+xiNRnxpeZIymvDp7zjg7+BJfqrV4AAAAAAQAB//8AD3icY2BkAALmJUwzGEQZZBwk+RkZGBmdGJgYmbIYgMwsoGSiiLgIs5A2owg7I5uSOqOaiT2jmZE8I5gQY17C/09BQEfg3yt+fh8gvYQxD0j68DOJiQn8U+DnZxQDcQUEljLmCwBpBgbG/3//b2SOZ+Zm4GEQcuAH2sblDLSEm8FFVJhJEGgLH6OSHpMdo5EcI3Nk0bEXJ/LYqvZ82VXHGFd6pKTkyCsQwQAAq+QkqAAAeJxjYGRgYADiw5VSsfH8Nl8ZuJlfAEUYzpvO6IXQCb7///7fyLyEmRvI5WBgAokCAFb/DJAAAAB4nGNgZGBgDvqfxRDF/IKB4f935iUMQBEUwAwAi5YFpgPoAAAD6AAAA1kAAAAAAAAAOABbAAEAAAADABYAAQAAAAAAAgAGABMAbgAAAC0JkQAAAAB4nHWQy2rCQBSG//HSi0JbWui2sypKabxgN4IgWHTTbqS4LTHGJBIzMhkFX6Pv0IfpS/RZ+puMpShNmMx3vjlz5mQAXOMbAvnzxJGzwBmjnAs4Rc9ykf7Zcon8YrmMKt4sn9C/W67gAYHlKm7wwQqidM5ogU/LAlfi0nIBF+LOcpH+0XKJ3LNcxq14tXxC71muYCJSy1Xci6+BWm11FIRG1gZ12W62OnK6lYoqStxYumsTKp3KvpyrxPhxrBxPLfc89oN17Op9uJ8nvk4jlciW09yrkZ/42jX+bFc93QRtY+ZyrtVSDm2GXGm18D3jhMasuo3G3/MwgMIKW2hEvKoQBhI12jrnNppooUOaMkMyM8+KkMBFTONizR1htpIy7nPMGSW0PjNisgOP3+WRH5MC7o9ZRR+tHsYT0u6MKPOSfTns7jBrREqyTDezs9/eU2x4WpvWcNeuS511JTE8qCF5H7u1BY1H72S3Ymi7aPD95/9+AN1fhEsAeJxjYGKAAC4G7ICZgYGRiZGZMzkjNTk7N7Eomy05syg5J5WBAQBE1QZBAABLuADIUlixAQGOWbkIAAgAYyCwASNEsAMjcLIEKAlFUkSyCgIHKrEGAUSxJAGIUViwQIhYsQYDRLEmAYhRWLgEAIhYsQYBRFlZWVm4Af+FsASNsQUARAAA":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAAoUAA4AAAAAEPQAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABPUy8yAAABRAAAAEQAAABWPeFJAWNtYXAAAAGIAAAAOgAAAUrQEhm3Y3Z0IAAAAcQAAAAUAAAAHAZJ/5RmcGdtAAAB2AAABPkAAAmRigp4O2dhc3AAAAbUAAAACAAAAAgAAAAQZ2x5ZgAABtwAAACuAAAAtt9nBHZoZWFkAAAHjAAAADUAAAA2ASs8e2hoZWEAAAfEAAAAIAAAACQHUwNNaG10eAAAB+QAAAAMAAAADAspAABsb2NhAAAH8AAAAAgAAAAIADgAW21heHAAAAf4AAAAIAAAACAApgm8bmFtZQAACBgAAAF3AAACzcydGhxwb3N0AAAJkAAAACoAAAA7rr1AmHByZXAAAAm8AAAAVgAAAFaSoZr/eJxjYGTewTiBgZWBg6mKaQ8DA0MPhGZ8wGDIyMTAwMTAysyAFQSkuaYwOLxgeMHIHPQ/iyGKmZvBHyjMCJIDAPe9C2B4nGNgYGBmgGAZBkYGEHAB8hjBfBYGDSDNBqQZGZgYGF4w/v8PUvCCAURLMELVAwEjG8OIBwBk5AavAAB4nGNgQANGDEbM3P83gjAAELQD4XicnVXZdtNWFJU8ZHASOmSgoA7X3DhQ68qEKRgwaSrFdiEdHAitBB2kDHTkncc+62uOQrtWH/m07n09JLR0rbYsls++R1tn2DrnRhwjKn0aiGvUoZKXA6msPZZK90lc13Uvj5UMBnFdthJPSZuonSRKat3sUC7xWOsqWSdYJ+PlIFZPVZ5noAziFB5lSUQbRBuplyZJ4onjJ4kWZxAfJUkgJaMQp9LIUEI1GsRS1aFM6dCr1xNx00DKRqMedVhU90PFJ8c1p9SsA0YqVznCFevVRr4bpwMve5DEOsGzrYcxHnisfpQqkIqR6cg/dkpOlIaBVHHUoVbi6DCTX/eRTCrNQKaMYkWl7oG43f102xYxPXQ6vi5KlUaqurnOKJrt0fGogygP2cbppNzQ2fbw5RlTVKtdcbPtQGYNXErJbHSfRAAdJlLj6QFONZwCqRn1R8XZ588BEslclKo8VTKHegOZMzt7cTHtbiersnCknwcyb3Z2452HQ6dXh3/R+hdM4cxHj+Jifj5C+lBqfiJOJKVGWMzyp4YfcVcgQrkxiAsXyuBThDl0RdrZZl3jtTH2hs/5SqlhPQna6KP4fgr9TiQrHGdRo/VInM1j13Wt3GdQS7W7Fzsyr0OVIu7vCwuuM+eEYZ4WC1VfnvneBTT/Bohn/EDeNIVL+5YpSrRvm6JMu2iKCu0SVKVdNsUU7YoppmnPmmKG9h1TzNKeMzLj/8vc55H7HN7xkJv2XeSmfQ+5ad9HbtoPkJtWITdtHblpLyA3rUZu2lWjOnYEGgZpF1IVQdA0svph3Fab9UDWjDR8aWDyLmLI+upER521tcofxX914gsHcmmip7siF5viLq/bFj483e6rj5pG3bDV+MaR8jAeRnocmtBZ+c3hv+1N3S6a7jKqMugBFUwKwABl7UAC0zrbCaT1mqf48gdgXIZ4zkpDtVSfO4am7+V5X/exOfG+x+3GLrdcd3kJWdYNcmP28N9SZKrrH+UtrVQnR6wrJ49VaxhDKrwour6SlHu0tRu/KKmy8l6U1srnk5CbPYMbQlu27mGwI0xpyiUeXlOlKD3UUo6yQyxvKco84JSLC1qGxLgOdQ9qa8TpoXoYGwshhqG0vRBwSCldFd+0ynfxHqtr2Oj4xRXh6XpyEhGf4ir7UfBU10b96A7avGbdMoMpVaqn+4xPsa/b9lFZaaSOsxe3VAfXNOsaORXTT+Rr4HRvOGjdAz1UfDRBI1U1x+jGKGM0ljXl3wR0MVZ+w2jVYvs93E+dpFWsuUuY7JsT9+C0u/0q+7WcW0bW/dcGvW3kip8jMb8tCvw7B2K3ZA3UO5OBGAvIWdAYxhYmdxiug23EbfY/Jqf/34aFRXJXOxq7eerD1ZNRJXfZ8rjLTXZZ16M2R9VOGvsIjS0PN+bY4XIstsRgQbb+wf8x7gF3aVEC4NDIZZiI2nShnurh6h6rsW04VxIBds2x43QAegAuQd8cu9bzCYD13CPnLsB9cgh2yCH4lByCz8i5BfA5OQRfkEMwIIdgl5w7AA/IIXhIDsEeOQSPyNkE+JIcgq/IIYjJIUjIuQ3wmByCJ+QQfE0OwTdGrk5k/pYH2QD6zqKbQKmdGhzaOGRGrk3Y+zxY9oFFZB9aROqRkesT6lMeLPV7i0j9wSJSfzRyY0L9iQdL/dkiUn+xiNRnxpeZIymvDp7zjg7+BJfqrV4AAAAAAQAB//8AD3icY2BkAALmJUwzGEQZZBwk+RkZGBmdGJgYmbIYgMwsoGSiiLgIs5A2owg7I5uSOqOaiT2jmZE8I5gQY17C/09BQEfg3yt+fh8gvYQxD0j68DOJiQn8U+DnZxQDcQUEljLmCwBpBgbG/3//b2SOZ+Zm4GEQcuAH2sblDLSEm8FFVJhJEGgLH6OSHpMdo5EcI3Nk0bEXJ/LYqvZ82VXHGFd6pKTkyCsQwQAAq+QkqAAAeJxjYGRgYADiw5VSsfH8Nl8ZuJlfAEUYzpvO6IXQCb7///7fyLyEmRvI5WBgAokCAFb/DJAAAAB4nGNgZGBgDvqfxRDF/IKB4f935iUMQBEUwAwAi5YFpgPoAAAD6AAAA1kAAAAAAAAAOABbAAEAAAADABYAAQAAAAAAAgAGABMAbgAAAC0JkQAAAAB4nHWQy2rCQBSG//HSi0JbWui2sypKabxgN4IgWHTTbqS4LTHGJBIzMhkFX6Pv0IfpS/RZ+puMpShNmMx3vjlz5mQAXOMbAvnzxJGzwBmjnAs4Rc9ykf7Zcon8YrmMKt4sn9C/W67gAYHlKm7wwQqidM5ogU/LAlfi0nIBF+LOcpH+0XKJ3LNcxq14tXxC71muYCJSy1Xci6+BWm11FIRG1gZ12W62OnK6lYoqStxYumsTKp3KvpyrxPhxrBxPLfc89oN17Op9uJ8nvk4jlciW09yrkZ/42jX+bFc93QRtY+ZyrtVSDm2GXGm18D3jhMasuo3G3/MwgMIKW2hEvKoQBhI12jrnNppooUOaMkMyM8+KkMBFTONizR1htpIy7nPMGSW0PjNisgOP3+WRH5MC7o9ZRR+tHsYT0u6MKPOSfTns7jBrREqyTDezs9/eU2x4WpvWcNeuS511JTE8qCF5H7u1BY1H72S3Ymi7aPD95/9+AN1fhEsAeJxjYGKAAC4G7ICZgYGRiZGZMzkjNTk7N7Eomy05syg5J5WBAQBE1QZBAABLuADIUlixAQGOWbkIAAgAYyCwASNEsAMjcLIEKAlFUkSyCgIHKrEGAUSxJAGIUViwQIhYsQYDRLEmAYhRWLgEAIhYsQYBRFlZWVm4Af+FsASNsQUARAAA ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "data:application/font-woff;charset=utf-8;base64,d09GRgABAAAAAAoUAA4AAAAAEPQAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABPUy8yAAABRAAAAEQAAABWPeFJAWNtYXAAAAGIAAAAOgAAAUrQEhm3Y3Z0IAAAAcQAAAAUAAAAHAZJ/5RmcGdtAAAB2AAABPkAAAmRigp4O2dhc3AAAAbUAAAACAAAAAgAAAAQZ2x5ZgAABtwAAACuAAAAtt9nBHZoZWFkAAAHjAAAADUAAAA2ASs8e2hoZWEAAAfEAAAAIAAAACQHUwNNaG10eAAAB+QAAAAMAAAADAspAABsb2NhAAAH8AAAAAgAAAAIADgAW21heHAAAAf4AAAAIAAAACAApgm8bmFtZQAACBgAAAF3AAACzcydGhxwb3N0AAAJkAAAACoAAAA7rr1AmHByZXAAAAm8AAAAVgAAAFaSoZr/eJxjYGTewTiBgZWBg6mKaQ8DA0MPhGZ8wGDIyMTAwMTAysyAFQSkuaYwOLxgeMHIHPQ/iyGKmZvBHyjMCJIDAPe9C2B4nGNgYGBmgGAZBkYGEHAB8hjBfBYGDSDNBqQZGZgYGF4w/v8PUvCCAURLMELVAwEjG8OIBwBk5AavAAB4nGNgQANGDEbM3P83gjAAELQD4XicnVXZdtNWFJU8ZHASOmSgoA7X3DhQ68qEKRgwaSrFdiEdHAitBB2kDHTkncc+62uOQrtWH/m07n09JLR0rbYsls++R1tn2DrnRhwjKn0aiGvUoZKXA6msPZZK90lc13Uvj5UMBnFdthJPSZuonSRKat3sUC7xWOsqWSdYJ+PlIFZPVZ5noAziFB5lSUQbRBuplyZJ4onjJ4kWZxAfJUkgJaMQp9LIUEI1GsRS1aFM6dCr1xNx00DKRqMedVhU90PFJ8c1p9SsA0YqVznCFevVRr4bpwMve5DEOsGzrYcxHnisfpQqkIqR6cg/dkpOlIaBVHHUoVbi6DCTX/eRTCrNQKaMYkWl7oG43f102xYxPXQ6vi5KlUaqurnOKJrt0fGogygP2cbppNzQ2fbw5RlTVKtdcbPtQGYNXErJbHSfRAAdJlLj6QFONZwCqRn1R8XZ588BEslclKo8VTKHegOZMzt7cTHtbiersnCknwcyb3Z2452HQ6dXh3/R+hdM4cxHj+Jifj5C+lBqfiJOJKVGWMzyp4YfcVcgQrkxiAsXyuBThDl0RdrZZl3jtTH2hs/5SqlhPQna6KP4fgr9TiQrHGdRo/VInM1j13Wt3GdQS7W7Fzsyr0OVIu7vCwuuM+eEYZ4WC1VfnvneBTT/Bohn/EDeNIVL+5YpSrRvm6JMu2iKCu0SVKVdNsUU7YoppmnPmmKG9h1TzNKeMzLj/8vc55H7HN7xkJv2XeSmfQ+5ad9HbtoPkJtWITdtHblpLyA3rUZu2lWjOnYEGgZpF1IVQdA0svph3Fab9UDWjDR8aWDyLmLI+upER521tcofxX914gsHcmmip7siF5viLq/bFj483e6rj5pG3bDV+MaR8jAeRnocmtBZ+c3hv+1N3S6a7jKqMugBFUwKwABl7UAC0zrbCaT1mqf48gdgXIZ4zkpDtVSfO4am7+V5X/exOfG+x+3GLrdcd3kJWdYNcmP28N9SZKrrH+UtrVQnR6wrJ49VaxhDKrwour6SlHu0tRu/KKmy8l6U1srnk5CbPYMbQlu27mGwI0xpyiUeXlOlKD3UUo6yQyxvKco84JSLC1qGxLgOdQ9qa8TpoXoYGwshhqG0vRBwSCldFd+0ynfxHqtr2Oj4xRXh6XpyEhGf4ir7UfBU10b96A7avGbdMoMpVaqn+4xPsa/b9lFZaaSOsxe3VAfXNOsaORXTT+Rr4HRvOGjdAz1UfDRBI1U1x+jGKGM0ljXl3wR0MVZ+w2jVYvs93E+dpFWsuUuY7JsT9+C0u/0q+7WcW0bW/dcGvW3kip8jMb8tCvw7B2K3ZA3UO5OBGAvIWdAYxhYmdxiug23EbfY/Jqf/34aFRXJXOxq7eerD1ZNRJXfZ8rjLTXZZ16M2R9VOGvsIjS0PN+bY4XIstsRgQbb+wf8x7gF3aVEC4NDIZZiI2nShnurh6h6rsW04VxIBds2x43QAegAuQd8cu9bzCYD13CPnLsB9cgh2yCH4lByCz8i5BfA5OQRfkEMwIIdgl5w7AA/IIXhIDsEeOQSPyNkE+JIcgq/IIYjJIUjIuQ3wmByCJ+QQfE0OwTdGrk5k/pYH2QD6zqKbQKmdGhzaOGRGrk3Y+zxY9oFFZB9aROqRkesT6lMeLPV7i0j9wSJSfzRyY0L9iQdL/dkiUn+xiNRnxpeZIymvDp7zjg7+BJfqrV4AAAAAAQAB//8AD3icY2BkAALmJUwzGEQZZBwk+RkZGBmdGJgYmbIYgMwsoGSiiLgIs5A2owg7I5uSOqOaiT2jmZE8I5gQY17C/09BQEfg3yt+fh8gvYQxD0j68DOJiQn8U+DnZxQDcQUEljLmCwBpBgbG/3//b2SOZ+Zm4GEQcuAH2sblDLSEm8FFVJhJEGgLH6OSHpMdo5EcI3Nk0bEXJ/LYqvZ82VXHGFd6pKTkyCsQwQAAq+QkqAAAeJxjYGRgYADiw5VSsfH8Nl8ZuJlfAEUYzpvO6IXQCb7///7fyLyEmRvI5WBgAokCAFb/DJAAAAB4nGNgZGBgDvqfxRDF/IKB4f935iUMQBEUwAwAi5YFpgPoAAAD6AAAA1kAAAAAAAAAOABbAAEAAAADABYAAQAAAAAAAgAGABMAbgAAAC0JkQAAAAB4nHWQy2rCQBSG//HSi0JbWui2sypKabxgN4IgWHTTbqS4LTHGJBIzMhkFX6Pv0IfpS/RZ+puMpShNmMx3vjlz5mQAXOMbAvnzxJGzwBmjnAs4Rc9ykf7Zcon8YrmMKt4sn9C/W67gAYHlKm7wwQqidM5ogU/LAlfi0nIBF+LOcpH+0XKJ3LNcxq14tXxC71muYCJSy1Xci6+BWm11FIRG1gZ12W62OnK6lYoqStxYumsTKp3KvpyrxPhxrBxPLfc89oN17Op9uJ8nvk4jlciW09yrkZ/42jX+bFc93QRtY+ZyrtVSDm2GXGm18D3jhMasuo3G3/MwgMIKW2hEvKoQBhI12jrnNppooUOaMkMyM8+KkMBFTONizR1htpIy7nPMGSW0PjNisgOP3+WRH5MC7o9ZRR+tHsYT0u6MKPOSfTns7jBrREqyTDezs9/eU2x4WpvWcNeuS511JTE8qCF5H7u1BY1H72S3Ymi7aPD95/9+AN1fhEsAeJxjYGKAAC4G7ICZgYGRiZGZMzkjNTk7N7Eomy05syg5J5WBAQBE1QZBAABLuADIUlixAQGOWbkIAAgAYyCwASNEsAMjcLIEKAlFUkSyCgIHKrEGAUSxJAGIUViwQIhYsQYDRLEmAYhRWLgEAIhYsQYBRFlZWVm4Af+FsASNsQUARAAA";

/***/ }),

/***/ "data:application/font-woff;charset=utf-8;base64,d09GRk9UVE8AAASwAAoAAAAABGgAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABDRkYgAAAA9AAAAS0AAAEtFpovuE9TLzIAAAIkAAAAYAAAAGAIIweQY21hcAAAAoQAAABMAAAATA984gpnYXNwAAAC0AAAAAgAAAAIAAAAEGhlYWQAAALYAAAANgAAADb/0IhHaGhlYQAAAxAAAAAkAAAAJAKZAedobXR4AAADNAAAABgAAAAYAm4AEm1heHAAAANMAAAABgAAAAYABlAAbmFtZQAAA1QAAAE8AAABPPC1n05wb3N0AAAEkAAAACAAAAAgAAMAAAEABAQAAQEBB3JhdGluZwABAgABADr4HAL4GwP4GAQeCgAZU/+Lix4KABlT/4uLDAeLa/iU+HQFHQAAAHkPHQAAAH4RHQAAAAkdAAABJBIABwEBBw0PERQZHnJhdGluZ3JhdGluZ3UwdTF1MjB1RjBEOXVGMERBAAACAYkABAAGAQEEBwoNVp38lA78lA78lA77lA773Z33bxWLkI2Qj44I9xT3FAWOj5CNkIuQi4+JjoePiI2Gi4YIi/uUBYuGiYeHiIiHh4mGi4aLho2Ijwj7FPcUBYeOiY+LkAgO+92L5hWL95QFi5CNkI6Oj4+PjZCLkIuQiY6HCPcU+xQFj4iNhouGi4aJh4eICPsU+xQFiIeGiYaLhouHjYePiI6Jj4uQCA74lBT4lBWLDAoAAAAAAwIAAZAABQAAAUwBZgAAAEcBTAFmAAAA9QAZAIQAAAAAAAAAAAAAAAAAAAABEAAAAAAAAAAAAAAAAAAAAABAAADw2gHg/+D/4AHgACAAAAABAAAAAAAAAAAAAAAgAAAAAAACAAAAAwAAABQAAwABAAAAFAAEADgAAAAKAAgAAgACAAEAIPDa//3//wAAAAAAIPDZ//3//wAB/+MPKwADAAEAAAAAAAAAAAAAAAEAAf//AA8AAQAAAAEAADfYOJZfDzz1AAsCAAAAAADP/aPuAAAAAM/9o+4AAAAAALcBbgAAAAgAAgAAAAAAAAABAAAB4P/gAAACAAAAAAAAtwABAAAAAAAAAAAAAAAAAAAABgAAAAAAAAAAAAAAAAEAAAAAtwASALcAAAAAUAAABgAAAAAADgCuAAEAAAAAAAEADAAAAAEAAAAAAAIADgBAAAEAAAAAAAMADAAiAAEAAAAAAAQADABOAAEAAAAAAAUAFgAMAAEAAAAAAAYABgAuAAEAAAAAAAoANABaAAMAAQQJAAEADAAAAAMAAQQJAAIADgBAAAMAAQQJAAMADAAiAAMAAQQJAAQADABOAAMAAQQJAAUAFgAMAAMAAQQJAAYADAA0AAMAAQQJAAoANABaAHIAYQB0AGkAbgBnAFYAZQByAHMAaQBvAG4AIAAxAC4AMAByAGEAdABpAG4AZ3JhdGluZwByAGEAdABpAG4AZwBSAGUAZwB1AGwAYQByAHIAYQB0AGkAbgBnAEYAbwBuAHQAIABnAGUAbgBlAHIAYQB0AGUAZAAgAGIAeQAgAEkAYwBvAE0AbwBvAG4ALgADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** data:application/font-woff;charset=utf-8;base64,d09GRk9UVE8AAASwAAoAAAAABGgAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABDRkYgAAAA9AAAAS0AAAEtFpovuE9TLzIAAAIkAAAAYAAAAGAIIweQY21hcAAAAoQAAABMAAAATA984gpnYXNwAAAC0AAAAAgAAAAIAAAAEGhlYWQAAALYAAAANgAAADb/0IhHaGhlYQAAAxAAAAAkAAAAJAKZAedobXR4AAADNAAAABgAAAAYAm4AEm1heHAAAANMAAAABgAAAAYABlAAbmFtZQAAA1QAAAE8AAABPPC1n05wb3N0AAAEkAAAACAAAAAgAAMAAAEABAQAAQEBB3JhdGluZwABAgABADr4HAL4GwP4GAQeCgAZU/+Lix4KABlT/4uLDAeLa/iU+HQFHQAAAHkPHQAAAH4RHQAAAAkdAAABJBIABwEBBw0PERQZHnJhdGluZ3JhdGluZ3UwdTF1MjB1RjBEOXVGMERBAAACAYkABAAGAQEEBwoNVp38lA78lA78lA77lA773Z33bxWLkI2Qj44I9xT3FAWOj5CNkIuQi4+JjoePiI2Gi4YIi/uUBYuGiYeHiIiHh4mGi4aLho2Ijwj7FPcUBYeOiY+LkAgO+92L5hWL95QFi5CNkI6Oj4+PjZCLkIuQiY6HCPcU+xQFj4iNhouGi4aJh4eICPsU+xQFiIeGiYaLhouHjYePiI6Jj4uQCA74lBT4lBWLDAoAAAAAAwIAAZAABQAAAUwBZgAAAEcBTAFmAAAA9QAZAIQAAAAAAAAAAAAAAAAAAAABEAAAAAAAAAAAAAAAAAAAAABAAADw2gHg/+D/4AHgACAAAAABAAAAAAAAAAAAAAAgAAAAAAACAAAAAwAAABQAAwABAAAAFAAEADgAAAAKAAgAAgACAAEAIPDa//3//wAAAAAAIPDZ//3//wAB/+MPKwADAAEAAAAAAAAAAAAAAAEAAf//AA8AAQAAAAEAADfYOJZfDzz1AAsCAAAAAADP/aPuAAAAAM/9o+4AAAAAALcBbgAAAAgAAgAAAAAAAAABAAAB4P/gAAACAAAAAAAAtwABAAAAAAAAAAAAAAAAAAAABgAAAAAAAAAAAAAAAAEAAAAAtwASALcAAAAAUAAABgAAAAAADgCuAAEAAAAAAAEADAAAAAEAAAAAAAIADgBAAAEAAAAAAAMADAAiAAEAAAAAAAQADABOAAEAAAAAAAUAFgAMAAEAAAAAAAYABgAuAAEAAAAAAAoANABaAAMAAQQJAAEADAAAAAMAAQQJAAIADgBAAAMAAQQJAAMADAAiAAMAAQQJAAQADABOAAMAAQQJAAUAFgAMAAMAAQQJAAYADAA0AAMAAQQJAAoANABaAHIAYQB0AGkAbgBnAFYAZQByAHMAaQBvAG4AIAAxAC4AMAByAGEAdABpAG4AZ3JhdGluZwByAGEAdABpAG4AZwBSAGUAZwB1AGwAYQByAHIAYQB0AGkAbgBnAEYAbwBuAHQAIABnAGUAbgBlAHIAYQB0AGUAZAAgAGIAeQAgAEkAYwBvAE0AbwBvAG4ALgADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "data:application/font-woff;charset=utf-8;base64,d09GRk9UVE8AAASwAAoAAAAABGgAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABDRkYgAAAA9AAAAS0AAAEtFpovuE9TLzIAAAIkAAAAYAAAAGAIIweQY21hcAAAAoQAAABMAAAATA984gpnYXNwAAAC0AAAAAgAAAAIAAAAEGhlYWQAAALYAAAANgAAADb/0IhHaGhlYQAAAxAAAAAkAAAAJAKZAedobXR4AAADNAAAABgAAAAYAm4AEm1heHAAAANMAAAABgAAAAYABlAAbmFtZQAAA1QAAAE8AAABPPC1n05wb3N0AAAEkAAAACAAAAAgAAMAAAEABAQAAQEBB3JhdGluZwABAgABADr4HAL4GwP4GAQeCgAZU/+Lix4KABlT/4uLDAeLa/iU+HQFHQAAAHkPHQAAAH4RHQAAAAkdAAABJBIABwEBBw0PERQZHnJhdGluZ3JhdGluZ3UwdTF1MjB1RjBEOXVGMERBAAACAYkABAAGAQEEBwoNVp38lA78lA78lA77lA773Z33bxWLkI2Qj44I9xT3FAWOj5CNkIuQi4+JjoePiI2Gi4YIi/uUBYuGiYeHiIiHh4mGi4aLho2Ijwj7FPcUBYeOiY+LkAgO+92L5hWL95QFi5CNkI6Oj4+PjZCLkIuQiY6HCPcU+xQFj4iNhouGi4aJh4eICPsU+xQFiIeGiYaLhouHjYePiI6Jj4uQCA74lBT4lBWLDAoAAAAAAwIAAZAABQAAAUwBZgAAAEcBTAFmAAAA9QAZAIQAAAAAAAAAAAAAAAAAAAABEAAAAAAAAAAAAAAAAAAAAABAAADw2gHg/+D/4AHgACAAAAABAAAAAAAAAAAAAAAgAAAAAAACAAAAAwAAABQAAwABAAAAFAAEADgAAAAKAAgAAgACAAEAIPDa//3//wAAAAAAIPDZ//3//wAB/+MPKwADAAEAAAAAAAAAAAAAAAEAAf//AA8AAQAAAAEAADfYOJZfDzz1AAsCAAAAAADP/aPuAAAAAM/9o+4AAAAAALcBbgAAAAgAAgAAAAAAAAABAAAB4P/gAAACAAAAAAAAtwABAAAAAAAAAAAAAAAAAAAABgAAAAAAAAAAAAAAAAEAAAAAtwASALcAAAAAUAAABgAAAAAADgCuAAEAAAAAAAEADAAAAAEAAAAAAAIADgBAAAEAAAAAAAMADAAiAAEAAAAAAAQADABOAAEAAAAAAAUAFgAMAAEAAAAAAAYABgAuAAEAAAAAAAoANABaAAMAAQQJAAEADAAAAAMAAQQJAAIADgBAAAMAAQQJAAMADAAiAAMAAQQJAAQADABOAAMAAQQJAAUAFgAMAAMAAQQJAAYADAA0AAMAAQQJAAoANABaAHIAYQB0AGkAbgBnAFYAZQByAHMAaQBvAG4AIAAxAC4AMAByAGEAdABpAG4AZ3JhdGluZwByAGEAdABpAG4AZwBSAGUAZwB1AGwAYQByAHIAYQB0AGkAbgBnAEYAbwBuAHQAIABnAGUAbgBlAHIAYQB0AGUAZAAgAGIAeQAgAEkAYwBvAE0AbwBvAG4ALgADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";

/***/ }),

/***/ "data:application/font-woff;charset=utf-8;base64,d09GRk9UVE8AABcUAAoAAAAAFswAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABDRkYgAAAA9AAAEuEAABLho6TvIE9TLzIAABPYAAAAYAAAAGAIIwgbY21hcAAAFDgAAACkAAAApKPambxnYXNwAAAU3AAAAAgAAAAIAAAAEGhlYWQAABTkAAAANgAAADYBGAe5aGhlYQAAFRwAAAAkAAAAJAPiAf1obXR4AAAVQAAAAHAAAABwLOAAQ21heHAAABWwAAAABgAAAAYAHFAAbmFtZQAAFbgAAAE8AAABPPC1n05wb3N0AAAW9AAAACAAAAAgAAMAAAEABAQAAQEBB3JhdGluZwABAgABADr4HAL4GwP4GAQeCgAZU/+Lix4KABlT/4uLDAeLZviU+HQFHQAAAP0PHQAAAQIRHQAAAAkdAAAS2BIAHQEBBw0PERQZHiMoLTI3PEFGS1BVWl9kaW5zeH2Ch4xyYXRpbmdyYXRpbmd1MHUxdTIwdUU2MDB1RTYwMXVFNjAydUU2MDN1RTYwNHVFNjA1dUYwMDR1RjAwNXVGMDA2dUYwMEN1RjAwRHVGMDIzdUYwMkV1RjA2RXVGMDcwdUYwODd1RjA4OHVGMDg5dUYwOEF1RjA5N3VGMDlDdUYxMjN1RjE2NHVGMTY1AAACAYkAGgAcAgABAAQABwAKAA0AVgCWAL0BAgGMAeQCbwLwA4cD5QR0BQMFdgZgB8MJkQtxC7oM2Q1jDggOmRAYEZr8lA78lA78lA77lA74lPetFftFpTz3NDz7NPtFcfcU+xBt+0T3Mt73Mjht90T3FPcQBfuU+0YV+wRRofcQMOP3EZ3D9wXD+wX3EXkwM6H7EPsExQUO+JT3rRX7RaU89zQ8+zT7RXH3FPsQbftE9zLe9zI4bfdE9xT3EAX7lPtGFYuLi/exw/sF9xF5MDOh+xD7BMUFDviU960V+0WlPPc0PPs0+0Vx9xT7EG37RPcy3vcyOG33RPcU9xAFDviU98EVi2B4ZG5wCIuL+zT7NAV7e3t7e4t7i3ube5sI+zT3NAVupniyi7aL3M3N3Iu2i7J4pm6mqLKetovci81JizoIDviU98EVi9xJzTqLYItkeHBucKhknmCLOotJSYs6i2CeZKhwCIuL9zT7NAWbe5t7m4ubi5ubm5sI9zT3NAWopp6yi7YIME0V+zb7NgWKioqKiouKi4qMiowI+zb3NgV6m4Ghi6OLubCwuYuji6GBm3oIule6vwWbnKGVo4u5i7Bmi12Lc4F1ensIDviU98EVi2B4ZG5wCIuL+zT7NAV7e3t7e4t7i3ube5sI+zT3NAVupniyi7aL3M3N3Iuni6WDoX4IXED3BEtL+zT3RPdU+wTLssYFl46YjZiL3IvNSYs6CA6L98UVi7WXrKOio6Otl7aLlouXiZiHl4eWhZaEloSUhZKFk4SShZKEkpKSkZOSkpGUkZaSCJaSlpGXj5iPl42Wi7aLrX+jc6N0l2qLYYthdWBgYAj7RvtABYeIh4mGi4aLh42Hjgj7RvdABYmNiY2Hj4iOhpGDlISUhZWFlIWVhpaHmYaYiZiLmAgOZ4v3txWLkpCPlo0I9yOgzPcWBY6SkI+Ri5CLkIePhAjL+xb3I3YFlomQh4uEi4aJh4aGCCMmpPsjBYuKi4mLiIuHioiJiImIiIqHi4iLh4yHjQj7FM/7FUcFh4mHioiLh4uIjImOiY6KjouPi4yLjYyOCKP3IyPwBYaQiZCLjwgOZ4v3txWLkpCPlo0I9yOgzPcWBY6SkI+Ri5CLkIePhAjL+xb3I3YFlomQh4uEi4aJh4aGCCMmpPsjBYuKi4mLiIuCh4aDi4iLh4yHjQj7FM/7FUcFh4mHioiLh4uIjImOiY6KjouPi4yLjYyOCKP3IyPwBYaQiZCLjwjKeRXjN3b7DfcAxPZSd/cN4t/7DJ1V9wFV+wEFDq73ZhWLk42RkZEIsbIFkZCRjpOLkouSiJCGCN8291D3UAWQkJKOkouTi5GIkYYIsWQFkYaNhIuEi4OJhYWFCPuJ+4kFhYWFiYOLhIuEjYaRCPsi9yIFhZCJkouSCA77AartFYuSjpKQkAjf3zffBYaQiJKLk4uSjpKQkAiysgWRkJGOk4uSi5KIkIYI3zff3wWQkJKOk4uSi5KIkIYIsmQFkIaOhIuEi4OIhIaGCDc33zcFkIaOhIuEi4OIhYaFCGRkBYaGhIiEi4OLhI6GkAg33zc3BYaGhIiEi4OLhY6FkAhksgWGkYiRi5MIDvtLi8sVi/c5BYuSjpKQkJCQko6SiwiVi4vCBYuul6mkpKSkqpiui66LqX6kcqRymG2LaAiLVJSLBZKLkoiQhpCGjoSLhAiL+zkFi4OIhYaGhoWEiYSLCPuniwWEi4SNhpGGkIiRi5MI5vdUFfcni4vCBYufhJx8mn2ZepJ3i3aLeoR9fX18g3qLdwiLVAUO+yaLshWL+AQFi5GNkY+RjpCQj5KNj42PjI+LCPfAiwWPi4+Kj4mRiZCHj4aPhY2Fi4UIi/wEBYuEiYWHhoeGhoeFiIiKhoqHi4GLhI6EkQj7EvcN+xL7DQWEhYOIgouHi4eLh42EjoaPiJCHkImRi5IIDov3XRWLko2Rj5Kltq+vuKW4pbuZvYu9i7t9uHG4ca9npWCPhI2Fi4SLhYmEh4RxYGdoXnAIXnFbflmLWYtbmF6lXqZnrnG2h5KJkouRCLCLFaRkq2yxdLF0tH+4i7iLtJexorGiq6qksm64Z61goZZ3kXaLdItnfm1ycnJybX9oiwhoi22XcqRypH6pi6+LopGglp9gdWdpbl4I9xiwFYuHjIiOiI6IjoqPi4+LjoyOjo2OjY6Lj4ubkJmXl5eWmZGbi4+LjoyOjo2OjY6LjwiLj4mOiY6IjYiNh4tzi3eCenp6eoJ3i3MIDov3XRWLko2Sj5GouK+utqW3pbqYvouci5yJnIgIm6cFjY6NjI+LjIuNi42JjYqOio+JjomOiY6KjomOiY6JjoqNioyKjomMiYuHi4qLiouLCHdnbVVjQ2NDbVV3Zwh9cgWJiIiJiIuJi36SdJiIjYmOi46LjY+UlJlvl3KcdJ90oHeie6WHkYmSi5IIsIsVqlq0Z711CKGzBXqXfpqCnoKdhp6LoIuikaCWn2B1Z2luXgj3GLAVi4eMiI6IjoiOio+Lj4uOjI6OjY6NjouPi5uQmZeXl5aZkZuLj4uOjI6OjY6NjouPCIuPiY6JjoiNiI2Hi3OLd4J6enp6gneLcwji+10VoLAFtI+wmK2hrqKnqKKvdq1wp2uhCJ2rBZ1/nHycepx6mHqWeY+EjYWLhIuEiYWHhIR/gH1+fG9qaXJmeWV5Y4Jhiwi53BXb9yQFjIKMg4uEi3CDc3x1fHV3fHOBCA6L1BWL90sFi5WPlJKSkpKTj5aLCNmLBZKPmJqepJaZlZeVlY+Qj5ONl42WjpeOmI+YkZWTk5OSk46Vi5uLmYiYhZiFlIGSfgiSfo55i3WLeYd5gXgIvosFn4uchJl8mn2Seot3i3qGfIJ9jYSLhYuEi3yIfoR+i4eLh4uHi3eGen99i3CDdnt8CHt8dYNwiwhmiwV5i3mNeY95kHeRc5N1k36Ph4sIOYsFgIuDjoSShJKHlIuVCLCdFYuGjIePiI+Hj4mQi5CLj42Pj46OjY+LkIuQiZCIjoePh42Gi4aLh4mHh4eIioaLhgjUeRWUiwWNi46Lj4qOi4+KjYqOi4+Kj4mQio6KjYqNio+Kj4mQio6KjIqzfquEpIsIrosFr4uemouri5CKkYqQkY6QkI6SjpKNkouSi5KJkoiRlZWQlouYi5CKkImRiZGJj4iOCJGMkI+PlI+UjZKLkouViJODk4SSgo+CiwgmiwWLlpCalJ6UnpCbi5aLnoiYhJSFlH+QeYuGhoeDiYCJf4h/h3+IfoWBg4KHh4SCgH4Ii4qIiYiGh4aIh4mIiIiIh4eGh4aHh4eHiIiHiIeHiIiHiIeKh4mIioiLCIKLi/tLBQ6L90sVi/dLBYuVj5OSk5KSk46WiwjdiwWPi5iPoZOkk6CRnZCdj56Nn4sIq4sFpougg5x8m3yTd4txCIuJBZd8kHuLd4uHi4eLh5J+jn6LfIuEi4SJhZR9kHyLeot3hHp8fH19eoR3iwhYiwWVeI95i3mLdIh6hH6EfoKBfoV+hX2He4uBi4OPg5KFkYaTh5SHlYiTipOKk4qTiJMIiZSIkYiPgZSBl4CaeKR+moSPCD2LBYCLg4+EkoSSh5SLlQiw9zgVi4aMh4+Ij4ePiZCLkIuPjY+Pjo6Nj4uQi5CJkIiOh4+HjYaLhouHiYeHh4iKhouGCNT7OBWUiwWOi46Kj4mPio+IjoiPh4+IjoePiI+Hj4aPho6HjoiNiI6Hj4aOho6Ii4qWfpKDj4YIk4ORgY5+j36OgI1/jYCPg5CGnYuXj5GUkpSOmYuei5aGmoKfgp6GmouWCPCLBZSLlI+SkpOTjpOLlYuSiZKHlIeUho+Fi46PjY+NkY2RjJCLkIuYhpaBlY6RjZKLkgiLkomSiJKIkoaQhY6MkIyRi5CLm4aXgpOBkn6Pe4sIZosFcotrhGN9iouIioaJh4qHiomKiYqIioaKh4mHioiKiYuHioiLh4qIi4mLCIKLi/tLBQ77lIv3txWLkpCPlo0I9yOgzPcWBY6SkI+RiwiL/BL7FUcFh4mHioiLh4uIjImOiY6KjouPi4yLjYyOCKP3IyPwBYaQiZCLjwgOi/fFFYu1l6yjoqOjrZe2i5aLl4mYh5eHloWWhJaElIWShZOEkoWShJKSkpGTkpKRlJGWkgiWkpaRl4+Yj5eNlou2i61/o3OjdJdqi2GLYXVgYGAI+0b7QAWHiIeJhouGi4eNh44I+0b3QAWJjYmNh4+IjoaRg5SElIWVhZSFlYaWh5mGmImYi5gIsIsVi2ucaa9oCPc6+zT3OvczBa+vnK2Lq4ubiZiHl4eXhpSFkoSSg5GCj4KQgo2CjYONgYuBi4KLgIl/hoCGgIWChAiBg4OFhISEhYaFhoaIhoaJhYuFi4aNiJCGkIaRhJGEkoORgZOCkoCRgJB/kICNgosIgYuBi4OJgomCiYKGgoeDhYSEhYSGgod/h3+Jfot7CA77JouyFYv4BAWLkY2Rj5GOkJCPko2PjY+Mj4sI98CLBY+Lj4qPiZGJkIePho+FjYWLhQiL/AQFi4SJhYeGh4aGh4WIiIqGioeLgYuEjoSRCPsS9w37EvsNBYSFg4iCi4eLh4uHjYSOho+IkIeQiZGLkgiwkxX3JvchpHL3DfsIi/f3+7iLi/v3BQ5ni8sVi/c5BYuSjpKQkJCQko6Siwj3VIuLwgWLrpippKSkpKmYrouvi6l+pHKkcpdti2gIi0IFi4aKhoeIh4eHiYaLCHmLBYaLh42Hj4eOipCLkAiL1AWLn4OcfZp9mXqSdot3i3qEfX18fIR6i3cIi1SniwWSi5KIkIaQho6Ei4QIi/s5BYuDiIWGhoaFhImEiwj7p4sFhIuEjYaRhpCIkYuTCA5njPe6FYyQkI6UjQj3I6DM9xYFj5KPj5GLkIuQh4+ECMv7FvcjdgWUiZCIjYaNhoiFhYUIIyak+yMFjIWKhomHiYiIiYaLiIuHjIeNCPsUz/sVRwWHiYeKiIuHi4eNiY6Jj4uQjJEIo/cjI/AFhZGJkY2QCPeB+z0VnILlW3rxiJ6ZmNTS+wydgpxe54v7pwUOZ4vCFYv3SwWLkI2Pjo+Pjo+NkIsI3osFkIuPiY6Ij4eNh4uGCIv7SwWLhomHh4eIh4eKhosIOIsFhouHjIePiI+Jj4uQCLCvFYuGjIePh46IkImQi5CLj42Pjo6PjY+LkIuQiZCIjoePh42Gi4aLhomIh4eIioaLhgjvZxWL90sFi5CNj46Oj4+PjZCLj4ySkJWWlZaVl5SXmJuVl5GRjo6OkI6RjZCNkIyPjI6MkY2TCIySjJGMj4yPjZCOkY6RjpCPjo6Pj42Qi5SLk4qSiZKJkYiPiJCIjoiPho6GjYeMhwiNh4yGjIaMhYuHi4iLiIuHi4eLg4uEiYSJhImFiYeJh4mFh4WLioqJiomJiIqJiokIi4qKiIqJCNqLBZqLmIWWgJaAkH+LfIt6hn2Af46DjYSLhIt9h36Cf4+Bi3+HgImAhYKEhI12hnmAfgh/fXiDcosIZosFfot+jHyOfI5/joOOg41/j32Qc5N8j4SMhouHjYiOh4+Jj4uQCA5ni/c5FYuGjYaOiI+Hj4mQiwjeiwWQi4+Njo+Pjo2Qi5AIi/dKBYuQiZCHjoiPh42Giwg4iwWGi4eJh4eIiImGi4YIi/tKBbD3JhWLkIyPj4+OjpCNkIuQi4+Jj4iOh42Hi4aLhomHiIeHh4eKhouGi4aMiI+Hj4qPi5AI7/snFYv3SwWLkI2Qj46Oj4+NkIuSi5qPo5OZkJePk46TjZeOmo6ajpiMmIsIsIsFpIueg5d9ln6Qeol1koSRgo2Aj4CLgIeAlH+Pfot9i4WJhIiCloCQfIt7i3yFfoGACICAfoZ8iwg8iwWMiIyJi4mMiYyJjYmMiIyKi4mPhI2GjYeNh42GjYOMhIyEi4SLhouHi4iLiYuGioYIioWKhomHioeJh4iGh4eIh4aIh4iFiISJhImDioKLhouHjYiPh4+Ij4iRiJGJkIqPCIqPipGKkomTipGKj4qOiZCJkYiQiJCIjoWSgZZ+nIKXgZaBloGWhJGHi4aLh42HjwiIjomQi48IDviUFPiUFYsMCgAAAAADAgABkAAFAAABTAFmAAAARwFMAWYAAAD1ABkAhAAAAAAAAAAAAAAAAAAAAAEQAAAAAAAAAAAAAAAAAAAAAEAAAPFlAeD/4P/gAeAAIAAAAAEAAAAAAAAAAAAAACAAAAAAAAIAAAADAAAAFAADAAEAAAAUAAQAkAAAACAAIAAEAAAAAQAg5gXwBvAN8CPwLvBu8HDwivCX8JzxI/Fl//3//wAAAAAAIOYA8ATwDPAj8C7wbvBw8Ifwl/Cc8SPxZP/9//8AAf/jGgQQBhABD+wP4g+jD6IPjA+AD3wO9g62AAMAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAf//AA8AAQAAAAEAAJrVlLJfDzz1AAsCAAAAAADP/GODAAAAAM/8Y4MAAP/bAgAB2wAAAAgAAgAAAAAAAAABAAAB4P/gAAACAAAAAAACAAABAAAAAAAAAAAAAAAAAAAAHAAAAAAAAAAAAAAAAAEAAAACAAAAAgAAAAIAAAACAAAAAgAAAAIAAAACAAAAAdwAAAHcAAACAAAjAZMAHwFJAAABbgAAAgAAAAIAAAACAAAAAgAAAAEAAAACAAAAAW4AAAHcAAAB3AABAdwAAAHcAAAAAFAAABwAAAAAAA4ArgABAAAAAAABAAwAAAABAAAAAAACAA4AQAABAAAAAAADAAwAIgABAAAAAAAEAAwATgABAAAAAAAFABYADAABAAAAAAAGAAYALgABAAAAAAAKADQAWgADAAEECQABAAwAAAADAAEECQACAA4AQAADAAEECQADAAwAIgADAAEECQAEAAwATgADAAEECQAFABYADAADAAEECQAGAAwANAADAAEECQAKADQAWgByAGEAdABpAG4AZwBWAGUAcgBzAGkAbwBuACAAMQAuADAAcgBhAHQAaQBuAGdyYXRpbmcAcgBhAHQAaQBuAGcAUgBlAGcAdQBsAGEAcgByAGEAdABpAG4AZwBGAG8AbgB0ACAAZwBlAG4AZQByAGEAdABlAGQAIABiAHkAIABJAGMAbwBNAG8AbwBuAC4AAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** data:application/font-woff;charset=utf-8;base64,d09GRk9UVE8AABcUAAoAAAAAFswAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABDRkYgAAAA9AAAEuEAABLho6TvIE9TLzIAABPYAAAAYAAAAGAIIwgbY21hcAAAFDgAAACkAAAApKPambxnYXNwAAAU3AAAAAgAAAAIAAAAEGhlYWQAABTkAAAANgAAADYBGAe5aGhlYQAAFRwAAAAkAAAAJAPiAf1obXR4AAAVQAAAAHAAAABwLOAAQ21heHAAABWwAAAABgAAAAYAHFAAbmFtZQAAFbgAAAE8AAABPPC1n05wb3N0AAAW9AAAACAAAAAgAAMAAAEABAQAAQEBB3JhdGluZwABAgABADr4HAL4GwP4GAQeCgAZU/+Lix4KABlT/4uLDAeLZviU+HQFHQAAAP0PHQAAAQIRHQAAAAkdAAAS2BIAHQEBBw0PERQZHiMoLTI3PEFGS1BVWl9kaW5zeH2Ch4xyYXRpbmdyYXRpbmd1MHUxdTIwdUU2MDB1RTYwMXVFNjAydUU2MDN1RTYwNHVFNjA1dUYwMDR1RjAwNXVGMDA2dUYwMEN1RjAwRHVGMDIzdUYwMkV1RjA2RXVGMDcwdUYwODd1RjA4OHVGMDg5dUYwOEF1RjA5N3VGMDlDdUYxMjN1RjE2NHVGMTY1AAACAYkAGgAcAgABAAQABwAKAA0AVgCWAL0BAgGMAeQCbwLwA4cD5QR0BQMFdgZgB8MJkQtxC7oM2Q1jDggOmRAYEZr8lA78lA78lA77lA74lPetFftFpTz3NDz7NPtFcfcU+xBt+0T3Mt73Mjht90T3FPcQBfuU+0YV+wRRofcQMOP3EZ3D9wXD+wX3EXkwM6H7EPsExQUO+JT3rRX7RaU89zQ8+zT7RXH3FPsQbftE9zLe9zI4bfdE9xT3EAX7lPtGFYuLi/exw/sF9xF5MDOh+xD7BMUFDviU960V+0WlPPc0PPs0+0Vx9xT7EG37RPcy3vcyOG33RPcU9xAFDviU98EVi2B4ZG5wCIuL+zT7NAV7e3t7e4t7i3ube5sI+zT3NAVupniyi7aL3M3N3Iu2i7J4pm6mqLKetovci81JizoIDviU98EVi9xJzTqLYItkeHBucKhknmCLOotJSYs6i2CeZKhwCIuL9zT7NAWbe5t7m4ubi5ubm5sI9zT3NAWopp6yi7YIME0V+zb7NgWKioqKiouKi4qMiowI+zb3NgV6m4Ghi6OLubCwuYuji6GBm3oIule6vwWbnKGVo4u5i7Bmi12Lc4F1ensIDviU98EVi2B4ZG5wCIuL+zT7NAV7e3t7e4t7i3ube5sI+zT3NAVupniyi7aL3M3N3Iuni6WDoX4IXED3BEtL+zT3RPdU+wTLssYFl46YjZiL3IvNSYs6CA6L98UVi7WXrKOio6Otl7aLlouXiZiHl4eWhZaEloSUhZKFk4SShZKEkpKSkZOSkpGUkZaSCJaSlpGXj5iPl42Wi7aLrX+jc6N0l2qLYYthdWBgYAj7RvtABYeIh4mGi4aLh42Hjgj7RvdABYmNiY2Hj4iOhpGDlISUhZWFlIWVhpaHmYaYiZiLmAgOZ4v3txWLkpCPlo0I9yOgzPcWBY6SkI+Ri5CLkIePhAjL+xb3I3YFlomQh4uEi4aJh4aGCCMmpPsjBYuKi4mLiIuHioiJiImIiIqHi4iLh4yHjQj7FM/7FUcFh4mHioiLh4uIjImOiY6KjouPi4yLjYyOCKP3IyPwBYaQiZCLjwgOZ4v3txWLkpCPlo0I9yOgzPcWBY6SkI+Ri5CLkIePhAjL+xb3I3YFlomQh4uEi4aJh4aGCCMmpPsjBYuKi4mLiIuCh4aDi4iLh4yHjQj7FM/7FUcFh4mHioiLh4uIjImOiY6KjouPi4yLjYyOCKP3IyPwBYaQiZCLjwjKeRXjN3b7DfcAxPZSd/cN4t/7DJ1V9wFV+wEFDq73ZhWLk42RkZEIsbIFkZCRjpOLkouSiJCGCN8291D3UAWQkJKOkouTi5GIkYYIsWQFkYaNhIuEi4OJhYWFCPuJ+4kFhYWFiYOLhIuEjYaRCPsi9yIFhZCJkouSCA77AartFYuSjpKQkAjf3zffBYaQiJKLk4uSjpKQkAiysgWRkJGOk4uSi5KIkIYI3zff3wWQkJKOk4uSi5KIkIYIsmQFkIaOhIuEi4OIhIaGCDc33zcFkIaOhIuEi4OIhYaFCGRkBYaGhIiEi4OLhI6GkAg33zc3BYaGhIiEi4OLhY6FkAhksgWGkYiRi5MIDvtLi8sVi/c5BYuSjpKQkJCQko6SiwiVi4vCBYuul6mkpKSkqpiui66LqX6kcqRymG2LaAiLVJSLBZKLkoiQhpCGjoSLhAiL+zkFi4OIhYaGhoWEiYSLCPuniwWEi4SNhpGGkIiRi5MI5vdUFfcni4vCBYufhJx8mn2ZepJ3i3aLeoR9fX18g3qLdwiLVAUO+yaLshWL+AQFi5GNkY+RjpCQj5KNj42PjI+LCPfAiwWPi4+Kj4mRiZCHj4aPhY2Fi4UIi/wEBYuEiYWHhoeGhoeFiIiKhoqHi4GLhI6EkQj7EvcN+xL7DQWEhYOIgouHi4eLh42EjoaPiJCHkImRi5IIDov3XRWLko2Rj5Kltq+vuKW4pbuZvYu9i7t9uHG4ca9npWCPhI2Fi4SLhYmEh4RxYGdoXnAIXnFbflmLWYtbmF6lXqZnrnG2h5KJkouRCLCLFaRkq2yxdLF0tH+4i7iLtJexorGiq6qksm64Z61goZZ3kXaLdItnfm1ycnJybX9oiwhoi22XcqRypH6pi6+LopGglp9gdWdpbl4I9xiwFYuHjIiOiI6IjoqPi4+LjoyOjo2OjY6Lj4ubkJmXl5eWmZGbi4+LjoyOjo2OjY6LjwiLj4mOiY6IjYiNh4tzi3eCenp6eoJ3i3MIDov3XRWLko2Sj5GouK+utqW3pbqYvouci5yJnIgIm6cFjY6NjI+LjIuNi42JjYqOio+JjomOiY6KjomOiY6JjoqNioyKjomMiYuHi4qLiouLCHdnbVVjQ2NDbVV3Zwh9cgWJiIiJiIuJi36SdJiIjYmOi46LjY+UlJlvl3KcdJ90oHeie6WHkYmSi5IIsIsVqlq0Z711CKGzBXqXfpqCnoKdhp6LoIuikaCWn2B1Z2luXgj3GLAVi4eMiI6IjoiOio+Lj4uOjI6OjY6NjouPi5uQmZeXl5aZkZuLj4uOjI6OjY6NjouPCIuPiY6JjoiNiI2Hi3OLd4J6enp6gneLcwji+10VoLAFtI+wmK2hrqKnqKKvdq1wp2uhCJ2rBZ1/nHycepx6mHqWeY+EjYWLhIuEiYWHhIR/gH1+fG9qaXJmeWV5Y4Jhiwi53BXb9yQFjIKMg4uEi3CDc3x1fHV3fHOBCA6L1BWL90sFi5WPlJKSkpKTj5aLCNmLBZKPmJqepJaZlZeVlY+Qj5ONl42WjpeOmI+YkZWTk5OSk46Vi5uLmYiYhZiFlIGSfgiSfo55i3WLeYd5gXgIvosFn4uchJl8mn2Seot3i3qGfIJ9jYSLhYuEi3yIfoR+i4eLh4uHi3eGen99i3CDdnt8CHt8dYNwiwhmiwV5i3mNeY95kHeRc5N1k36Ph4sIOYsFgIuDjoSShJKHlIuVCLCdFYuGjIePiI+Hj4mQi5CLj42Pj46OjY+LkIuQiZCIjoePh42Gi4aLh4mHh4eIioaLhgjUeRWUiwWNi46Lj4qOi4+KjYqOi4+Kj4mQio6KjYqNio+Kj4mQio6KjIqzfquEpIsIrosFr4uemouri5CKkYqQkY6QkI6SjpKNkouSi5KJkoiRlZWQlouYi5CKkImRiZGJj4iOCJGMkI+PlI+UjZKLkouViJODk4SSgo+CiwgmiwWLlpCalJ6UnpCbi5aLnoiYhJSFlH+QeYuGhoeDiYCJf4h/h3+IfoWBg4KHh4SCgH4Ii4qIiYiGh4aIh4mIiIiIh4eGh4aHh4eHiIiHiIeHiIiHiIeKh4mIioiLCIKLi/tLBQ6L90sVi/dLBYuVj5OSk5KSk46WiwjdiwWPi5iPoZOkk6CRnZCdj56Nn4sIq4sFpougg5x8m3yTd4txCIuJBZd8kHuLd4uHi4eLh5J+jn6LfIuEi4SJhZR9kHyLeot3hHp8fH19eoR3iwhYiwWVeI95i3mLdIh6hH6EfoKBfoV+hX2He4uBi4OPg5KFkYaTh5SHlYiTipOKk4qTiJMIiZSIkYiPgZSBl4CaeKR+moSPCD2LBYCLg4+EkoSSh5SLlQiw9zgVi4aMh4+Ij4ePiZCLkIuPjY+Pjo6Nj4uQi5CJkIiOh4+HjYaLhouHiYeHh4iKhouGCNT7OBWUiwWOi46Kj4mPio+IjoiPh4+IjoePiI+Hj4aPho6HjoiNiI6Hj4aOho6Ii4qWfpKDj4YIk4ORgY5+j36OgI1/jYCPg5CGnYuXj5GUkpSOmYuei5aGmoKfgp6GmouWCPCLBZSLlI+SkpOTjpOLlYuSiZKHlIeUho+Fi46PjY+NkY2RjJCLkIuYhpaBlY6RjZKLkgiLkomSiJKIkoaQhY6MkIyRi5CLm4aXgpOBkn6Pe4sIZosFcotrhGN9iouIioaJh4qHiomKiYqIioaKh4mHioiKiYuHioiLh4qIi4mLCIKLi/tLBQ77lIv3txWLkpCPlo0I9yOgzPcWBY6SkI+RiwiL/BL7FUcFh4mHioiLh4uIjImOiY6KjouPi4yLjYyOCKP3IyPwBYaQiZCLjwgOi/fFFYu1l6yjoqOjrZe2i5aLl4mYh5eHloWWhJaElIWShZOEkoWShJKSkpGTkpKRlJGWkgiWkpaRl4+Yj5eNlou2i61/o3OjdJdqi2GLYXVgYGAI+0b7QAWHiIeJhouGi4eNh44I+0b3QAWJjYmNh4+IjoaRg5SElIWVhZSFlYaWh5mGmImYi5gIsIsVi2ucaa9oCPc6+zT3OvczBa+vnK2Lq4ubiZiHl4eXhpSFkoSSg5GCj4KQgo2CjYONgYuBi4KLgIl/hoCGgIWChAiBg4OFhISEhYaFhoaIhoaJhYuFi4aNiJCGkIaRhJGEkoORgZOCkoCRgJB/kICNgosIgYuBi4OJgomCiYKGgoeDhYSEhYSGgod/h3+Jfot7CA77JouyFYv4BAWLkY2Rj5GOkJCPko2PjY+Mj4sI98CLBY+Lj4qPiZGJkIePho+FjYWLhQiL/AQFi4SJhYeGh4aGh4WIiIqGioeLgYuEjoSRCPsS9w37EvsNBYSFg4iCi4eLh4uHjYSOho+IkIeQiZGLkgiwkxX3JvchpHL3DfsIi/f3+7iLi/v3BQ5ni8sVi/c5BYuSjpKQkJCQko6Siwj3VIuLwgWLrpippKSkpKmYrouvi6l+pHKkcpdti2gIi0IFi4aKhoeIh4eHiYaLCHmLBYaLh42Hj4eOipCLkAiL1AWLn4OcfZp9mXqSdot3i3qEfX18fIR6i3cIi1SniwWSi5KIkIaQho6Ei4QIi/s5BYuDiIWGhoaFhImEiwj7p4sFhIuEjYaRhpCIkYuTCA5njPe6FYyQkI6UjQj3I6DM9xYFj5KPj5GLkIuQh4+ECMv7FvcjdgWUiZCIjYaNhoiFhYUIIyak+yMFjIWKhomHiYiIiYaLiIuHjIeNCPsUz/sVRwWHiYeKiIuHi4eNiY6Jj4uQjJEIo/cjI/AFhZGJkY2QCPeB+z0VnILlW3rxiJ6ZmNTS+wydgpxe54v7pwUOZ4vCFYv3SwWLkI2Pjo+Pjo+NkIsI3osFkIuPiY6Ij4eNh4uGCIv7SwWLhomHh4eIh4eKhosIOIsFhouHjIePiI+Jj4uQCLCvFYuGjIePh46IkImQi5CLj42Pjo6PjY+LkIuQiZCIjoePh42Gi4aLhomIh4eIioaLhgjvZxWL90sFi5CNj46Oj4+PjZCLj4ySkJWWlZaVl5SXmJuVl5GRjo6OkI6RjZCNkIyPjI6MkY2TCIySjJGMj4yPjZCOkY6RjpCPjo6Pj42Qi5SLk4qSiZKJkYiPiJCIjoiPho6GjYeMhwiNh4yGjIaMhYuHi4iLiIuHi4eLg4uEiYSJhImFiYeJh4mFh4WLioqJiomJiIqJiokIi4qKiIqJCNqLBZqLmIWWgJaAkH+LfIt6hn2Af46DjYSLhIt9h36Cf4+Bi3+HgImAhYKEhI12hnmAfgh/fXiDcosIZosFfot+jHyOfI5/joOOg41/j32Qc5N8j4SMhouHjYiOh4+Jj4uQCA5ni/c5FYuGjYaOiI+Hj4mQiwjeiwWQi4+Njo+Pjo2Qi5AIi/dKBYuQiZCHjoiPh42Giwg4iwWGi4eJh4eIiImGi4YIi/tKBbD3JhWLkIyPj4+OjpCNkIuQi4+Jj4iOh42Hi4aLhomHiIeHh4eKhouGi4aMiI+Hj4qPi5AI7/snFYv3SwWLkI2Qj46Oj4+NkIuSi5qPo5OZkJePk46TjZeOmo6ajpiMmIsIsIsFpIueg5d9ln6Qeol1koSRgo2Aj4CLgIeAlH+Pfot9i4WJhIiCloCQfIt7i3yFfoGACICAfoZ8iwg8iwWMiIyJi4mMiYyJjYmMiIyKi4mPhI2GjYeNh42GjYOMhIyEi4SLhouHi4iLiYuGioYIioWKhomHioeJh4iGh4eIh4aIh4iFiISJhImDioKLhouHjYiPh4+Ij4iRiJGJkIqPCIqPipGKkomTipGKj4qOiZCJkYiQiJCIjoWSgZZ+nIKXgZaBloGWhJGHi4aLh42HjwiIjomQi48IDviUFPiUFYsMCgAAAAADAgABkAAFAAABTAFmAAAARwFMAWYAAAD1ABkAhAAAAAAAAAAAAAAAAAAAAAEQAAAAAAAAAAAAAAAAAAAAAEAAAPFlAeD/4P/gAeAAIAAAAAEAAAAAAAAAAAAAACAAAAAAAAIAAAADAAAAFAADAAEAAAAUAAQAkAAAACAAIAAEAAAAAQAg5gXwBvAN8CPwLvBu8HDwivCX8JzxI/Fl//3//wAAAAAAIOYA8ATwDPAj8C7wbvBw8Ifwl/Cc8SPxZP/9//8AAf/jGgQQBhABD+wP4g+jD6IPjA+AD3wO9g62AAMAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAf//AA8AAQAAAAEAAJrVlLJfDzz1AAsCAAAAAADP/GODAAAAAM/8Y4MAAP/bAgAB2wAAAAgAAgAAAAAAAAABAAAB4P/gAAACAAAAAAACAAABAAAAAAAAAAAAAAAAAAAAHAAAAAAAAAAAAAAAAAEAAAACAAAAAgAAAAIAAAACAAAAAgAAAAIAAAACAAAAAdwAAAHcAAACAAAjAZMAHwFJAAABbgAAAgAAAAIAAAACAAAAAgAAAAEAAAACAAAAAW4AAAHcAAAB3AABAdwAAAHcAAAAAFAAABwAAAAAAA4ArgABAAAAAAABAAwAAAABAAAAAAACAA4AQAABAAAAAAADAAwAIgABAAAAAAAEAAwATgABAAAAAAAFABYADAABAAAAAAAGAAYALgABAAAAAAAKADQAWgADAAEECQABAAwAAAADAAEECQACAA4AQAADAAEECQADAAwAIgADAAEECQAEAAwATgADAAEECQAFABYADAADAAEECQAGAAwANAADAAEECQAKADQAWgByAGEAdABpAG4AZwBWAGUAcgBzAGkAbwBuACAAMQAuADAAcgBhAHQAaQBuAGdyYXRpbmcAcgBhAHQAaQBuAGcAUgBlAGcAdQBsAGEAcgByAGEAdABpAG4AZwBGAG8AbgB0ACAAZwBlAG4AZQByAGEAdABlAGQAIABiAHkAIABJAGMAbwBNAG8AbwBuAC4AAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA== ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "data:application/font-woff;charset=utf-8;base64,d09GRk9UVE8AABcUAAoAAAAAFswAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABDRkYgAAAA9AAAEuEAABLho6TvIE9TLzIAABPYAAAAYAAAAGAIIwgbY21hcAAAFDgAAACkAAAApKPambxnYXNwAAAU3AAAAAgAAAAIAAAAEGhlYWQAABTkAAAANgAAADYBGAe5aGhlYQAAFRwAAAAkAAAAJAPiAf1obXR4AAAVQAAAAHAAAABwLOAAQ21heHAAABWwAAAABgAAAAYAHFAAbmFtZQAAFbgAAAE8AAABPPC1n05wb3N0AAAW9AAAACAAAAAgAAMAAAEABAQAAQEBB3JhdGluZwABAgABADr4HAL4GwP4GAQeCgAZU/+Lix4KABlT/4uLDAeLZviU+HQFHQAAAP0PHQAAAQIRHQAAAAkdAAAS2BIAHQEBBw0PERQZHiMoLTI3PEFGS1BVWl9kaW5zeH2Ch4xyYXRpbmdyYXRpbmd1MHUxdTIwdUU2MDB1RTYwMXVFNjAydUU2MDN1RTYwNHVFNjA1dUYwMDR1RjAwNXVGMDA2dUYwMEN1RjAwRHVGMDIzdUYwMkV1RjA2RXVGMDcwdUYwODd1RjA4OHVGMDg5dUYwOEF1RjA5N3VGMDlDdUYxMjN1RjE2NHVGMTY1AAACAYkAGgAcAgABAAQABwAKAA0AVgCWAL0BAgGMAeQCbwLwA4cD5QR0BQMFdgZgB8MJkQtxC7oM2Q1jDggOmRAYEZr8lA78lA78lA77lA74lPetFftFpTz3NDz7NPtFcfcU+xBt+0T3Mt73Mjht90T3FPcQBfuU+0YV+wRRofcQMOP3EZ3D9wXD+wX3EXkwM6H7EPsExQUO+JT3rRX7RaU89zQ8+zT7RXH3FPsQbftE9zLe9zI4bfdE9xT3EAX7lPtGFYuLi/exw/sF9xF5MDOh+xD7BMUFDviU960V+0WlPPc0PPs0+0Vx9xT7EG37RPcy3vcyOG33RPcU9xAFDviU98EVi2B4ZG5wCIuL+zT7NAV7e3t7e4t7i3ube5sI+zT3NAVupniyi7aL3M3N3Iu2i7J4pm6mqLKetovci81JizoIDviU98EVi9xJzTqLYItkeHBucKhknmCLOotJSYs6i2CeZKhwCIuL9zT7NAWbe5t7m4ubi5ubm5sI9zT3NAWopp6yi7YIME0V+zb7NgWKioqKiouKi4qMiowI+zb3NgV6m4Ghi6OLubCwuYuji6GBm3oIule6vwWbnKGVo4u5i7Bmi12Lc4F1ensIDviU98EVi2B4ZG5wCIuL+zT7NAV7e3t7e4t7i3ube5sI+zT3NAVupniyi7aL3M3N3Iuni6WDoX4IXED3BEtL+zT3RPdU+wTLssYFl46YjZiL3IvNSYs6CA6L98UVi7WXrKOio6Otl7aLlouXiZiHl4eWhZaEloSUhZKFk4SShZKEkpKSkZOSkpGUkZaSCJaSlpGXj5iPl42Wi7aLrX+jc6N0l2qLYYthdWBgYAj7RvtABYeIh4mGi4aLh42Hjgj7RvdABYmNiY2Hj4iOhpGDlISUhZWFlIWVhpaHmYaYiZiLmAgOZ4v3txWLkpCPlo0I9yOgzPcWBY6SkI+Ri5CLkIePhAjL+xb3I3YFlomQh4uEi4aJh4aGCCMmpPsjBYuKi4mLiIuHioiJiImIiIqHi4iLh4yHjQj7FM/7FUcFh4mHioiLh4uIjImOiY6KjouPi4yLjYyOCKP3IyPwBYaQiZCLjwgOZ4v3txWLkpCPlo0I9yOgzPcWBY6SkI+Ri5CLkIePhAjL+xb3I3YFlomQh4uEi4aJh4aGCCMmpPsjBYuKi4mLiIuCh4aDi4iLh4yHjQj7FM/7FUcFh4mHioiLh4uIjImOiY6KjouPi4yLjYyOCKP3IyPwBYaQiZCLjwjKeRXjN3b7DfcAxPZSd/cN4t/7DJ1V9wFV+wEFDq73ZhWLk42RkZEIsbIFkZCRjpOLkouSiJCGCN8291D3UAWQkJKOkouTi5GIkYYIsWQFkYaNhIuEi4OJhYWFCPuJ+4kFhYWFiYOLhIuEjYaRCPsi9yIFhZCJkouSCA77AartFYuSjpKQkAjf3zffBYaQiJKLk4uSjpKQkAiysgWRkJGOk4uSi5KIkIYI3zff3wWQkJKOk4uSi5KIkIYIsmQFkIaOhIuEi4OIhIaGCDc33zcFkIaOhIuEi4OIhYaFCGRkBYaGhIiEi4OLhI6GkAg33zc3BYaGhIiEi4OLhY6FkAhksgWGkYiRi5MIDvtLi8sVi/c5BYuSjpKQkJCQko6SiwiVi4vCBYuul6mkpKSkqpiui66LqX6kcqRymG2LaAiLVJSLBZKLkoiQhpCGjoSLhAiL+zkFi4OIhYaGhoWEiYSLCPuniwWEi4SNhpGGkIiRi5MI5vdUFfcni4vCBYufhJx8mn2ZepJ3i3aLeoR9fX18g3qLdwiLVAUO+yaLshWL+AQFi5GNkY+RjpCQj5KNj42PjI+LCPfAiwWPi4+Kj4mRiZCHj4aPhY2Fi4UIi/wEBYuEiYWHhoeGhoeFiIiKhoqHi4GLhI6EkQj7EvcN+xL7DQWEhYOIgouHi4eLh42EjoaPiJCHkImRi5IIDov3XRWLko2Rj5Kltq+vuKW4pbuZvYu9i7t9uHG4ca9npWCPhI2Fi4SLhYmEh4RxYGdoXnAIXnFbflmLWYtbmF6lXqZnrnG2h5KJkouRCLCLFaRkq2yxdLF0tH+4i7iLtJexorGiq6qksm64Z61goZZ3kXaLdItnfm1ycnJybX9oiwhoi22XcqRypH6pi6+LopGglp9gdWdpbl4I9xiwFYuHjIiOiI6IjoqPi4+LjoyOjo2OjY6Lj4ubkJmXl5eWmZGbi4+LjoyOjo2OjY6LjwiLj4mOiY6IjYiNh4tzi3eCenp6eoJ3i3MIDov3XRWLko2Sj5GouK+utqW3pbqYvouci5yJnIgIm6cFjY6NjI+LjIuNi42JjYqOio+JjomOiY6KjomOiY6JjoqNioyKjomMiYuHi4qLiouLCHdnbVVjQ2NDbVV3Zwh9cgWJiIiJiIuJi36SdJiIjYmOi46LjY+UlJlvl3KcdJ90oHeie6WHkYmSi5IIsIsVqlq0Z711CKGzBXqXfpqCnoKdhp6LoIuikaCWn2B1Z2luXgj3GLAVi4eMiI6IjoiOio+Lj4uOjI6OjY6NjouPi5uQmZeXl5aZkZuLj4uOjI6OjY6NjouPCIuPiY6JjoiNiI2Hi3OLd4J6enp6gneLcwji+10VoLAFtI+wmK2hrqKnqKKvdq1wp2uhCJ2rBZ1/nHycepx6mHqWeY+EjYWLhIuEiYWHhIR/gH1+fG9qaXJmeWV5Y4Jhiwi53BXb9yQFjIKMg4uEi3CDc3x1fHV3fHOBCA6L1BWL90sFi5WPlJKSkpKTj5aLCNmLBZKPmJqepJaZlZeVlY+Qj5ONl42WjpeOmI+YkZWTk5OSk46Vi5uLmYiYhZiFlIGSfgiSfo55i3WLeYd5gXgIvosFn4uchJl8mn2Seot3i3qGfIJ9jYSLhYuEi3yIfoR+i4eLh4uHi3eGen99i3CDdnt8CHt8dYNwiwhmiwV5i3mNeY95kHeRc5N1k36Ph4sIOYsFgIuDjoSShJKHlIuVCLCdFYuGjIePiI+Hj4mQi5CLj42Pj46OjY+LkIuQiZCIjoePh42Gi4aLh4mHh4eIioaLhgjUeRWUiwWNi46Lj4qOi4+KjYqOi4+Kj4mQio6KjYqNio+Kj4mQio6KjIqzfquEpIsIrosFr4uemouri5CKkYqQkY6QkI6SjpKNkouSi5KJkoiRlZWQlouYi5CKkImRiZGJj4iOCJGMkI+PlI+UjZKLkouViJODk4SSgo+CiwgmiwWLlpCalJ6UnpCbi5aLnoiYhJSFlH+QeYuGhoeDiYCJf4h/h3+IfoWBg4KHh4SCgH4Ii4qIiYiGh4aIh4mIiIiIh4eGh4aHh4eHiIiHiIeHiIiHiIeKh4mIioiLCIKLi/tLBQ6L90sVi/dLBYuVj5OSk5KSk46WiwjdiwWPi5iPoZOkk6CRnZCdj56Nn4sIq4sFpougg5x8m3yTd4txCIuJBZd8kHuLd4uHi4eLh5J+jn6LfIuEi4SJhZR9kHyLeot3hHp8fH19eoR3iwhYiwWVeI95i3mLdIh6hH6EfoKBfoV+hX2He4uBi4OPg5KFkYaTh5SHlYiTipOKk4qTiJMIiZSIkYiPgZSBl4CaeKR+moSPCD2LBYCLg4+EkoSSh5SLlQiw9zgVi4aMh4+Ij4ePiZCLkIuPjY+Pjo6Nj4uQi5CJkIiOh4+HjYaLhouHiYeHh4iKhouGCNT7OBWUiwWOi46Kj4mPio+IjoiPh4+IjoePiI+Hj4aPho6HjoiNiI6Hj4aOho6Ii4qWfpKDj4YIk4ORgY5+j36OgI1/jYCPg5CGnYuXj5GUkpSOmYuei5aGmoKfgp6GmouWCPCLBZSLlI+SkpOTjpOLlYuSiZKHlIeUho+Fi46PjY+NkY2RjJCLkIuYhpaBlY6RjZKLkgiLkomSiJKIkoaQhY6MkIyRi5CLm4aXgpOBkn6Pe4sIZosFcotrhGN9iouIioaJh4qHiomKiYqIioaKh4mHioiKiYuHioiLh4qIi4mLCIKLi/tLBQ77lIv3txWLkpCPlo0I9yOgzPcWBY6SkI+RiwiL/BL7FUcFh4mHioiLh4uIjImOiY6KjouPi4yLjYyOCKP3IyPwBYaQiZCLjwgOi/fFFYu1l6yjoqOjrZe2i5aLl4mYh5eHloWWhJaElIWShZOEkoWShJKSkpGTkpKRlJGWkgiWkpaRl4+Yj5eNlou2i61/o3OjdJdqi2GLYXVgYGAI+0b7QAWHiIeJhouGi4eNh44I+0b3QAWJjYmNh4+IjoaRg5SElIWVhZSFlYaWh5mGmImYi5gIsIsVi2ucaa9oCPc6+zT3OvczBa+vnK2Lq4ubiZiHl4eXhpSFkoSSg5GCj4KQgo2CjYONgYuBi4KLgIl/hoCGgIWChAiBg4OFhISEhYaFhoaIhoaJhYuFi4aNiJCGkIaRhJGEkoORgZOCkoCRgJB/kICNgosIgYuBi4OJgomCiYKGgoeDhYSEhYSGgod/h3+Jfot7CA77JouyFYv4BAWLkY2Rj5GOkJCPko2PjY+Mj4sI98CLBY+Lj4qPiZGJkIePho+FjYWLhQiL/AQFi4SJhYeGh4aGh4WIiIqGioeLgYuEjoSRCPsS9w37EvsNBYSFg4iCi4eLh4uHjYSOho+IkIeQiZGLkgiwkxX3JvchpHL3DfsIi/f3+7iLi/v3BQ5ni8sVi/c5BYuSjpKQkJCQko6Siwj3VIuLwgWLrpippKSkpKmYrouvi6l+pHKkcpdti2gIi0IFi4aKhoeIh4eHiYaLCHmLBYaLh42Hj4eOipCLkAiL1AWLn4OcfZp9mXqSdot3i3qEfX18fIR6i3cIi1SniwWSi5KIkIaQho6Ei4QIi/s5BYuDiIWGhoaFhImEiwj7p4sFhIuEjYaRhpCIkYuTCA5njPe6FYyQkI6UjQj3I6DM9xYFj5KPj5GLkIuQh4+ECMv7FvcjdgWUiZCIjYaNhoiFhYUIIyak+yMFjIWKhomHiYiIiYaLiIuHjIeNCPsUz/sVRwWHiYeKiIuHi4eNiY6Jj4uQjJEIo/cjI/AFhZGJkY2QCPeB+z0VnILlW3rxiJ6ZmNTS+wydgpxe54v7pwUOZ4vCFYv3SwWLkI2Pjo+Pjo+NkIsI3osFkIuPiY6Ij4eNh4uGCIv7SwWLhomHh4eIh4eKhosIOIsFhouHjIePiI+Jj4uQCLCvFYuGjIePh46IkImQi5CLj42Pjo6PjY+LkIuQiZCIjoePh42Gi4aLhomIh4eIioaLhgjvZxWL90sFi5CNj46Oj4+PjZCLj4ySkJWWlZaVl5SXmJuVl5GRjo6OkI6RjZCNkIyPjI6MkY2TCIySjJGMj4yPjZCOkY6RjpCPjo6Pj42Qi5SLk4qSiZKJkYiPiJCIjoiPho6GjYeMhwiNh4yGjIaMhYuHi4iLiIuHi4eLg4uEiYSJhImFiYeJh4mFh4WLioqJiomJiIqJiokIi4qKiIqJCNqLBZqLmIWWgJaAkH+LfIt6hn2Af46DjYSLhIt9h36Cf4+Bi3+HgImAhYKEhI12hnmAfgh/fXiDcosIZosFfot+jHyOfI5/joOOg41/j32Qc5N8j4SMhouHjYiOh4+Jj4uQCA5ni/c5FYuGjYaOiI+Hj4mQiwjeiwWQi4+Njo+Pjo2Qi5AIi/dKBYuQiZCHjoiPh42Giwg4iwWGi4eJh4eIiImGi4YIi/tKBbD3JhWLkIyPj4+OjpCNkIuQi4+Jj4iOh42Hi4aLhomHiIeHh4eKhouGi4aMiI+Hj4qPi5AI7/snFYv3SwWLkI2Qj46Oj4+NkIuSi5qPo5OZkJePk46TjZeOmo6ajpiMmIsIsIsFpIueg5d9ln6Qeol1koSRgo2Aj4CLgIeAlH+Pfot9i4WJhIiCloCQfIt7i3yFfoGACICAfoZ8iwg8iwWMiIyJi4mMiYyJjYmMiIyKi4mPhI2GjYeNh42GjYOMhIyEi4SLhouHi4iLiYuGioYIioWKhomHioeJh4iGh4eIh4aIh4iFiISJhImDioKLhouHjYiPh4+Ij4iRiJGJkIqPCIqPipGKkomTipGKj4qOiZCJkYiQiJCIjoWSgZZ+nIKXgZaBloGWhJGHi4aLh42HjwiIjomQi48IDviUFPiUFYsMCgAAAAADAgABkAAFAAABTAFmAAAARwFMAWYAAAD1ABkAhAAAAAAAAAAAAAAAAAAAAAEQAAAAAAAAAAAAAAAAAAAAAEAAAPFlAeD/4P/gAeAAIAAAAAEAAAAAAAAAAAAAACAAAAAAAAIAAAADAAAAFAADAAEAAAAUAAQAkAAAACAAIAAEAAAAAQAg5gXwBvAN8CPwLvBu8HDwivCX8JzxI/Fl//3//wAAAAAAIOYA8ATwDPAj8C7wbvBw8Ifwl/Cc8SPxZP/9//8AAf/jGgQQBhABD+wP4g+jD6IPjA+AD3wO9g62AAMAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAf//AA8AAQAAAAEAAJrVlLJfDzz1AAsCAAAAAADP/GODAAAAAM/8Y4MAAP/bAgAB2wAAAAgAAgAAAAAAAAABAAAB4P/gAAACAAAAAAACAAABAAAAAAAAAAAAAAAAAAAAHAAAAAAAAAAAAAAAAAEAAAACAAAAAgAAAAIAAAACAAAAAgAAAAIAAAACAAAAAdwAAAHcAAACAAAjAZMAHwFJAAABbgAAAgAAAAIAAAACAAAAAgAAAAEAAAACAAAAAW4AAAHcAAAB3AABAdwAAAHcAAAAAFAAABwAAAAAAA4ArgABAAAAAAABAAwAAAABAAAAAAACAA4AQAABAAAAAAADAAwAIgABAAAAAAAEAAwATgABAAAAAAAFABYADAABAAAAAAAGAAYALgABAAAAAAAKADQAWgADAAEECQABAAwAAAADAAEECQACAA4AQAADAAEECQADAAwAIgADAAEECQAEAAwATgADAAEECQAFABYADAADAAEECQAGAAwANAADAAEECQAKADQAWgByAGEAdABpAG4AZwBWAGUAcgBzAGkAbwBuACAAMQAuADAAcgBhAHQAaQBuAGdyYXRpbmcAcgBhAHQAaQBuAGcAUgBlAGcAdQBsAGEAcgByAGEAdABpAG4AZwBGAG8AbgB0ACAAZwBlAG4AZQByAGEAdABlAGQAIABiAHkAIABJAGMAbwBNAG8AbwBuAC4AAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==";

/***/ }),

/***/ "data:application/x-font-ttf;charset=utf-8;base64,AAEAAAALAIAAAwAwT1MvMg8SBD8AAAC8AAAAYGNtYXAYVtCJAAABHAAAAFRnYXNwAAAAEAAAAXAAAAAIZ2x5Zn4huwUAAAF4AAABYGhlYWQGPe1ZAAAC2AAAADZoaGVhB30DyAAAAxAAAAAkaG10eBBKAEUAAAM0AAAAHGxvY2EAmgESAAADUAAAABBtYXhwAAkALwAAA2AAAAAgbmFtZSC8IugAAAOAAAABknBvc3QAAwAAAAAFFAAAACAAAwMTAZAABQAAApkCzAAAAI8CmQLMAAAB6wAzAQkAAAAAAAAAAAAAAAAAAAABEAAAAAAAAAAAAAAAAAAAAABAAADoAgPA/8AAQAPAAEAAAAABAAAAAAAAAAAAAAAgAAAAAAADAAAAAwAAABwAAQADAAAAHAADAAEAAAAcAAQAOAAAAAoACAACAAIAAQAg6AL//f//AAAAAAAg6AD//f//AAH/4xgEAAMAAQAAAAAAAAAAAAAAAQAB//8ADwABAAAAAAAAAAAAAgAANzkBAAAAAAEAAAAAAAAAAAACAAA3OQEAAAAAAQAAAAAAAAAAAAIAADc5AQAAAAABAEUAUQO7AvgAGgAAARQHAQYjIicBJjU0PwE2MzIfAQE2MzIfARYVA7sQ/hQQFhcQ/uMQEE4QFxcQqAF2EBcXEE4QAnMWEP4UEBABHRAXFhBOEBCoAXcQEE4QFwAAAAABAAABbgMlAkkAFAAAARUUBwYjISInJj0BNDc2MyEyFxYVAyUQEBf9SRcQEBAQFwK3FxAQAhJtFxAQEBAXbRcQEBAQFwAAAAABAAAASQMlA24ALAAAARUUBwYrARUUBwYrASInJj0BIyInJj0BNDc2OwE1NDc2OwEyFxYdATMyFxYVAyUQEBfuEBAXbhYQEO4XEBAQEBfuEBAWbhcQEO4XEBACEm0XEBDuFxAQEBAX7hAQF20XEBDuFxAQEBAX7hAQFwAAAQAAAAIAAHRSzT9fDzz1AAsEAAAAAADRsdR3AAAAANGx1HcAAAAAA7sDbgAAAAgAAgAAAAAAAAABAAADwP/AAAAEAAAAAAADuwABAAAAAAAAAAAAAAAAAAAABwQAAAAAAAAAAAAAAAIAAAAEAABFAyUAAAMlAAAAAAAAAAoAFAAeAE4AcgCwAAEAAAAHAC0AAQAAAAAAAgAAAAAAAAAAAAAAAAAAAAAAAAAOAK4AAQAAAAAAAQAIAAAAAQAAAAAAAgAHAGkAAQAAAAAAAwAIADkAAQAAAAAABAAIAH4AAQAAAAAABQALABgAAQAAAAAABgAIAFEAAQAAAAAACgAaAJYAAwABBAkAAQAQAAgAAwABBAkAAgAOAHAAAwABBAkAAwAQAEEAAwABBAkABAAQAIYAAwABBAkABQAWACMAAwABBAkABgAQAFkAAwABBAkACgA0ALBDaGVja2JveABDAGgAZQBjAGsAYgBvAHhWZXJzaW9uIDIuMABWAGUAcgBzAGkAbwBuACAAMgAuADBDaGVja2JveABDAGgAZQBjAGsAYgBvAHhDaGVja2JveABDAGgAZQBjAGsAYgBvAHhSZWd1bGFyAFIAZQBnAHUAbABhAHJDaGVja2JveABDAGgAZQBjAGsAYgBvAHhGb250IGdlbmVyYXRlZCBieSBJY29Nb29uLgBGAG8AbgB0ACAAZwBlAG4AZQByAGEAdABlAGQAIABiAHkAIABJAGMAbwBNAG8AbwBuAC4AAAADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** data:application/x-font-ttf;charset=utf-8;base64,AAEAAAALAIAAAwAwT1MvMg8SBD8AAAC8AAAAYGNtYXAYVtCJAAABHAAAAFRnYXNwAAAAEAAAAXAAAAAIZ2x5Zn4huwUAAAF4AAABYGhlYWQGPe1ZAAAC2AAAADZoaGVhB30DyAAAAxAAAAAkaG10eBBKAEUAAAM0AAAAHGxvY2EAmgESAAADUAAAABBtYXhwAAkALwAAA2AAAAAgbmFtZSC8IugAAAOAAAABknBvc3QAAwAAAAAFFAAAACAAAwMTAZAABQAAApkCzAAAAI8CmQLMAAAB6wAzAQkAAAAAAAAAAAAAAAAAAAABEAAAAAAAAAAAAAAAAAAAAABAAADoAgPA/8AAQAPAAEAAAAABAAAAAAAAAAAAAAAgAAAAAAADAAAAAwAAABwAAQADAAAAHAADAAEAAAAcAAQAOAAAAAoACAACAAIAAQAg6AL//f//AAAAAAAg6AD//f//AAH/4xgEAAMAAQAAAAAAAAAAAAAAAQAB//8ADwABAAAAAAAAAAAAAgAANzkBAAAAAAEAAAAAAAAAAAACAAA3OQEAAAAAAQAAAAAAAAAAAAIAADc5AQAAAAABAEUAUQO7AvgAGgAAARQHAQYjIicBJjU0PwE2MzIfAQE2MzIfARYVA7sQ/hQQFhcQ/uMQEE4QFxcQqAF2EBcXEE4QAnMWEP4UEBABHRAXFhBOEBCoAXcQEE4QFwAAAAABAAABbgMlAkkAFAAAARUUBwYjISInJj0BNDc2MyEyFxYVAyUQEBf9SRcQEBAQFwK3FxAQAhJtFxAQEBAXbRcQEBAQFwAAAAABAAAASQMlA24ALAAAARUUBwYrARUUBwYrASInJj0BIyInJj0BNDc2OwE1NDc2OwEyFxYdATMyFxYVAyUQEBfuEBAXbhYQEO4XEBAQEBfuEBAWbhcQEO4XEBACEm0XEBDuFxAQEBAX7hAQF20XEBDuFxAQEBAX7hAQFwAAAQAAAAIAAHRSzT9fDzz1AAsEAAAAAADRsdR3AAAAANGx1HcAAAAAA7sDbgAAAAgAAgAAAAAAAAABAAADwP/AAAAEAAAAAAADuwABAAAAAAAAAAAAAAAAAAAABwQAAAAAAAAAAAAAAAIAAAAEAABFAyUAAAMlAAAAAAAAAAoAFAAeAE4AcgCwAAEAAAAHAC0AAQAAAAAAAgAAAAAAAAAAAAAAAAAAAAAAAAAOAK4AAQAAAAAAAQAIAAAAAQAAAAAAAgAHAGkAAQAAAAAAAwAIADkAAQAAAAAABAAIAH4AAQAAAAAABQALABgAAQAAAAAABgAIAFEAAQAAAAAACgAaAJYAAwABBAkAAQAQAAgAAwABBAkAAgAOAHAAAwABBAkAAwAQAEEAAwABBAkABAAQAIYAAwABBAkABQAWACMAAwABBAkABgAQAFkAAwABBAkACgA0ALBDaGVja2JveABDAGgAZQBjAGsAYgBvAHhWZXJzaW9uIDIuMABWAGUAcgBzAGkAbwBuACAAMgAuADBDaGVja2JveABDAGgAZQBjAGsAYgBvAHhDaGVja2JveABDAGgAZQBjAGsAYgBvAHhSZWd1bGFyAFIAZQBnAHUAbABhAHJDaGVja2JveABDAGgAZQBjAGsAYgBvAHhGb250IGdlbmVyYXRlZCBieSBJY29Nb29uLgBGAG8AbgB0ACAAZwBlAG4AZQByAGEAdABlAGQAIABiAHkAIABJAGMAbwBNAG8AbwBuAC4AAAADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "data:application/x-font-ttf;charset=utf-8;base64,AAEAAAALAIAAAwAwT1MvMg8SBD8AAAC8AAAAYGNtYXAYVtCJAAABHAAAAFRnYXNwAAAAEAAAAXAAAAAIZ2x5Zn4huwUAAAF4AAABYGhlYWQGPe1ZAAAC2AAAADZoaGVhB30DyAAAAxAAAAAkaG10eBBKAEUAAAM0AAAAHGxvY2EAmgESAAADUAAAABBtYXhwAAkALwAAA2AAAAAgbmFtZSC8IugAAAOAAAABknBvc3QAAwAAAAAFFAAAACAAAwMTAZAABQAAApkCzAAAAI8CmQLMAAAB6wAzAQkAAAAAAAAAAAAAAAAAAAABEAAAAAAAAAAAAAAAAAAAAABAAADoAgPA/8AAQAPAAEAAAAABAAAAAAAAAAAAAAAgAAAAAAADAAAAAwAAABwAAQADAAAAHAADAAEAAAAcAAQAOAAAAAoACAACAAIAAQAg6AL//f//AAAAAAAg6AD//f//AAH/4xgEAAMAAQAAAAAAAAAAAAAAAQAB//8ADwABAAAAAAAAAAAAAgAANzkBAAAAAAEAAAAAAAAAAAACAAA3OQEAAAAAAQAAAAAAAAAAAAIAADc5AQAAAAABAEUAUQO7AvgAGgAAARQHAQYjIicBJjU0PwE2MzIfAQE2MzIfARYVA7sQ/hQQFhcQ/uMQEE4QFxcQqAF2EBcXEE4QAnMWEP4UEBABHRAXFhBOEBCoAXcQEE4QFwAAAAABAAABbgMlAkkAFAAAARUUBwYjISInJj0BNDc2MyEyFxYVAyUQEBf9SRcQEBAQFwK3FxAQAhJtFxAQEBAXbRcQEBAQFwAAAAABAAAASQMlA24ALAAAARUUBwYrARUUBwYrASInJj0BIyInJj0BNDc2OwE1NDc2OwEyFxYdATMyFxYVAyUQEBfuEBAXbhYQEO4XEBAQEBfuEBAWbhcQEO4XEBACEm0XEBDuFxAQEBAX7hAQF20XEBDuFxAQEBAX7hAQFwAAAQAAAAIAAHRSzT9fDzz1AAsEAAAAAADRsdR3AAAAANGx1HcAAAAAA7sDbgAAAAgAAgAAAAAAAAABAAADwP/AAAAEAAAAAAADuwABAAAAAAAAAAAAAAAAAAAABwQAAAAAAAAAAAAAAAIAAAAEAABFAyUAAAMlAAAAAAAAAAoAFAAeAE4AcgCwAAEAAAAHAC0AAQAAAAAAAgAAAAAAAAAAAAAAAAAAAAAAAAAOAK4AAQAAAAAAAQAIAAAAAQAAAAAAAgAHAGkAAQAAAAAAAwAIADkAAQAAAAAABAAIAH4AAQAAAAAABQALABgAAQAAAAAABgAIAFEAAQAAAAAACgAaAJYAAwABBAkAAQAQAAgAAwABBAkAAgAOAHAAAwABBAkAAwAQAEEAAwABBAkABAAQAIYAAwABBAkABQAWACMAAwABBAkABgAQAFkAAwABBAkACgA0ALBDaGVja2JveABDAGgAZQBjAGsAYgBvAHhWZXJzaW9uIDIuMABWAGUAcgBzAGkAbwBuACAAMgAuADBDaGVja2JveABDAGgAZQBjAGsAYgBvAHhDaGVja2JveABDAGgAZQBjAGsAYgBvAHhSZWd1bGFyAFIAZQBnAHUAbABhAHJDaGVja2JveABDAGgAZQBjAGsAYgBvAHhGb250IGdlbmVyYXRlZCBieSBJY29Nb29uLgBGAG8AbgB0ACAAZwBlAG4AZQByAGEAdABlAGQAIABiAHkAIABJAGMAbwBNAG8AbwBuAC4AAAADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";

/***/ }),

/***/ "data:application/x-font-ttf;charset=utf-8;base64,AAEAAAALAIAAAwAwT1MvMggjB5AAAAC8AAAAYGNtYXAPfOIKAAABHAAAAExnYXNwAAAAEAAAAWgAAAAIZ2x5Zryj6HgAAAFwAAAAyGhlYWT/0IhHAAACOAAAADZoaGVhApkB5wAAAnAAAAAkaG10eAJuABIAAAKUAAAAGGxvY2EAjABWAAACrAAAAA5tYXhwAAgAFgAAArwAAAAgbmFtZfC1n04AAALcAAABPHBvc3QAAwAAAAAEGAAAACAAAwIAAZAABQAAAUwBZgAAAEcBTAFmAAAA9QAZAIQAAAAAAAAAAAAAAAAAAAABEAAAAAAAAAAAAAAAAAAAAABAAADw2gHg/+D/4AHgACAAAAABAAAAAAAAAAAAAAAgAAAAAAACAAAAAwAAABQAAwABAAAAFAAEADgAAAAKAAgAAgACAAEAIPDa//3//wAAAAAAIPDZ//3//wAB/+MPKwADAAEAAAAAAAAAAAAAAAEAAf//AA8AAQAAAAAAAAAAAAIAADc5AQAAAAABAAAAAAAAAAAAAgAANzkBAAAAAAEAAAAAAAAAAAACAAA3OQEAAAAAAQASAEkAtwFuABMAADc0PwE2FzYXFh0BFAcGJwYvASY1EgaABQgHBQYGBQcIBYAG2wcGfwcBAQcECf8IBAcBAQd/BgYAAAAAAQAAAEkApQFuABMAADcRNDc2MzIfARYVFA8BBiMiJyY1AAUGBwgFgAYGgAUIBwYFWwEACAUGBoAFCAcFgAYGBQcAAAABAAAAAQAAqWYls18PPPUACwIAAAAAAM/9o+4AAAAAz/2j7gAAAAAAtwFuAAAACAACAAAAAAAAAAEAAAHg/+AAAAIAAAAAAAC3AAEAAAAAAAAAAAAAAAAAAAAGAAAAAAAAAAAAAAAAAQAAAAC3ABIAtwAAAAAAAAAKABQAHgBCAGQAAAABAAAABgAUAAEAAAAAAAIAAAAAAAAAAAAAAAAAAAAAAAAADgCuAAEAAAAAAAEADAAAAAEAAAAAAAIADgBAAAEAAAAAAAMADAAiAAEAAAAAAAQADABOAAEAAAAAAAUAFgAMAAEAAAAAAAYABgAuAAEAAAAAAAoANABaAAMAAQQJAAEADAAAAAMAAQQJAAIADgBAAAMAAQQJAAMADAAiAAMAAQQJAAQADABOAAMAAQQJAAUAFgAMAAMAAQQJAAYADAA0AAMAAQQJAAoANABaAHIAYQB0AGkAbgBnAFYAZQByAHMAaQBvAG4AIAAxAC4AMAByAGEAdABpAG4AZ3JhdGluZwByAGEAdABpAG4AZwBSAGUAZwB1AGwAYQByAHIAYQB0AGkAbgBnAEYAbwBuAHQAIABnAGUAbgBlAHIAYQB0AGUAZAAgAGIAeQAgAEkAYwBvAE0AbwBvAG4ALgADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** data:application/x-font-ttf;charset=utf-8;base64,AAEAAAALAIAAAwAwT1MvMggjB5AAAAC8AAAAYGNtYXAPfOIKAAABHAAAAExnYXNwAAAAEAAAAWgAAAAIZ2x5Zryj6HgAAAFwAAAAyGhlYWT/0IhHAAACOAAAADZoaGVhApkB5wAAAnAAAAAkaG10eAJuABIAAAKUAAAAGGxvY2EAjABWAAACrAAAAA5tYXhwAAgAFgAAArwAAAAgbmFtZfC1n04AAALcAAABPHBvc3QAAwAAAAAEGAAAACAAAwIAAZAABQAAAUwBZgAAAEcBTAFmAAAA9QAZAIQAAAAAAAAAAAAAAAAAAAABEAAAAAAAAAAAAAAAAAAAAABAAADw2gHg/+D/4AHgACAAAAABAAAAAAAAAAAAAAAgAAAAAAACAAAAAwAAABQAAwABAAAAFAAEADgAAAAKAAgAAgACAAEAIPDa//3//wAAAAAAIPDZ//3//wAB/+MPKwADAAEAAAAAAAAAAAAAAAEAAf//AA8AAQAAAAAAAAAAAAIAADc5AQAAAAABAAAAAAAAAAAAAgAANzkBAAAAAAEAAAAAAAAAAAACAAA3OQEAAAAAAQASAEkAtwFuABMAADc0PwE2FzYXFh0BFAcGJwYvASY1EgaABQgHBQYGBQcIBYAG2wcGfwcBAQcECf8IBAcBAQd/BgYAAAAAAQAAAEkApQFuABMAADcRNDc2MzIfARYVFA8BBiMiJyY1AAUGBwgFgAYGgAUIBwYFWwEACAUGBoAFCAcFgAYGBQcAAAABAAAAAQAAqWYls18PPPUACwIAAAAAAM/9o+4AAAAAz/2j7gAAAAAAtwFuAAAACAACAAAAAAAAAAEAAAHg/+AAAAIAAAAAAAC3AAEAAAAAAAAAAAAAAAAAAAAGAAAAAAAAAAAAAAAAAQAAAAC3ABIAtwAAAAAAAAAKABQAHgBCAGQAAAABAAAABgAUAAEAAAAAAAIAAAAAAAAAAAAAAAAAAAAAAAAADgCuAAEAAAAAAAEADAAAAAEAAAAAAAIADgBAAAEAAAAAAAMADAAiAAEAAAAAAAQADABOAAEAAAAAAAUAFgAMAAEAAAAAAAYABgAuAAEAAAAAAAoANABaAAMAAQQJAAEADAAAAAMAAQQJAAIADgBAAAMAAQQJAAMADAAiAAMAAQQJAAQADABOAAMAAQQJAAUAFgAMAAMAAQQJAAYADAA0AAMAAQQJAAoANABaAHIAYQB0AGkAbgBnAFYAZQByAHMAaQBvAG4AIAAxAC4AMAByAGEAdABpAG4AZ3JhdGluZwByAGEAdABpAG4AZwBSAGUAZwB1AGwAYQByAHIAYQB0AGkAbgBnAEYAbwBuAHQAIABnAGUAbgBlAHIAYQB0AGUAZAAgAGIAeQAgAEkAYwBvAE0AbwBvAG4ALgADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "data:application/x-font-ttf;charset=utf-8;base64,AAEAAAALAIAAAwAwT1MvMggjB5AAAAC8AAAAYGNtYXAPfOIKAAABHAAAAExnYXNwAAAAEAAAAWgAAAAIZ2x5Zryj6HgAAAFwAAAAyGhlYWT/0IhHAAACOAAAADZoaGVhApkB5wAAAnAAAAAkaG10eAJuABIAAAKUAAAAGGxvY2EAjABWAAACrAAAAA5tYXhwAAgAFgAAArwAAAAgbmFtZfC1n04AAALcAAABPHBvc3QAAwAAAAAEGAAAACAAAwIAAZAABQAAAUwBZgAAAEcBTAFmAAAA9QAZAIQAAAAAAAAAAAAAAAAAAAABEAAAAAAAAAAAAAAAAAAAAABAAADw2gHg/+D/4AHgACAAAAABAAAAAAAAAAAAAAAgAAAAAAACAAAAAwAAABQAAwABAAAAFAAEADgAAAAKAAgAAgACAAEAIPDa//3//wAAAAAAIPDZ//3//wAB/+MPKwADAAEAAAAAAAAAAAAAAAEAAf//AA8AAQAAAAAAAAAAAAIAADc5AQAAAAABAAAAAAAAAAAAAgAANzkBAAAAAAEAAAAAAAAAAAACAAA3OQEAAAAAAQASAEkAtwFuABMAADc0PwE2FzYXFh0BFAcGJwYvASY1EgaABQgHBQYGBQcIBYAG2wcGfwcBAQcECf8IBAcBAQd/BgYAAAAAAQAAAEkApQFuABMAADcRNDc2MzIfARYVFA8BBiMiJyY1AAUGBwgFgAYGgAUIBwYFWwEACAUGBoAFCAcFgAYGBQcAAAABAAAAAQAAqWYls18PPPUACwIAAAAAAM/9o+4AAAAAz/2j7gAAAAAAtwFuAAAACAACAAAAAAAAAAEAAAHg/+AAAAIAAAAAAAC3AAEAAAAAAAAAAAAAAAAAAAAGAAAAAAAAAAAAAAAAAQAAAAC3ABIAtwAAAAAAAAAKABQAHgBCAGQAAAABAAAABgAUAAEAAAAAAAIAAAAAAAAAAAAAAAAAAAAAAAAADgCuAAEAAAAAAAEADAAAAAEAAAAAAAIADgBAAAEAAAAAAAMADAAiAAEAAAAAAAQADABOAAEAAAAAAAUAFgAMAAEAAAAAAAYABgAuAAEAAAAAAAoANABaAAMAAQQJAAEADAAAAAMAAQQJAAIADgBAAAMAAQQJAAMADAAiAAMAAQQJAAQADABOAAMAAQQJAAUAFgAMAAMAAQQJAAYADAA0AAMAAQQJAAoANABaAHIAYQB0AGkAbgBnAFYAZQByAHMAaQBvAG4AIAAxAC4AMAByAGEAdABpAG4AZ3JhdGluZwByAGEAdABpAG4AZwBSAGUAZwB1AGwAYQByAHIAYQB0AGkAbgBnAEYAbwBuAHQAIABnAGUAbgBlAHIAYQB0AGUAZAAgAGIAeQAgAEkAYwBvAE0AbwBvAG4ALgADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";

/***/ }),

/***/ "data:application/x-font-ttf;charset=utf-8;base64,AAEAAAALAIAAAwAwT1MvMggjCBsAAAC8AAAAYGNtYXCj2pm8AAABHAAAAKRnYXNwAAAAEAAAAcAAAAAIZ2x5ZlJbXMYAAAHIAAARnGhlYWQBGAe5AAATZAAAADZoaGVhA+IB/QAAE5wAAAAkaG10eCzgAEMAABPAAAAAcGxvY2EwXCxOAAAUMAAAADptYXhwACIAnAAAFGwAAAAgbmFtZfC1n04AABSMAAABPHBvc3QAAwAAAAAVyAAAACAAAwIAAZAABQAAAUwBZgAAAEcBTAFmAAAA9QAZAIQAAAAAAAAAAAAAAAAAAAABEAAAAAAAAAAAAAAAAAAAAABAAADxZQHg/+D/4AHgACAAAAABAAAAAAAAAAAAAAAgAAAAAAACAAAAAwAAABQAAwABAAAAFAAEAJAAAAAgACAABAAAAAEAIOYF8AbwDfAj8C7wbvBw8Irwl/Cc8SPxZf/9//8AAAAAACDmAPAE8AzwI/Au8G7wcPCH8JfwnPEj8WT//f//AAH/4xoEEAYQAQ/sD+IPow+iD4wPgA98DvYOtgADAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAH//wAPAAEAAAAAAAAAAAACAAA3OQEAAAAAAQAAAAAAAAAAAAIAADc5AQAAAAABAAAAAAAAAAAAAgAANzkBAAAAAAIAAP/tAgAB0wAKABUAAAEvAQ8BFwc3Fyc3BQc3Jz8BHwEHFycCALFPT7GAHp6eHoD/AHAWW304OH1bFnABGRqgoBp8sFNTsHyyOnxYEnFxElh8OgAAAAACAAD/7QIAAdMACgASAAABLwEPARcHNxcnNwUxER8BBxcnAgCxT0+xgB6enh6A/wA4fVsWcAEZGqCgGnywU1OwfLIBHXESWHw6AAAAAQAA/+0CAAHTAAoAAAEvAQ8BFwc3Fyc3AgCxT0+xgB6enh6AARkaoKAafLBTU7B8AAAAAAEAAAAAAgABwAArAAABFA4CBzEHDgMjIi4CLwEuAzU0PgIzMh4CFz4DMzIeAhUCAAcMEgugBgwMDAYGDAwMBqALEgwHFyg2HhAfGxkKChkbHxAeNigXAS0QHxsZCqAGCwkGBQkLBqAKGRsfEB42KBcHDBILCxIMBxcoNh4AAAAAAgAAAAACAAHAACsAWAAAATQuAiMiDgIHLgMjIg4CFRQeAhcxFx4DMzI+Aj8BPgM1DwEiFCIGMTAmIjQjJy4DNTQ+AjMyHgIfATc+AzMyHgIVFA4CBwIAFyg2HhAfGxkKChkbHxAeNigXBwwSC6AGDAwMBgYMDAwGoAsSDAdbogEBAQEBAaIGCgcEDRceEQkREA4GLy8GDhARCREeFw0EBwoGAS0eNigXBwwSCwsSDAcXKDYeEB8bGQqgBgsJBgUJCwagChkbHxA+ogEBAQGiBg4QEQkRHhcNBAcKBjQ0BgoHBA0XHhEJERAOBgABAAAAAAIAAcAAMQAAARQOAgcxBw4DIyIuAi8BLgM1ND4CMzIeAhcHFwc3Jzc+AzMyHgIVAgAHDBILoAYMDAwGBgwMDAagCxIMBxcoNh4KFRMSCC9wQLBwJwUJCgkFHjYoFwEtEB8bGQqgBgsJBgUJCwagChkbHxAeNigXAwUIBUtAoMBAOwECAQEXKDYeAAABAAAAAAIAAbcAKgAAEzQ3NjMyFxYXFhcWFzY3Njc2NzYzMhcWFRQPAQYjIi8BJicmJyYnJicmNQAkJUARExIQEAsMCgoMCxAQEhMRQCUkQbIGBwcGsgMFBQsKCQkGBwExPyMkBgYLCgkKCgoKCQoLBgYkIz8/QawFBawCBgUNDg4OFRQTAAAAAQAAAA0B2wHSACYAABM0PwI2FzYfAhYVFA8BFxQVFAcGByYvAQcGByYnJjU0PwEnJjUAEI9BBQkIBkCPEAdoGQMDBgUGgIEGBQYDAwEYaAcBIwsCFoEMAQEMgRYCCwYIZJABBQUFAwEBAkVFAgEBAwUFAwOQZAkFAAAAAAIAAAANAdsB0gAkAC4AABM0PwI2FzYfAhYVFA8BFxQVFAcmLwEHBgcmJyY1ND8BJyY1HwEHNxcnNy8BBwAQj0EFCQgGQI8QB2gZDAUGgIEGBQYDAwEYaAc/WBVsaxRXeDY2ASMLAhaBDAEBDIEWAgsGCGSQAQUNAQECRUUCAQEDBQUDA5BkCQURVXg4OHhVEW5uAAABACMAKQHdAXwAGgAANzQ/ATYXNh8BNzYXNh8BFhUUDwEGByYvASY1IwgmCAwLCFS8CAsMCCYICPUIDAsIjgjSCwkmCQEBCVS7CQEBCSYJCg0H9gcBAQePBwwAAAEAHwAfAXMBcwAsAAA3ND8BJyY1ND8BNjMyHwE3NjMyHwEWFRQPARcWFRQPAQYjIi8BBwYjIi8BJjUfCFRUCAgnCAwLCFRUCAwLCCcICFRUCAgnCAsMCFRUCAsMCCcIYgsIVFQIDAsIJwgIVFQICCcICwwIVFQICwwIJwgIVFQICCcIDAAAAAACAAAAJQFJAbcAHwArAAA3NTQ3NjsBNTQ3NjMyFxYdATMyFxYdARQHBiMhIicmNTczNTQnJiMiBwYdAQAICAsKJSY1NCYmCQsICAgIC/7tCwgIW5MWFR4fFRZApQsICDc0JiYmJjQ3CAgLpQsICAgIC8A3HhYVFRYeNwAAAQAAAAcBbgG3ACEAADcRNDc2NzYzITIXFhcWFREUBwYHBiMiLwEHBiMiJyYnJjUABgUKBgYBLAYGCgUGBgUKBQcOCn5+Cg4GBgoFBicBcAoICAMDAwMICAr+kAoICAQCCXl5CQIECAgKAAAAAwAAACUCAAFuABgAMQBKAAA3NDc2NzYzMhcWFxYVFAcGBwYjIicmJyY1MxYXFjMyNzY3JicWFRQHBiMiJyY1NDcGBzcUFxYzMjc2NTQ3NjMyNzY1NCcmIyIHBhUABihDREtLREMoBgYoQ0RLS0RDKAYlJjk5Q0M5OSYrQREmJTU1JSYRQSuEBAQGBgQEEREZBgQEBAQGJBkayQoKQSgoKChBCgoKCkEoJycoQQoKOiMjIyM6RCEeIjUmJSUmNSIeIUQlBgQEBAQGGBIRBAQGBgQEGhojAAAABQAAAAkCAAGJACwAOABRAGgAcAAANzQ3Njc2MzIXNzYzMhcWFxYXFhcWFxYVFDEGBwYPAQYjIicmNTQ3JicmJyY1MxYXNyYnJjU0NwYHNxQXFjMyNzY1NDc2MzI3NjU0JyYjIgcGFRc3Njc2NyYnNxYXFhcWFRQHBgcGBwYjPwEWFRQHBgcABitBQU0ZGhADBQEEBAUFBAUEBQEEHjw8Hg4DBQQiBQ0pIyIZBiUvSxYZDg4RQSuEBAQGBgQEEREZBgQEBAQGJBkaVxU9MzQiIDASGxkZEAYGCxQrODk/LlACFxYlyQsJQycnBRwEAgEDAwIDAwIBAwUCNmxsNhkFFAMFBBUTHh8nCQtKISgSHBsfIh4hRCUGBAQEBAYYEhEEBAYGBAQaGiPJJQUiIjYzISASGhkbCgoKChIXMRsbUZANCyghIA8AAAMAAAAAAbcB2wA5AEoAlAAANzU0NzY7ATY3Njc2NzY3Njc2MzIXFhcWFRQHMzIXFhUUBxYVFAcUFRQHFgcGKwEiJyYnJisBIicmNTcUFxYzMjc2NTQnJiMiBwYVFzMyFxYXFhcWFxYXFhcWOwEyNTQnNjc2NTQnNjU0JyYnNjc2NTQnJisBNDc2NTQnJiMGBwYHBgcGBwYHBgcGBwYHBgcGBwYrARUACwoQTgodEQ4GBAMFBgwLDxgTEwoKDjMdFhYOAgoRARkZKCUbGxsjIQZSEAoLJQUFCAcGBQUGBwgFBUkJBAUFBAQHBwMDBwcCPCUjNwIJBQUFDwMDBAkGBgsLDmUODgoJGwgDAwYFDAYQAQUGAwQGBgYFBgUGBgQJSbcPCwsGJhUPCBERExMMCgkJFBQhGxwWFR4ZFQoKFhMGBh0WKBcXBgcMDAoLDxIHBQYGBQcIBQYGBQgSAQEBAQICAQEDAgEULwgIBQoLCgsJDhQHCQkEAQ0NCg8LCxAdHREcDQ4IEBETEw0GFAEHBwUECAgFBQUFAgO3AAADAAD/2wG3AbcAPABNAJkAADc1NDc2OwEyNzY3NjsBMhcWBxUWFRQVFhUUBxYVFAcGKwEWFRQHBgcGIyInJicmJyYnJicmJyYnIyInJjU3FBcWMzI3NjU0JyYjIgcGFRczMhcWFxYXFhcWFxYXFhcWFxYXFhcWFzI3NjU0JyY1MzI3NjU0JyYjNjc2NTQnNjU0JyYnNjU0JyYrASIHIgcGBwYHBgcGIwYrARUACwoQUgYhJRsbHiAoGRkBEQoCDhYWHTMOCgoTExgPCwoFBgIBBAMFDhEdCk4QCgslBQUIBwYFBQYHCAUFSQkEBgYFBgUGBgYEAwYFARAGDAUGAwMIGwkKDg5lDgsLBgYJBAMDDwUFBQkCDg4ZJSU8AgcHAwMHBwQEBQUECbe3DwsKDAwHBhcWJwIWHQYGExYKChUZHhYVHRoiExQJCgsJDg4MDAwNBg4WJQcLCw+kBwUGBgUHCAUGBgUIpAMCBQYFBQcIBAUHBwITBwwTExERBw0OHBEdHRALCw8KDQ0FCQkHFA4JCwoLCgUICBgMCxUDAgEBAgMBAQG3AAAAAQAAAA0A7gHSABQAABM0PwI2FxEHBgcmJyY1ND8BJyY1ABCPQQUJgQYFBgMDARhoBwEjCwIWgQwB/oNFAgEBAwUFAwOQZAkFAAAAAAIAAAAAAgABtwAqAFkAABM0NzYzMhcWFxYXFhc2NzY3Njc2MzIXFhUUDwEGIyIvASYnJicmJyYnJjUzFB8BNzY1NCcmJyYnJicmIyIHBgcGBwYHBiMiJyYnJicmJyYjIgcGBwYHBgcGFQAkJUARExIQEAsMCgoMCxAQEhMRQCUkQbIGBwcGsgMFBQsKCQkGByU1pqY1BgYJCg4NDg0PDhIRDg8KCgcFCQkFBwoKDw4REg4PDQ4NDgoJBgYBMT8jJAYGCwoJCgoKCgkKCwYGJCM/P0GsBQWsAgYFDQ4ODhUUEzA1oJ82MBcSEgoLBgcCAgcHCwsKCQgHBwgJCgsLBwcCAgcGCwoSEhcAAAACAAAABwFuAbcAIQAoAAA3ETQ3Njc2MyEyFxYXFhURFAcGBwYjIi8BBwYjIicmJyY1PwEfAREhEQAGBQoGBgEsBgYKBQYGBQoFBw4Kfn4KDgYGCgUGJZIZef7cJwFwCggIAwMDAwgICv6QCggIBAIJeXkJAgQICAoIjRl0AWP+nQAAAAABAAAAJQHbAbcAMgAANzU0NzY7ATU0NzYzMhcWHQEUBwYrASInJj0BNCcmIyIHBh0BMzIXFh0BFAcGIyEiJyY1AAgIC8AmJjQ1JiUFBQgSCAUFFhUfHhUWHAsICAgIC/7tCwgIQKULCAg3NSUmJiU1SQgFBgYFCEkeFhUVFh43CAgLpQsICAgICwAAAAIAAQANAdsB0gAiAC0AABM2PwI2MzIfAhYXFg8BFxYHBiMiLwEHBiMiJyY/AScmNx8CLwE/AS8CEwEDDJBABggJBUGODgIDCmcYAgQCCAMIf4IFBgYEAgEZaQgC7hBbEgINSnkILgEBJggCFYILC4IVAggICWWPCgUFA0REAwUFCo9lCQipCTBmEw1HEhFc/u0AAAADAAAAAAHJAbcAFAAlAHkAADc1NDc2OwEyFxYdARQHBisBIicmNTcUFxYzMjc2NTQnJiMiBwYVFzU0NzYzNjc2NzY3Njc2NzY3Njc2NzY3NjMyFxYXFhcWFxYXFhUUFRQHBgcGBxQHBgcGBzMyFxYVFAcWFRYHFgcGBxYHBgcjIicmJyYnJiciJyY1AAUGB1MHBQYGBQdTBwYFJQUFCAcGBQUGBwgFBWQFBQgGDw8OFAkFBAQBAQMCAQIEBAYFBw4KCgcHBQQCAwEBAgMDAgYCAgIBAU8XEBAQBQEOBQUECwMREiYlExYXDAwWJAoHBQY3twcGBQUGB7cIBQUFBQgkBwYFBQYHCAUGBgUIJLcHBQYBEBATGQkFCQgGBQwLBgcICQUGAwMFBAcHBgYICQQEBwsLCwYGCgIDBAMCBBEQFhkSDAoVEhAREAsgFBUBBAUEBAcMAQUFCAAAAAADAAD/2wHJAZIAFAAlAHkAADcUFxYXNxY3Nj0BNCcmBycGBwYdATc0NzY3FhcWFRQHBicGJyY1FzU0NzY3Fjc2NzY3NjcXNhcWBxYXFgcWBxQHFhUUBwYHJxYXFhcWFRYXFhcWFRQVFAcGBwYHBgcGBwYnBicmJyYnJicmJyYnJicmJyYnJiciJyY1AAUGB1MHBQYGBQdTBwYFJQUFCAcGBQUGBwgFBWQGBQcKJBYMDBcWEyUmEhEDCwQFBQ4BBRAQEBdPAQECAgIGAgMDAgEBAwIEBQcHCgoOBwUGBAQCAQIDAQEEBAUJFA4PDwYIBQWlBwYFAQEBBwQJtQkEBwEBAQUGB7eTBwYEAQEEBgcJBAYBAQYECZS4BwYEAgENBwUCBgMBAQEXEyEJEhAREBcIDhAaFhEPAQEFAgQCBQELBQcKDAkIBAUHCgUGBwgDBgIEAQEHBQkIBwUMCwcECgcGCRoREQ8CBgQIAAAAAQAAAAEAAJth57dfDzz1AAsCAAAAAADP/GODAAAAAM/8Y4MAAP/bAgAB2wAAAAgAAgAAAAAAAAABAAAB4P/gAAACAAAAAAACAAABAAAAAAAAAAAAAAAAAAAAHAAAAAAAAAAAAAAAAAEAAAACAAAAAgAAAAIAAAACAAAAAgAAAAIAAAACAAAAAdwAAAHcAAACAAAjAZMAHwFJAAABbgAAAgAAAAIAAAACAAAAAgAAAAEAAAACAAAAAW4AAAHcAAAB3AABAdwAAAHcAAAAAAAAAAoAFAAeAEoAcACKAMoBQAGIAcwCCgJUAoICxgMEAzoDpgRKBRgF7AYSBpgG2gcgB2oIGAjOAAAAAQAAABwAmgAFAAAAAAACAAAAAAAAAAAAAAAAAAAAAAAAAA4ArgABAAAAAAABAAwAAAABAAAAAAACAA4AQAABAAAAAAADAAwAIgABAAAAAAAEAAwATgABAAAAAAAFABYADAABAAAAAAAGAAYALgABAAAAAAAKADQAWgADAAEECQABAAwAAAADAAEECQACAA4AQAADAAEECQADAAwAIgADAAEECQAEAAwATgADAAEECQAFABYADAADAAEECQAGAAwANAADAAEECQAKADQAWgByAGEAdABpAG4AZwBWAGUAcgBzAGkAbwBuACAAMQAuADAAcgBhAHQAaQBuAGdyYXRpbmcAcgBhAHQAaQBuAGcAUgBlAGcAdQBsAGEAcgByAGEAdABpAG4AZwBGAG8AbgB0ACAAZwBlAG4AZQByAGEAdABlAGQAIABiAHkAIABJAGMAbwBNAG8AbwBuAC4AAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** data:application/x-font-ttf;charset=utf-8;base64,AAEAAAALAIAAAwAwT1MvMggjCBsAAAC8AAAAYGNtYXCj2pm8AAABHAAAAKRnYXNwAAAAEAAAAcAAAAAIZ2x5ZlJbXMYAAAHIAAARnGhlYWQBGAe5AAATZAAAADZoaGVhA+IB/QAAE5wAAAAkaG10eCzgAEMAABPAAAAAcGxvY2EwXCxOAAAUMAAAADptYXhwACIAnAAAFGwAAAAgbmFtZfC1n04AABSMAAABPHBvc3QAAwAAAAAVyAAAACAAAwIAAZAABQAAAUwBZgAAAEcBTAFmAAAA9QAZAIQAAAAAAAAAAAAAAAAAAAABEAAAAAAAAAAAAAAAAAAAAABAAADxZQHg/+D/4AHgACAAAAABAAAAAAAAAAAAAAAgAAAAAAACAAAAAwAAABQAAwABAAAAFAAEAJAAAAAgACAABAAAAAEAIOYF8AbwDfAj8C7wbvBw8Irwl/Cc8SPxZf/9//8AAAAAACDmAPAE8AzwI/Au8G7wcPCH8JfwnPEj8WT//f//AAH/4xoEEAYQAQ/sD+IPow+iD4wPgA98DvYOtgADAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAH//wAPAAEAAAAAAAAAAAACAAA3OQEAAAAAAQAAAAAAAAAAAAIAADc5AQAAAAABAAAAAAAAAAAAAgAANzkBAAAAAAIAAP/tAgAB0wAKABUAAAEvAQ8BFwc3Fyc3BQc3Jz8BHwEHFycCALFPT7GAHp6eHoD/AHAWW304OH1bFnABGRqgoBp8sFNTsHyyOnxYEnFxElh8OgAAAAACAAD/7QIAAdMACgASAAABLwEPARcHNxcnNwUxER8BBxcnAgCxT0+xgB6enh6A/wA4fVsWcAEZGqCgGnywU1OwfLIBHXESWHw6AAAAAQAA/+0CAAHTAAoAAAEvAQ8BFwc3Fyc3AgCxT0+xgB6enh6AARkaoKAafLBTU7B8AAAAAAEAAAAAAgABwAArAAABFA4CBzEHDgMjIi4CLwEuAzU0PgIzMh4CFz4DMzIeAhUCAAcMEgugBgwMDAYGDAwMBqALEgwHFyg2HhAfGxkKChkbHxAeNigXAS0QHxsZCqAGCwkGBQkLBqAKGRsfEB42KBcHDBILCxIMBxcoNh4AAAAAAgAAAAACAAHAACsAWAAAATQuAiMiDgIHLgMjIg4CFRQeAhcxFx4DMzI+Aj8BPgM1DwEiFCIGMTAmIjQjJy4DNTQ+AjMyHgIfATc+AzMyHgIVFA4CBwIAFyg2HhAfGxkKChkbHxAeNigXBwwSC6AGDAwMBgYMDAwGoAsSDAdbogEBAQEBAaIGCgcEDRceEQkREA4GLy8GDhARCREeFw0EBwoGAS0eNigXBwwSCwsSDAcXKDYeEB8bGQqgBgsJBgUJCwagChkbHxA+ogEBAQGiBg4QEQkRHhcNBAcKBjQ0BgoHBA0XHhEJERAOBgABAAAAAAIAAcAAMQAAARQOAgcxBw4DIyIuAi8BLgM1ND4CMzIeAhcHFwc3Jzc+AzMyHgIVAgAHDBILoAYMDAwGBgwMDAagCxIMBxcoNh4KFRMSCC9wQLBwJwUJCgkFHjYoFwEtEB8bGQqgBgsJBgUJCwagChkbHxAeNigXAwUIBUtAoMBAOwECAQEXKDYeAAABAAAAAAIAAbcAKgAAEzQ3NjMyFxYXFhcWFzY3Njc2NzYzMhcWFRQPAQYjIi8BJicmJyYnJicmNQAkJUARExIQEAsMCgoMCxAQEhMRQCUkQbIGBwcGsgMFBQsKCQkGBwExPyMkBgYLCgkKCgoKCQoLBgYkIz8/QawFBawCBgUNDg4OFRQTAAAAAQAAAA0B2wHSACYAABM0PwI2FzYfAhYVFA8BFxQVFAcGByYvAQcGByYnJjU0PwEnJjUAEI9BBQkIBkCPEAdoGQMDBgUGgIEGBQYDAwEYaAcBIwsCFoEMAQEMgRYCCwYIZJABBQUFAwEBAkVFAgEBAwUFAwOQZAkFAAAAAAIAAAANAdsB0gAkAC4AABM0PwI2FzYfAhYVFA8BFxQVFAcmLwEHBgcmJyY1ND8BJyY1HwEHNxcnNy8BBwAQj0EFCQgGQI8QB2gZDAUGgIEGBQYDAwEYaAc/WBVsaxRXeDY2ASMLAhaBDAEBDIEWAgsGCGSQAQUNAQECRUUCAQEDBQUDA5BkCQURVXg4OHhVEW5uAAABACMAKQHdAXwAGgAANzQ/ATYXNh8BNzYXNh8BFhUUDwEGByYvASY1IwgmCAwLCFS8CAsMCCYICPUIDAsIjgjSCwkmCQEBCVS7CQEBCSYJCg0H9gcBAQePBwwAAAEAHwAfAXMBcwAsAAA3ND8BJyY1ND8BNjMyHwE3NjMyHwEWFRQPARcWFRQPAQYjIi8BBwYjIi8BJjUfCFRUCAgnCAwLCFRUCAwLCCcICFRUCAgnCAsMCFRUCAsMCCcIYgsIVFQIDAsIJwgIVFQICCcICwwIVFQICwwIJwgIVFQICCcIDAAAAAACAAAAJQFJAbcAHwArAAA3NTQ3NjsBNTQ3NjMyFxYdATMyFxYdARQHBiMhIicmNTczNTQnJiMiBwYdAQAICAsKJSY1NCYmCQsICAgIC/7tCwgIW5MWFR4fFRZApQsICDc0JiYmJjQ3CAgLpQsICAgIC8A3HhYVFRYeNwAAAQAAAAcBbgG3ACEAADcRNDc2NzYzITIXFhcWFREUBwYHBiMiLwEHBiMiJyYnJjUABgUKBgYBLAYGCgUGBgUKBQcOCn5+Cg4GBgoFBicBcAoICAMDAwMICAr+kAoICAQCCXl5CQIECAgKAAAAAwAAACUCAAFuABgAMQBKAAA3NDc2NzYzMhcWFxYVFAcGBwYjIicmJyY1MxYXFjMyNzY3JicWFRQHBiMiJyY1NDcGBzcUFxYzMjc2NTQ3NjMyNzY1NCcmIyIHBhUABihDREtLREMoBgYoQ0RLS0RDKAYlJjk5Q0M5OSYrQREmJTU1JSYRQSuEBAQGBgQEEREZBgQEBAQGJBkayQoKQSgoKChBCgoKCkEoJycoQQoKOiMjIyM6RCEeIjUmJSUmNSIeIUQlBgQEBAQGGBIRBAQGBgQEGhojAAAABQAAAAkCAAGJACwAOABRAGgAcAAANzQ3Njc2MzIXNzYzMhcWFxYXFhcWFxYVFDEGBwYPAQYjIicmNTQ3JicmJyY1MxYXNyYnJjU0NwYHNxQXFjMyNzY1NDc2MzI3NjU0JyYjIgcGFRc3Njc2NyYnNxYXFhcWFRQHBgcGBwYjPwEWFRQHBgcABitBQU0ZGhADBQEEBAUFBAUEBQEEHjw8Hg4DBQQiBQ0pIyIZBiUvSxYZDg4RQSuEBAQGBgQEEREZBgQEBAQGJBkaVxU9MzQiIDASGxkZEAYGCxQrODk/LlACFxYlyQsJQycnBRwEAgEDAwIDAwIBAwUCNmxsNhkFFAMFBBUTHh8nCQtKISgSHBsfIh4hRCUGBAQEBAYYEhEEBAYGBAQaGiPJJQUiIjYzISASGhkbCgoKChIXMRsbUZANCyghIA8AAAMAAAAAAbcB2wA5AEoAlAAANzU0NzY7ATY3Njc2NzY3Njc2MzIXFhcWFRQHMzIXFhUUBxYVFAcUFRQHFgcGKwEiJyYnJisBIicmNTcUFxYzMjc2NTQnJiMiBwYVFzMyFxYXFhcWFxYXFhcWOwEyNTQnNjc2NTQnNjU0JyYnNjc2NTQnJisBNDc2NTQnJiMGBwYHBgcGBwYHBgcGBwYHBgcGBwYrARUACwoQTgodEQ4GBAMFBgwLDxgTEwoKDjMdFhYOAgoRARkZKCUbGxsjIQZSEAoLJQUFCAcGBQUGBwgFBUkJBAUFBAQHBwMDBwcCPCUjNwIJBQUFDwMDBAkGBgsLDmUODgoJGwgDAwYFDAYQAQUGAwQGBgYFBgUGBgQJSbcPCwsGJhUPCBERExMMCgkJFBQhGxwWFR4ZFQoKFhMGBh0WKBcXBgcMDAoLDxIHBQYGBQcIBQYGBQgSAQEBAQICAQEDAgEULwgIBQoLCgsJDhQHCQkEAQ0NCg8LCxAdHREcDQ4IEBETEw0GFAEHBwUECAgFBQUFAgO3AAADAAD/2wG3AbcAPABNAJkAADc1NDc2OwEyNzY3NjsBMhcWBxUWFRQVFhUUBxYVFAcGKwEWFRQHBgcGIyInJicmJyYnJicmJyYnIyInJjU3FBcWMzI3NjU0JyYjIgcGFRczMhcWFxYXFhcWFxYXFhcWFxYXFhcWFzI3NjU0JyY1MzI3NjU0JyYjNjc2NTQnNjU0JyYnNjU0JyYrASIHIgcGBwYHBgcGIwYrARUACwoQUgYhJRsbHiAoGRkBEQoCDhYWHTMOCgoTExgPCwoFBgIBBAMFDhEdCk4QCgslBQUIBwYFBQYHCAUFSQkEBgYFBgUGBgYEAwYFARAGDAUGAwMIGwkKDg5lDgsLBgYJBAMDDwUFBQkCDg4ZJSU8AgcHAwMHBwQEBQUECbe3DwsKDAwHBhcWJwIWHQYGExYKChUZHhYVHRoiExQJCgsJDg4MDAwNBg4WJQcLCw+kBwUGBgUHCAUGBgUIpAMCBQYFBQcIBAUHBwITBwwTExERBw0OHBEdHRALCw8KDQ0FCQkHFA4JCwoLCgUICBgMCxUDAgEBAgMBAQG3AAAAAQAAAA0A7gHSABQAABM0PwI2FxEHBgcmJyY1ND8BJyY1ABCPQQUJgQYFBgMDARhoBwEjCwIWgQwB/oNFAgEBAwUFAwOQZAkFAAAAAAIAAAAAAgABtwAqAFkAABM0NzYzMhcWFxYXFhc2NzY3Njc2MzIXFhUUDwEGIyIvASYnJicmJyYnJjUzFB8BNzY1NCcmJyYnJicmIyIHBgcGBwYHBiMiJyYnJicmJyYjIgcGBwYHBgcGFQAkJUARExIQEAsMCgoMCxAQEhMRQCUkQbIGBwcGsgMFBQsKCQkGByU1pqY1BgYJCg4NDg0PDhIRDg8KCgcFCQkFBwoKDw4REg4PDQ4NDgoJBgYBMT8jJAYGCwoJCgoKCgkKCwYGJCM/P0GsBQWsAgYFDQ4ODhUUEzA1oJ82MBcSEgoLBgcCAgcHCwsKCQgHBwgJCgsLBwcCAgcGCwoSEhcAAAACAAAABwFuAbcAIQAoAAA3ETQ3Njc2MyEyFxYXFhURFAcGBwYjIi8BBwYjIicmJyY1PwEfAREhEQAGBQoGBgEsBgYKBQYGBQoFBw4Kfn4KDgYGCgUGJZIZef7cJwFwCggIAwMDAwgICv6QCggIBAIJeXkJAgQICAoIjRl0AWP+nQAAAAABAAAAJQHbAbcAMgAANzU0NzY7ATU0NzYzMhcWHQEUBwYrASInJj0BNCcmIyIHBh0BMzIXFh0BFAcGIyEiJyY1AAgIC8AmJjQ1JiUFBQgSCAUFFhUfHhUWHAsICAgIC/7tCwgIQKULCAg3NSUmJiU1SQgFBgYFCEkeFhUVFh43CAgLpQsICAgICwAAAAIAAQANAdsB0gAiAC0AABM2PwI2MzIfAhYXFg8BFxYHBiMiLwEHBiMiJyY/AScmNx8CLwE/AS8CEwEDDJBABggJBUGODgIDCmcYAgQCCAMIf4IFBgYEAgEZaQgC7hBbEgINSnkILgEBJggCFYILC4IVAggICWWPCgUFA0REAwUFCo9lCQipCTBmEw1HEhFc/u0AAAADAAAAAAHJAbcAFAAlAHkAADc1NDc2OwEyFxYdARQHBisBIicmNTcUFxYzMjc2NTQnJiMiBwYVFzU0NzYzNjc2NzY3Njc2NzY3Njc2NzY3NjMyFxYXFhcWFxYXFhUUFRQHBgcGBxQHBgcGBzMyFxYVFAcWFRYHFgcGBxYHBgcjIicmJyYnJiciJyY1AAUGB1MHBQYGBQdTBwYFJQUFCAcGBQUGBwgFBWQFBQgGDw8OFAkFBAQBAQMCAQIEBAYFBw4KCgcHBQQCAwEBAgMDAgYCAgIBAU8XEBAQBQEOBQUECwMREiYlExYXDAwWJAoHBQY3twcGBQUGB7cIBQUFBQgkBwYFBQYHCAUGBgUIJLcHBQYBEBATGQkFCQgGBQwLBgcICQUGAwMFBAcHBgYICQQEBwsLCwYGCgIDBAMCBBEQFhkSDAoVEhAREAsgFBUBBAUEBAcMAQUFCAAAAAADAAD/2wHJAZIAFAAlAHkAADcUFxYXNxY3Nj0BNCcmBycGBwYdATc0NzY3FhcWFRQHBicGJyY1FzU0NzY3Fjc2NzY3NjcXNhcWBxYXFgcWBxQHFhUUBwYHJxYXFhcWFRYXFhcWFRQVFAcGBwYHBgcGBwYnBicmJyYnJicmJyYnJicmJyYnJiciJyY1AAUGB1MHBQYGBQdTBwYFJQUFCAcGBQUGBwgFBWQGBQcKJBYMDBcWEyUmEhEDCwQFBQ4BBRAQEBdPAQECAgIGAgMDAgEBAwIEBQcHCgoOBwUGBAQCAQIDAQEEBAUJFA4PDwYIBQWlBwYFAQEBBwQJtQkEBwEBAQUGB7eTBwYEAQEEBgcJBAYBAQYECZS4BwYEAgENBwUCBgMBAQEXEyEJEhAREBcIDhAaFhEPAQEFAgQCBQELBQcKDAkIBAUHCgUGBwgDBgIEAQEHBQkIBwUMCwcECgcGCRoREQ8CBgQIAAAAAQAAAAEAAJth57dfDzz1AAsCAAAAAADP/GODAAAAAM/8Y4MAAP/bAgAB2wAAAAgAAgAAAAAAAAABAAAB4P/gAAACAAAAAAACAAABAAAAAAAAAAAAAAAAAAAAHAAAAAAAAAAAAAAAAAEAAAACAAAAAgAAAAIAAAACAAAAAgAAAAIAAAACAAAAAdwAAAHcAAACAAAjAZMAHwFJAAABbgAAAgAAAAIAAAACAAAAAgAAAAEAAAACAAAAAW4AAAHcAAAB3AABAdwAAAHcAAAAAAAAAAoAFAAeAEoAcACKAMoBQAGIAcwCCgJUAoICxgMEAzoDpgRKBRgF7AYSBpgG2gcgB2oIGAjOAAAAAQAAABwAmgAFAAAAAAACAAAAAAAAAAAAAAAAAAAAAAAAAA4ArgABAAAAAAABAAwAAAABAAAAAAACAA4AQAABAAAAAAADAAwAIgABAAAAAAAEAAwATgABAAAAAAAFABYADAABAAAAAAAGAAYALgABAAAAAAAKADQAWgADAAEECQABAAwAAAADAAEECQACAA4AQAADAAEECQADAAwAIgADAAEECQAEAAwATgADAAEECQAFABYADAADAAEECQAGAAwANAADAAEECQAKADQAWgByAGEAdABpAG4AZwBWAGUAcgBzAGkAbwBuACAAMQAuADAAcgBhAHQAaQBuAGdyYXRpbmcAcgBhAHQAaQBuAGcAUgBlAGcAdQBsAGEAcgByAGEAdABpAG4AZwBGAG8AbgB0ACAAZwBlAG4AZQByAGEAdABlAGQAIABiAHkAIABJAGMAbwBNAG8AbwBuAC4AAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA== ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "data:application/x-font-ttf;charset=utf-8;base64,AAEAAAALAIAAAwAwT1MvMggjCBsAAAC8AAAAYGNtYXCj2pm8AAABHAAAAKRnYXNwAAAAEAAAAcAAAAAIZ2x5ZlJbXMYAAAHIAAARnGhlYWQBGAe5AAATZAAAADZoaGVhA+IB/QAAE5wAAAAkaG10eCzgAEMAABPAAAAAcGxvY2EwXCxOAAAUMAAAADptYXhwACIAnAAAFGwAAAAgbmFtZfC1n04AABSMAAABPHBvc3QAAwAAAAAVyAAAACAAAwIAAZAABQAAAUwBZgAAAEcBTAFmAAAA9QAZAIQAAAAAAAAAAAAAAAAAAAABEAAAAAAAAAAAAAAAAAAAAABAAADxZQHg/+D/4AHgACAAAAABAAAAAAAAAAAAAAAgAAAAAAACAAAAAwAAABQAAwABAAAAFAAEAJAAAAAgACAABAAAAAEAIOYF8AbwDfAj8C7wbvBw8Irwl/Cc8SPxZf/9//8AAAAAACDmAPAE8AzwI/Au8G7wcPCH8JfwnPEj8WT//f//AAH/4xoEEAYQAQ/sD+IPow+iD4wPgA98DvYOtgADAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAH//wAPAAEAAAAAAAAAAAACAAA3OQEAAAAAAQAAAAAAAAAAAAIAADc5AQAAAAABAAAAAAAAAAAAAgAANzkBAAAAAAIAAP/tAgAB0wAKABUAAAEvAQ8BFwc3Fyc3BQc3Jz8BHwEHFycCALFPT7GAHp6eHoD/AHAWW304OH1bFnABGRqgoBp8sFNTsHyyOnxYEnFxElh8OgAAAAACAAD/7QIAAdMACgASAAABLwEPARcHNxcnNwUxER8BBxcnAgCxT0+xgB6enh6A/wA4fVsWcAEZGqCgGnywU1OwfLIBHXESWHw6AAAAAQAA/+0CAAHTAAoAAAEvAQ8BFwc3Fyc3AgCxT0+xgB6enh6AARkaoKAafLBTU7B8AAAAAAEAAAAAAgABwAArAAABFA4CBzEHDgMjIi4CLwEuAzU0PgIzMh4CFz4DMzIeAhUCAAcMEgugBgwMDAYGDAwMBqALEgwHFyg2HhAfGxkKChkbHxAeNigXAS0QHxsZCqAGCwkGBQkLBqAKGRsfEB42KBcHDBILCxIMBxcoNh4AAAAAAgAAAAACAAHAACsAWAAAATQuAiMiDgIHLgMjIg4CFRQeAhcxFx4DMzI+Aj8BPgM1DwEiFCIGMTAmIjQjJy4DNTQ+AjMyHgIfATc+AzMyHgIVFA4CBwIAFyg2HhAfGxkKChkbHxAeNigXBwwSC6AGDAwMBgYMDAwGoAsSDAdbogEBAQEBAaIGCgcEDRceEQkREA4GLy8GDhARCREeFw0EBwoGAS0eNigXBwwSCwsSDAcXKDYeEB8bGQqgBgsJBgUJCwagChkbHxA+ogEBAQGiBg4QEQkRHhcNBAcKBjQ0BgoHBA0XHhEJERAOBgABAAAAAAIAAcAAMQAAARQOAgcxBw4DIyIuAi8BLgM1ND4CMzIeAhcHFwc3Jzc+AzMyHgIVAgAHDBILoAYMDAwGBgwMDAagCxIMBxcoNh4KFRMSCC9wQLBwJwUJCgkFHjYoFwEtEB8bGQqgBgsJBgUJCwagChkbHxAeNigXAwUIBUtAoMBAOwECAQEXKDYeAAABAAAAAAIAAbcAKgAAEzQ3NjMyFxYXFhcWFzY3Njc2NzYzMhcWFRQPAQYjIi8BJicmJyYnJicmNQAkJUARExIQEAsMCgoMCxAQEhMRQCUkQbIGBwcGsgMFBQsKCQkGBwExPyMkBgYLCgkKCgoKCQoLBgYkIz8/QawFBawCBgUNDg4OFRQTAAAAAQAAAA0B2wHSACYAABM0PwI2FzYfAhYVFA8BFxQVFAcGByYvAQcGByYnJjU0PwEnJjUAEI9BBQkIBkCPEAdoGQMDBgUGgIEGBQYDAwEYaAcBIwsCFoEMAQEMgRYCCwYIZJABBQUFAwEBAkVFAgEBAwUFAwOQZAkFAAAAAAIAAAANAdsB0gAkAC4AABM0PwI2FzYfAhYVFA8BFxQVFAcmLwEHBgcmJyY1ND8BJyY1HwEHNxcnNy8BBwAQj0EFCQgGQI8QB2gZDAUGgIEGBQYDAwEYaAc/WBVsaxRXeDY2ASMLAhaBDAEBDIEWAgsGCGSQAQUNAQECRUUCAQEDBQUDA5BkCQURVXg4OHhVEW5uAAABACMAKQHdAXwAGgAANzQ/ATYXNh8BNzYXNh8BFhUUDwEGByYvASY1IwgmCAwLCFS8CAsMCCYICPUIDAsIjgjSCwkmCQEBCVS7CQEBCSYJCg0H9gcBAQePBwwAAAEAHwAfAXMBcwAsAAA3ND8BJyY1ND8BNjMyHwE3NjMyHwEWFRQPARcWFRQPAQYjIi8BBwYjIi8BJjUfCFRUCAgnCAwLCFRUCAwLCCcICFRUCAgnCAsMCFRUCAsMCCcIYgsIVFQIDAsIJwgIVFQICCcICwwIVFQICwwIJwgIVFQICCcIDAAAAAACAAAAJQFJAbcAHwArAAA3NTQ3NjsBNTQ3NjMyFxYdATMyFxYdARQHBiMhIicmNTczNTQnJiMiBwYdAQAICAsKJSY1NCYmCQsICAgIC/7tCwgIW5MWFR4fFRZApQsICDc0JiYmJjQ3CAgLpQsICAgIC8A3HhYVFRYeNwAAAQAAAAcBbgG3ACEAADcRNDc2NzYzITIXFhcWFREUBwYHBiMiLwEHBiMiJyYnJjUABgUKBgYBLAYGCgUGBgUKBQcOCn5+Cg4GBgoFBicBcAoICAMDAwMICAr+kAoICAQCCXl5CQIECAgKAAAAAwAAACUCAAFuABgAMQBKAAA3NDc2NzYzMhcWFxYVFAcGBwYjIicmJyY1MxYXFjMyNzY3JicWFRQHBiMiJyY1NDcGBzcUFxYzMjc2NTQ3NjMyNzY1NCcmIyIHBhUABihDREtLREMoBgYoQ0RLS0RDKAYlJjk5Q0M5OSYrQREmJTU1JSYRQSuEBAQGBgQEEREZBgQEBAQGJBkayQoKQSgoKChBCgoKCkEoJycoQQoKOiMjIyM6RCEeIjUmJSUmNSIeIUQlBgQEBAQGGBIRBAQGBgQEGhojAAAABQAAAAkCAAGJACwAOABRAGgAcAAANzQ3Njc2MzIXNzYzMhcWFxYXFhcWFxYVFDEGBwYPAQYjIicmNTQ3JicmJyY1MxYXNyYnJjU0NwYHNxQXFjMyNzY1NDc2MzI3NjU0JyYjIgcGFRc3Njc2NyYnNxYXFhcWFRQHBgcGBwYjPwEWFRQHBgcABitBQU0ZGhADBQEEBAUFBAUEBQEEHjw8Hg4DBQQiBQ0pIyIZBiUvSxYZDg4RQSuEBAQGBgQEEREZBgQEBAQGJBkaVxU9MzQiIDASGxkZEAYGCxQrODk/LlACFxYlyQsJQycnBRwEAgEDAwIDAwIBAwUCNmxsNhkFFAMFBBUTHh8nCQtKISgSHBsfIh4hRCUGBAQEBAYYEhEEBAYGBAQaGiPJJQUiIjYzISASGhkbCgoKChIXMRsbUZANCyghIA8AAAMAAAAAAbcB2wA5AEoAlAAANzU0NzY7ATY3Njc2NzY3Njc2MzIXFhcWFRQHMzIXFhUUBxYVFAcUFRQHFgcGKwEiJyYnJisBIicmNTcUFxYzMjc2NTQnJiMiBwYVFzMyFxYXFhcWFxYXFhcWOwEyNTQnNjc2NTQnNjU0JyYnNjc2NTQnJisBNDc2NTQnJiMGBwYHBgcGBwYHBgcGBwYHBgcGBwYrARUACwoQTgodEQ4GBAMFBgwLDxgTEwoKDjMdFhYOAgoRARkZKCUbGxsjIQZSEAoLJQUFCAcGBQUGBwgFBUkJBAUFBAQHBwMDBwcCPCUjNwIJBQUFDwMDBAkGBgsLDmUODgoJGwgDAwYFDAYQAQUGAwQGBgYFBgUGBgQJSbcPCwsGJhUPCBERExMMCgkJFBQhGxwWFR4ZFQoKFhMGBh0WKBcXBgcMDAoLDxIHBQYGBQcIBQYGBQgSAQEBAQICAQEDAgEULwgIBQoLCgsJDhQHCQkEAQ0NCg8LCxAdHREcDQ4IEBETEw0GFAEHBwUECAgFBQUFAgO3AAADAAD/2wG3AbcAPABNAJkAADc1NDc2OwEyNzY3NjsBMhcWBxUWFRQVFhUUBxYVFAcGKwEWFRQHBgcGIyInJicmJyYnJicmJyYnIyInJjU3FBcWMzI3NjU0JyYjIgcGFRczMhcWFxYXFhcWFxYXFhcWFxYXFhcWFzI3NjU0JyY1MzI3NjU0JyYjNjc2NTQnNjU0JyYnNjU0JyYrASIHIgcGBwYHBgcGIwYrARUACwoQUgYhJRsbHiAoGRkBEQoCDhYWHTMOCgoTExgPCwoFBgIBBAMFDhEdCk4QCgslBQUIBwYFBQYHCAUFSQkEBgYFBgUGBgYEAwYFARAGDAUGAwMIGwkKDg5lDgsLBgYJBAMDDwUFBQkCDg4ZJSU8AgcHAwMHBwQEBQUECbe3DwsKDAwHBhcWJwIWHQYGExYKChUZHhYVHRoiExQJCgsJDg4MDAwNBg4WJQcLCw+kBwUGBgUHCAUGBgUIpAMCBQYFBQcIBAUHBwITBwwTExERBw0OHBEdHRALCw8KDQ0FCQkHFA4JCwoLCgUICBgMCxUDAgEBAgMBAQG3AAAAAQAAAA0A7gHSABQAABM0PwI2FxEHBgcmJyY1ND8BJyY1ABCPQQUJgQYFBgMDARhoBwEjCwIWgQwB/oNFAgEBAwUFAwOQZAkFAAAAAAIAAAAAAgABtwAqAFkAABM0NzYzMhcWFxYXFhc2NzY3Njc2MzIXFhUUDwEGIyIvASYnJicmJyYnJjUzFB8BNzY1NCcmJyYnJicmIyIHBgcGBwYHBiMiJyYnJicmJyYjIgcGBwYHBgcGFQAkJUARExIQEAsMCgoMCxAQEhMRQCUkQbIGBwcGsgMFBQsKCQkGByU1pqY1BgYJCg4NDg0PDhIRDg8KCgcFCQkFBwoKDw4REg4PDQ4NDgoJBgYBMT8jJAYGCwoJCgoKCgkKCwYGJCM/P0GsBQWsAgYFDQ4ODhUUEzA1oJ82MBcSEgoLBgcCAgcHCwsKCQgHBwgJCgsLBwcCAgcGCwoSEhcAAAACAAAABwFuAbcAIQAoAAA3ETQ3Njc2MyEyFxYXFhURFAcGBwYjIi8BBwYjIicmJyY1PwEfAREhEQAGBQoGBgEsBgYKBQYGBQoFBw4Kfn4KDgYGCgUGJZIZef7cJwFwCggIAwMDAwgICv6QCggIBAIJeXkJAgQICAoIjRl0AWP+nQAAAAABAAAAJQHbAbcAMgAANzU0NzY7ATU0NzYzMhcWHQEUBwYrASInJj0BNCcmIyIHBh0BMzIXFh0BFAcGIyEiJyY1AAgIC8AmJjQ1JiUFBQgSCAUFFhUfHhUWHAsICAgIC/7tCwgIQKULCAg3NSUmJiU1SQgFBgYFCEkeFhUVFh43CAgLpQsICAgICwAAAAIAAQANAdsB0gAiAC0AABM2PwI2MzIfAhYXFg8BFxYHBiMiLwEHBiMiJyY/AScmNx8CLwE/AS8CEwEDDJBABggJBUGODgIDCmcYAgQCCAMIf4IFBgYEAgEZaQgC7hBbEgINSnkILgEBJggCFYILC4IVAggICWWPCgUFA0REAwUFCo9lCQipCTBmEw1HEhFc/u0AAAADAAAAAAHJAbcAFAAlAHkAADc1NDc2OwEyFxYdARQHBisBIicmNTcUFxYzMjc2NTQnJiMiBwYVFzU0NzYzNjc2NzY3Njc2NzY3Njc2NzY3NjMyFxYXFhcWFxYXFhUUFRQHBgcGBxQHBgcGBzMyFxYVFAcWFRYHFgcGBxYHBgcjIicmJyYnJiciJyY1AAUGB1MHBQYGBQdTBwYFJQUFCAcGBQUGBwgFBWQFBQgGDw8OFAkFBAQBAQMCAQIEBAYFBw4KCgcHBQQCAwEBAgMDAgYCAgIBAU8XEBAQBQEOBQUECwMREiYlExYXDAwWJAoHBQY3twcGBQUGB7cIBQUFBQgkBwYFBQYHCAUGBgUIJLcHBQYBEBATGQkFCQgGBQwLBgcICQUGAwMFBAcHBgYICQQEBwsLCwYGCgIDBAMCBBEQFhkSDAoVEhAREAsgFBUBBAUEBAcMAQUFCAAAAAADAAD/2wHJAZIAFAAlAHkAADcUFxYXNxY3Nj0BNCcmBycGBwYdATc0NzY3FhcWFRQHBicGJyY1FzU0NzY3Fjc2NzY3NjcXNhcWBxYXFgcWBxQHFhUUBwYHJxYXFhcWFRYXFhcWFRQVFAcGBwYHBgcGBwYnBicmJyYnJicmJyYnJicmJyYnJiciJyY1AAUGB1MHBQYGBQdTBwYFJQUFCAcGBQUGBwgFBWQGBQcKJBYMDBcWEyUmEhEDCwQFBQ4BBRAQEBdPAQECAgIGAgMDAgEBAwIEBQcHCgoOBwUGBAQCAQIDAQEEBAUJFA4PDwYIBQWlBwYFAQEBBwQJtQkEBwEBAQUGB7eTBwYEAQEEBgcJBAYBAQYECZS4BwYEAgENBwUCBgMBAQEXEyEJEhAREBcIDhAaFhEPAQEFAgQCBQELBQcKDAkIBAUHCgUGBwgDBgIEAQEHBQkIBwUMCwcECgcGCRoREQ8CBgQIAAAAAQAAAAEAAJth57dfDzz1AAsCAAAAAADP/GODAAAAAM/8Y4MAAP/bAgAB2wAAAAgAAgAAAAAAAAABAAAB4P/gAAACAAAAAAACAAABAAAAAAAAAAAAAAAAAAAAHAAAAAAAAAAAAAAAAAEAAAACAAAAAgAAAAIAAAACAAAAAgAAAAIAAAACAAAAAdwAAAHcAAACAAAjAZMAHwFJAAABbgAAAgAAAAIAAAACAAAAAgAAAAEAAAACAAAAAW4AAAHcAAAB3AABAdwAAAHcAAAAAAAAAAoAFAAeAEoAcACKAMoBQAGIAcwCCgJUAoICxgMEAzoDpgRKBRgF7AYSBpgG2gcgB2oIGAjOAAAAAQAAABwAmgAFAAAAAAACAAAAAAAAAAAAAAAAAAAAAAAAAA4ArgABAAAAAAABAAwAAAABAAAAAAACAA4AQAABAAAAAAADAAwAIgABAAAAAAAEAAwATgABAAAAAAAFABYADAABAAAAAAAGAAYALgABAAAAAAAKADQAWgADAAEECQABAAwAAAADAAEECQACAA4AQAADAAEECQADAAwAIgADAAEECQAEAAwATgADAAEECQAFABYADAADAAEECQAGAAwANAADAAEECQAKADQAWgByAGEAdABpAG4AZwBWAGUAcgBzAGkAbwBuACAAMQAuADAAcgBhAHQAaQBuAGdyYXRpbmcAcgBhAHQAaQBuAGcAUgBlAGcAdQBsAGEAcgByAGEAdABpAG4AZwBGAG8AbgB0ACAAZwBlAG4AZQByAGEAdABlAGQAIABiAHkAIABJAGMAbwBNAG8AbwBuAC4AAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==";

/***/ }),

/***/ "data:application/x-font-ttf;charset=utf-8;base64,AAEAAAAOAIAAAwBgT1MvMj3hSQEAAADsAAAAVmNtYXDQEhm3AAABRAAAAUpjdnQgBkn/lAAABuwAAAAcZnBnbYoKeDsAAAcIAAAJkWdhc3AAAAAQAAAG5AAAAAhnbHlm32cEdgAAApAAAAC2aGVhZAErPHsAAANIAAAANmhoZWEHUwNNAAADgAAAACRobXR4CykAAAAAA6QAAAAMbG9jYQA4AFsAAAOwAAAACG1heHAApgm8AAADuAAAACBuYW1lzJ0aHAAAA9gAAALNcG9zdK69QJgAAAaoAAAAO3ByZXCSoZr/AAAQnAAAAFYAAQO4AZAABQAIAnoCvAAAAIwCegK8AAAB4AAxAQIAAAIABQMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUGZFZABA6ADoAQNS/2oAWgMLAE8AAAABAAAAAAAAAAAAAwAAAAMAAAAcAAEAAAAAAEQAAwABAAAAHAAEACgAAAAGAAQAAQACAADoAf//AAAAAOgA//8AABgBAAEAAAAAAAAAAAEGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAADpAKYABUAHEAZDwEAAQFCAAIBAmoAAQABagAAAGEUFxQDEisBFAcBBiInASY0PwE2Mh8BATYyHwEWA6QP/iAQLBD+6g8PTBAsEKQBbhAsEEwPAhYWEP4gDw8BFhAsEEwQEKUBbxAQTBAAAAH//f+xA18DCwAMABJADwABAQpDAAAACwBEFRMCESsBFA4BIi4CPgEyHgEDWXLG6MhuBnq89Lp+AV51xHR0xOrEdHTEAAAAAAEAAAABAADDeRpdXw889QALA+gAAAAAzzWYjQAAAADPNWBN//3/sQOkAwsAAAAIAAIAAAAAAAAAAQAAA1L/agBaA+gAAP/3A6QAAQAAAAAAAAAAAAAAAAAAAAMD6AAAA+gAAANZAAAAAAAAADgAWwABAAAAAwAWAAEAAAAAAAIABgATAG4AAAAtCZEAAAAAAAAAEgDeAAEAAAAAAAAANQAAAAEAAAAAAAEACAA1AAEAAAAAAAIABwA9AAEAAAAAAAMACABEAAEAAAAAAAQACABMAAEAAAAAAAUACwBUAAEAAAAAAAYACABfAAEAAAAAAAoAKwBnAAEAAAAAAAsAEwCSAAMAAQQJAAAAagClAAMAAQQJAAEAEAEPAAMAAQQJAAIADgEfAAMAAQQJAAMAEAEtAAMAAQQJAAQAEAE9AAMAAQQJAAUAFgFNAAMAAQQJAAYAEAFjAAMAAQQJAAoAVgFzAAMAAQQJAAsAJgHJQ29weXJpZ2h0IChDKSAyMDE0IGJ5IG9yaWdpbmFsIGF1dGhvcnMgQCBmb250ZWxsby5jb21mb250ZWxsb1JlZ3VsYXJmb250ZWxsb2ZvbnRlbGxvVmVyc2lvbiAxLjBmb250ZWxsb0dlbmVyYXRlZCBieSBzdmcydHRmIGZyb20gRm9udGVsbG8gcHJvamVjdC5odHRwOi8vZm9udGVsbG8uY29tAEMAbwBwAHkAcgBpAGcAaAB0ACAAKABDACkAIAAyADAAMQA0ACAAYgB5ACAAbwByAGkAZwBpAG4AYQBsACAAYQB1AHQAaABvAHIAcwAgAEAAIABmAG8AbgB0AGUAbABsAG8ALgBjAG8AbQBmAG8AbgB0AGUAbABsAG8AUgBlAGcAdQBsAGEAcgBmAG8AbgB0AGUAbABsAG8AZgBvAG4AdABlAGwAbABvAFYAZQByAHMAaQBvAG4AIAAxAC4AMABmAG8AbgB0AGUAbABsAG8ARwBlAG4AZQByAGEAdABlAGQAIABiAHkAIABzAHYAZwAyAHQAdABmACAAZgByAG8AbQAgAEYAbwBuAHQAZQBsAGwAbwAgAHAAcgBvAGoAZQBjAHQALgBoAHQAdABwADoALwAvAGYAbwBuAHQAZQBsAGwAbwAuAGMAbwBtAAAAAAIAAAAAAAAACgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwAAAQIBAwljaGVja21hcmsGY2lyY2xlAAAAAAEAAf//AA8AAAAAAAAAAAAAAAAAAAAAADIAMgML/7EDC/+xsAAssCBgZi2wASwgZCCwwFCwBCZasARFW1ghIyEbilggsFBQWCGwQFkbILA4UFghsDhZWSCwCkVhZLAoUFghsApFILAwUFghsDBZGyCwwFBYIGYgiophILAKUFhgGyCwIFBYIbAKYBsgsDZQWCGwNmAbYFlZWRuwACtZWSOwAFBYZVlZLbACLCBFILAEJWFkILAFQ1BYsAUjQrAGI0IbISFZsAFgLbADLCMhIyEgZLEFYkIgsAYjQrIKAAIqISCwBkMgiiCKsAArsTAFJYpRWGBQG2FSWVgjWSEgsEBTWLAAKxshsEBZI7AAUFhlWS2wBCywB0MrsgACAENgQi2wBSywByNCIyCwACNCYbCAYrABYLAEKi2wBiwgIEUgsAJFY7ABRWJgRLABYC2wBywgIEUgsAArI7ECBCVgIEWKI2EgZCCwIFBYIbAAG7AwUFiwIBuwQFlZI7AAUFhlWbADJSNhRESwAWAtsAgssQUFRbABYUQtsAkssAFgICCwCUNKsABQWCCwCSNCWbAKQ0qwAFJYILAKI0JZLbAKLCC4BABiILgEAGOKI2GwC0NgIIpgILALI0IjLbALLEtUWLEHAURZJLANZSN4LbAMLEtRWEtTWLEHAURZGyFZJLATZSN4LbANLLEADENVWLEMDEOwAWFCsAorWbAAQ7ACJUKxCQIlQrEKAiVCsAEWIyCwAyVQWLEBAENgsAQlQoqKIIojYbAJKiEjsAFhIIojYbAJKiEbsQEAQ2CwAiVCsAIlYbAJKiFZsAlDR7AKQ0dgsIBiILACRWOwAUViYLEAABMjRLABQ7AAPrIBAQFDYEItsA4ssQAFRVRYALAMI0IgYLABYbUNDQEACwBCQopgsQ0FK7BtKxsiWS2wDyyxAA4rLbAQLLEBDistsBEssQIOKy2wEiyxAw4rLbATLLEEDistsBQssQUOKy2wFSyxBg4rLbAWLLEHDistsBcssQgOKy2wGCyxCQ4rLbAZLLAIK7EABUVUWACwDCNCIGCwAWG1DQ0BAAsAQkKKYLENBSuwbSsbIlktsBossQAZKy2wGyyxARkrLbAcLLECGSstsB0ssQMZKy2wHiyxBBkrLbAfLLEFGSstsCAssQYZKy2wISyxBxkrLbAiLLEIGSstsCMssQkZKy2wJCwgPLABYC2wJSwgYLANYCBDI7ABYEOwAiVhsAFgsCQqIS2wJiywJSuwJSotsCcsICBHICCwAkVjsAFFYmAjYTgjIIpVWCBHICCwAkVjsAFFYmAjYTgbIVktsCgssQAFRVRYALABFrAnKrABFTAbIlktsCkssAgrsQAFRVRYALABFrAnKrABFTAbIlktsCosIDWwAWAtsCssALADRWOwAUVisAArsAJFY7ABRWKwACuwABa0AAAAAABEPiM4sSoBFSotsCwsIDwgRyCwAkVjsAFFYmCwAENhOC2wLSwuFzwtsC4sIDwgRyCwAkVjsAFFYmCwAENhsAFDYzgtsC8ssQIAFiUgLiBHsAAjQrACJUmKikcjRyNhIFhiGyFZsAEjQrIuAQEVFCotsDAssAAWsAQlsAQlRyNHI2GwBkUrZYouIyAgPIo4LbAxLLAAFrAEJbAEJSAuRyNHI2EgsAQjQrAGRSsgsGBQWCCwQFFYswIgAyAbswImAxpZQkIjILAIQyCKI0cjRyNhI0ZgsARDsIBiYCCwACsgiophILACQ2BkI7ADQ2FkUFiwAkNhG7ADQ2BZsAMlsIBiYSMgILAEJiNGYTgbI7AIQ0awAiWwCENHI0cjYWAgsARDsIBiYCMgsAArI7AEQ2CwACuwBSVhsAUlsIBisAQmYSCwBCVgZCOwAyVgZFBYIRsjIVkjICCwBCYjRmE4WS2wMiywABYgICCwBSYgLkcjRyNhIzw4LbAzLLAAFiCwCCNCICAgRiNHsAArI2E4LbA0LLAAFrADJbACJUcjRyNhsABUWC4gPCMhG7ACJbACJUcjRyNhILAFJbAEJUcjRyNhsAYlsAUlSbACJWGwAUVjIyBYYhshWWOwAUViYCMuIyAgPIo4IyFZLbA1LLAAFiCwCEMgLkcjRyNhIGCwIGBmsIBiIyAgPIo4LbA2LCMgLkawAiVGUlggPFkusSYBFCstsDcsIyAuRrACJUZQWCA8WS6xJgEUKy2wOCwjIC5GsAIlRlJYIDxZIyAuRrACJUZQWCA8WS6xJgEUKy2wOSywMCsjIC5GsAIlRlJYIDxZLrEmARQrLbA6LLAxK4ogIDywBCNCijgjIC5GsAIlRlJYIDxZLrEmARQrsARDLrAmKy2wOyywABawBCWwBCYgLkcjRyNhsAZFKyMgPCAuIzixJgEUKy2wPCyxCAQlQrAAFrAEJbAEJSAuRyNHI2EgsAQjQrAGRSsgsGBQWCCwQFFYswIgAyAbswImAxpZQkIjIEewBEOwgGJgILAAKyCKimEgsAJDYGQjsANDYWRQWLACQ2EbsANDYFmwAyWwgGJhsAIlRmE4IyA8IzgbISAgRiNHsAArI2E4IVmxJgEUKy2wPSywMCsusSYBFCstsD4ssDErISMgIDywBCNCIzixJgEUK7AEQy6wJistsD8ssAAVIEewACNCsgABARUUEy6wLCotsEAssAAVIEewACNCsgABARUUEy6wLCotsEEssQABFBOwLSotsEIssC8qLbBDLLAAFkUjIC4gRoojYTixJgEUKy2wRCywCCNCsEMrLbBFLLIAADwrLbBGLLIAATwrLbBHLLIBADwrLbBILLIBATwrLbBJLLIAAD0rLbBKLLIAAT0rLbBLLLIBAD0rLbBMLLIBAT0rLbBNLLIAADkrLbBOLLIAATkrLbBPLLIBADkrLbBQLLIBATkrLbBRLLIAADsrLbBSLLIAATsrLbBTLLIBADsrLbBULLIBATsrLbBVLLIAAD4rLbBWLLIAAT4rLbBXLLIBAD4rLbBYLLIBAT4rLbBZLLIAADorLbBaLLIAATorLbBbLLIBADorLbBcLLIBATorLbBdLLAyKy6xJgEUKy2wXiywMiuwNistsF8ssDIrsDcrLbBgLLAAFrAyK7A4Ky2wYSywMysusSYBFCstsGIssDMrsDYrLbBjLLAzK7A3Ky2wZCywMyuwOCstsGUssDQrLrEmARQrLbBmLLA0K7A2Ky2wZyywNCuwNystsGgssDQrsDgrLbBpLLA1Ky6xJgEUKy2waiywNSuwNistsGsssDUrsDcrLbBsLLA1K7A4Ky2wbSwrsAhlsAMkUHiwARUwLQAAAEu4AMhSWLEBAY5ZuQgACABjILABI0SwAyNwsgQoCUVSRLIKAgcqsQYBRLEkAYhRWLBAiFixBgNEsSYBiFFYuAQAiFixBgFEWVlZWbgB/4WwBI2xBQBEAAA=":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** data:application/x-font-ttf;charset=utf-8;base64,AAEAAAAOAIAAAwBgT1MvMj3hSQEAAADsAAAAVmNtYXDQEhm3AAABRAAAAUpjdnQgBkn/lAAABuwAAAAcZnBnbYoKeDsAAAcIAAAJkWdhc3AAAAAQAAAG5AAAAAhnbHlm32cEdgAAApAAAAC2aGVhZAErPHsAAANIAAAANmhoZWEHUwNNAAADgAAAACRobXR4CykAAAAAA6QAAAAMbG9jYQA4AFsAAAOwAAAACG1heHAApgm8AAADuAAAACBuYW1lzJ0aHAAAA9gAAALNcG9zdK69QJgAAAaoAAAAO3ByZXCSoZr/AAAQnAAAAFYAAQO4AZAABQAIAnoCvAAAAIwCegK8AAAB4AAxAQIAAAIABQMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUGZFZABA6ADoAQNS/2oAWgMLAE8AAAABAAAAAAAAAAAAAwAAAAMAAAAcAAEAAAAAAEQAAwABAAAAHAAEACgAAAAGAAQAAQACAADoAf//AAAAAOgA//8AABgBAAEAAAAAAAAAAAEGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAADpAKYABUAHEAZDwEAAQFCAAIBAmoAAQABagAAAGEUFxQDEisBFAcBBiInASY0PwE2Mh8BATYyHwEWA6QP/iAQLBD+6g8PTBAsEKQBbhAsEEwPAhYWEP4gDw8BFhAsEEwQEKUBbxAQTBAAAAH//f+xA18DCwAMABJADwABAQpDAAAACwBEFRMCESsBFA4BIi4CPgEyHgEDWXLG6MhuBnq89Lp+AV51xHR0xOrEdHTEAAAAAAEAAAABAADDeRpdXw889QALA+gAAAAAzzWYjQAAAADPNWBN//3/sQOkAwsAAAAIAAIAAAAAAAAAAQAAA1L/agBaA+gAAP/3A6QAAQAAAAAAAAAAAAAAAAAAAAMD6AAAA+gAAANZAAAAAAAAADgAWwABAAAAAwAWAAEAAAAAAAIABgATAG4AAAAtCZEAAAAAAAAAEgDeAAEAAAAAAAAANQAAAAEAAAAAAAEACAA1AAEAAAAAAAIABwA9AAEAAAAAAAMACABEAAEAAAAAAAQACABMAAEAAAAAAAUACwBUAAEAAAAAAAYACABfAAEAAAAAAAoAKwBnAAEAAAAAAAsAEwCSAAMAAQQJAAAAagClAAMAAQQJAAEAEAEPAAMAAQQJAAIADgEfAAMAAQQJAAMAEAEtAAMAAQQJAAQAEAE9AAMAAQQJAAUAFgFNAAMAAQQJAAYAEAFjAAMAAQQJAAoAVgFzAAMAAQQJAAsAJgHJQ29weXJpZ2h0IChDKSAyMDE0IGJ5IG9yaWdpbmFsIGF1dGhvcnMgQCBmb250ZWxsby5jb21mb250ZWxsb1JlZ3VsYXJmb250ZWxsb2ZvbnRlbGxvVmVyc2lvbiAxLjBmb250ZWxsb0dlbmVyYXRlZCBieSBzdmcydHRmIGZyb20gRm9udGVsbG8gcHJvamVjdC5odHRwOi8vZm9udGVsbG8uY29tAEMAbwBwAHkAcgBpAGcAaAB0ACAAKABDACkAIAAyADAAMQA0ACAAYgB5ACAAbwByAGkAZwBpAG4AYQBsACAAYQB1AHQAaABvAHIAcwAgAEAAIABmAG8AbgB0AGUAbABsAG8ALgBjAG8AbQBmAG8AbgB0AGUAbABsAG8AUgBlAGcAdQBsAGEAcgBmAG8AbgB0AGUAbABsAG8AZgBvAG4AdABlAGwAbABvAFYAZQByAHMAaQBvAG4AIAAxAC4AMABmAG8AbgB0AGUAbABsAG8ARwBlAG4AZQByAGEAdABlAGQAIABiAHkAIABzAHYAZwAyAHQAdABmACAAZgByAG8AbQAgAEYAbwBuAHQAZQBsAGwAbwAgAHAAcgBvAGoAZQBjAHQALgBoAHQAdABwADoALwAvAGYAbwBuAHQAZQBsAGwAbwAuAGMAbwBtAAAAAAIAAAAAAAAACgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwAAAQIBAwljaGVja21hcmsGY2lyY2xlAAAAAAEAAf//AA8AAAAAAAAAAAAAAAAAAAAAADIAMgML/7EDC/+xsAAssCBgZi2wASwgZCCwwFCwBCZasARFW1ghIyEbilggsFBQWCGwQFkbILA4UFghsDhZWSCwCkVhZLAoUFghsApFILAwUFghsDBZGyCwwFBYIGYgiophILAKUFhgGyCwIFBYIbAKYBsgsDZQWCGwNmAbYFlZWRuwACtZWSOwAFBYZVlZLbACLCBFILAEJWFkILAFQ1BYsAUjQrAGI0IbISFZsAFgLbADLCMhIyEgZLEFYkIgsAYjQrIKAAIqISCwBkMgiiCKsAArsTAFJYpRWGBQG2FSWVgjWSEgsEBTWLAAKxshsEBZI7AAUFhlWS2wBCywB0MrsgACAENgQi2wBSywByNCIyCwACNCYbCAYrABYLAEKi2wBiwgIEUgsAJFY7ABRWJgRLABYC2wBywgIEUgsAArI7ECBCVgIEWKI2EgZCCwIFBYIbAAG7AwUFiwIBuwQFlZI7AAUFhlWbADJSNhRESwAWAtsAgssQUFRbABYUQtsAkssAFgICCwCUNKsABQWCCwCSNCWbAKQ0qwAFJYILAKI0JZLbAKLCC4BABiILgEAGOKI2GwC0NgIIpgILALI0IjLbALLEtUWLEHAURZJLANZSN4LbAMLEtRWEtTWLEHAURZGyFZJLATZSN4LbANLLEADENVWLEMDEOwAWFCsAorWbAAQ7ACJUKxCQIlQrEKAiVCsAEWIyCwAyVQWLEBAENgsAQlQoqKIIojYbAJKiEjsAFhIIojYbAJKiEbsQEAQ2CwAiVCsAIlYbAJKiFZsAlDR7AKQ0dgsIBiILACRWOwAUViYLEAABMjRLABQ7AAPrIBAQFDYEItsA4ssQAFRVRYALAMI0IgYLABYbUNDQEACwBCQopgsQ0FK7BtKxsiWS2wDyyxAA4rLbAQLLEBDistsBEssQIOKy2wEiyxAw4rLbATLLEEDistsBQssQUOKy2wFSyxBg4rLbAWLLEHDistsBcssQgOKy2wGCyxCQ4rLbAZLLAIK7EABUVUWACwDCNCIGCwAWG1DQ0BAAsAQkKKYLENBSuwbSsbIlktsBossQAZKy2wGyyxARkrLbAcLLECGSstsB0ssQMZKy2wHiyxBBkrLbAfLLEFGSstsCAssQYZKy2wISyxBxkrLbAiLLEIGSstsCMssQkZKy2wJCwgPLABYC2wJSwgYLANYCBDI7ABYEOwAiVhsAFgsCQqIS2wJiywJSuwJSotsCcsICBHICCwAkVjsAFFYmAjYTgjIIpVWCBHICCwAkVjsAFFYmAjYTgbIVktsCgssQAFRVRYALABFrAnKrABFTAbIlktsCkssAgrsQAFRVRYALABFrAnKrABFTAbIlktsCosIDWwAWAtsCssALADRWOwAUVisAArsAJFY7ABRWKwACuwABa0AAAAAABEPiM4sSoBFSotsCwsIDwgRyCwAkVjsAFFYmCwAENhOC2wLSwuFzwtsC4sIDwgRyCwAkVjsAFFYmCwAENhsAFDYzgtsC8ssQIAFiUgLiBHsAAjQrACJUmKikcjRyNhIFhiGyFZsAEjQrIuAQEVFCotsDAssAAWsAQlsAQlRyNHI2GwBkUrZYouIyAgPIo4LbAxLLAAFrAEJbAEJSAuRyNHI2EgsAQjQrAGRSsgsGBQWCCwQFFYswIgAyAbswImAxpZQkIjILAIQyCKI0cjRyNhI0ZgsARDsIBiYCCwACsgiophILACQ2BkI7ADQ2FkUFiwAkNhG7ADQ2BZsAMlsIBiYSMgILAEJiNGYTgbI7AIQ0awAiWwCENHI0cjYWAgsARDsIBiYCMgsAArI7AEQ2CwACuwBSVhsAUlsIBisAQmYSCwBCVgZCOwAyVgZFBYIRsjIVkjICCwBCYjRmE4WS2wMiywABYgICCwBSYgLkcjRyNhIzw4LbAzLLAAFiCwCCNCICAgRiNHsAArI2E4LbA0LLAAFrADJbACJUcjRyNhsABUWC4gPCMhG7ACJbACJUcjRyNhILAFJbAEJUcjRyNhsAYlsAUlSbACJWGwAUVjIyBYYhshWWOwAUViYCMuIyAgPIo4IyFZLbA1LLAAFiCwCEMgLkcjRyNhIGCwIGBmsIBiIyAgPIo4LbA2LCMgLkawAiVGUlggPFkusSYBFCstsDcsIyAuRrACJUZQWCA8WS6xJgEUKy2wOCwjIC5GsAIlRlJYIDxZIyAuRrACJUZQWCA8WS6xJgEUKy2wOSywMCsjIC5GsAIlRlJYIDxZLrEmARQrLbA6LLAxK4ogIDywBCNCijgjIC5GsAIlRlJYIDxZLrEmARQrsARDLrAmKy2wOyywABawBCWwBCYgLkcjRyNhsAZFKyMgPCAuIzixJgEUKy2wPCyxCAQlQrAAFrAEJbAEJSAuRyNHI2EgsAQjQrAGRSsgsGBQWCCwQFFYswIgAyAbswImAxpZQkIjIEewBEOwgGJgILAAKyCKimEgsAJDYGQjsANDYWRQWLACQ2EbsANDYFmwAyWwgGJhsAIlRmE4IyA8IzgbISAgRiNHsAArI2E4IVmxJgEUKy2wPSywMCsusSYBFCstsD4ssDErISMgIDywBCNCIzixJgEUK7AEQy6wJistsD8ssAAVIEewACNCsgABARUUEy6wLCotsEAssAAVIEewACNCsgABARUUEy6wLCotsEEssQABFBOwLSotsEIssC8qLbBDLLAAFkUjIC4gRoojYTixJgEUKy2wRCywCCNCsEMrLbBFLLIAADwrLbBGLLIAATwrLbBHLLIBADwrLbBILLIBATwrLbBJLLIAAD0rLbBKLLIAAT0rLbBLLLIBAD0rLbBMLLIBAT0rLbBNLLIAADkrLbBOLLIAATkrLbBPLLIBADkrLbBQLLIBATkrLbBRLLIAADsrLbBSLLIAATsrLbBTLLIBADsrLbBULLIBATsrLbBVLLIAAD4rLbBWLLIAAT4rLbBXLLIBAD4rLbBYLLIBAT4rLbBZLLIAADorLbBaLLIAATorLbBbLLIBADorLbBcLLIBATorLbBdLLAyKy6xJgEUKy2wXiywMiuwNistsF8ssDIrsDcrLbBgLLAAFrAyK7A4Ky2wYSywMysusSYBFCstsGIssDMrsDYrLbBjLLAzK7A3Ky2wZCywMyuwOCstsGUssDQrLrEmARQrLbBmLLA0K7A2Ky2wZyywNCuwNystsGgssDQrsDgrLbBpLLA1Ky6xJgEUKy2waiywNSuwNistsGsssDUrsDcrLbBsLLA1K7A4Ky2wbSwrsAhlsAMkUHiwARUwLQAAAEu4AMhSWLEBAY5ZuQgACABjILABI0SwAyNwsgQoCUVSRLIKAgcqsQYBRLEkAYhRWLBAiFixBgNEsSYBiFFYuAQAiFixBgFEWVlZWbgB/4WwBI2xBQBEAAA= ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "data:application/x-font-ttf;charset=utf-8;base64,AAEAAAAOAIAAAwBgT1MvMj3hSQEAAADsAAAAVmNtYXDQEhm3AAABRAAAAUpjdnQgBkn/lAAABuwAAAAcZnBnbYoKeDsAAAcIAAAJkWdhc3AAAAAQAAAG5AAAAAhnbHlm32cEdgAAApAAAAC2aGVhZAErPHsAAANIAAAANmhoZWEHUwNNAAADgAAAACRobXR4CykAAAAAA6QAAAAMbG9jYQA4AFsAAAOwAAAACG1heHAApgm8AAADuAAAACBuYW1lzJ0aHAAAA9gAAALNcG9zdK69QJgAAAaoAAAAO3ByZXCSoZr/AAAQnAAAAFYAAQO4AZAABQAIAnoCvAAAAIwCegK8AAAB4AAxAQIAAAIABQMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUGZFZABA6ADoAQNS/2oAWgMLAE8AAAABAAAAAAAAAAAAAwAAAAMAAAAcAAEAAAAAAEQAAwABAAAAHAAEACgAAAAGAAQAAQACAADoAf//AAAAAOgA//8AABgBAAEAAAAAAAAAAAEGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAADpAKYABUAHEAZDwEAAQFCAAIBAmoAAQABagAAAGEUFxQDEisBFAcBBiInASY0PwE2Mh8BATYyHwEWA6QP/iAQLBD+6g8PTBAsEKQBbhAsEEwPAhYWEP4gDw8BFhAsEEwQEKUBbxAQTBAAAAH//f+xA18DCwAMABJADwABAQpDAAAACwBEFRMCESsBFA4BIi4CPgEyHgEDWXLG6MhuBnq89Lp+AV51xHR0xOrEdHTEAAAAAAEAAAABAADDeRpdXw889QALA+gAAAAAzzWYjQAAAADPNWBN//3/sQOkAwsAAAAIAAIAAAAAAAAAAQAAA1L/agBaA+gAAP/3A6QAAQAAAAAAAAAAAAAAAAAAAAMD6AAAA+gAAANZAAAAAAAAADgAWwABAAAAAwAWAAEAAAAAAAIABgATAG4AAAAtCZEAAAAAAAAAEgDeAAEAAAAAAAAANQAAAAEAAAAAAAEACAA1AAEAAAAAAAIABwA9AAEAAAAAAAMACABEAAEAAAAAAAQACABMAAEAAAAAAAUACwBUAAEAAAAAAAYACABfAAEAAAAAAAoAKwBnAAEAAAAAAAsAEwCSAAMAAQQJAAAAagClAAMAAQQJAAEAEAEPAAMAAQQJAAIADgEfAAMAAQQJAAMAEAEtAAMAAQQJAAQAEAE9AAMAAQQJAAUAFgFNAAMAAQQJAAYAEAFjAAMAAQQJAAoAVgFzAAMAAQQJAAsAJgHJQ29weXJpZ2h0IChDKSAyMDE0IGJ5IG9yaWdpbmFsIGF1dGhvcnMgQCBmb250ZWxsby5jb21mb250ZWxsb1JlZ3VsYXJmb250ZWxsb2ZvbnRlbGxvVmVyc2lvbiAxLjBmb250ZWxsb0dlbmVyYXRlZCBieSBzdmcydHRmIGZyb20gRm9udGVsbG8gcHJvamVjdC5odHRwOi8vZm9udGVsbG8uY29tAEMAbwBwAHkAcgBpAGcAaAB0ACAAKABDACkAIAAyADAAMQA0ACAAYgB5ACAAbwByAGkAZwBpAG4AYQBsACAAYQB1AHQAaABvAHIAcwAgAEAAIABmAG8AbgB0AGUAbABsAG8ALgBjAG8AbQBmAG8AbgB0AGUAbABsAG8AUgBlAGcAdQBsAGEAcgBmAG8AbgB0AGUAbABsAG8AZgBvAG4AdABlAGwAbABvAFYAZQByAHMAaQBvAG4AIAAxAC4AMABmAG8AbgB0AGUAbABsAG8ARwBlAG4AZQByAGEAdABlAGQAIABiAHkAIABzAHYAZwAyAHQAdABmACAAZgByAG8AbQAgAEYAbwBuAHQAZQBsAGwAbwAgAHAAcgBvAGoAZQBjAHQALgBoAHQAdABwADoALwAvAGYAbwBuAHQAZQBsAGwAbwAuAGMAbwBtAAAAAAIAAAAAAAAACgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwAAAQIBAwljaGVja21hcmsGY2lyY2xlAAAAAAEAAf//AA8AAAAAAAAAAAAAAAAAAAAAADIAMgML/7EDC/+xsAAssCBgZi2wASwgZCCwwFCwBCZasARFW1ghIyEbilggsFBQWCGwQFkbILA4UFghsDhZWSCwCkVhZLAoUFghsApFILAwUFghsDBZGyCwwFBYIGYgiophILAKUFhgGyCwIFBYIbAKYBsgsDZQWCGwNmAbYFlZWRuwACtZWSOwAFBYZVlZLbACLCBFILAEJWFkILAFQ1BYsAUjQrAGI0IbISFZsAFgLbADLCMhIyEgZLEFYkIgsAYjQrIKAAIqISCwBkMgiiCKsAArsTAFJYpRWGBQG2FSWVgjWSEgsEBTWLAAKxshsEBZI7AAUFhlWS2wBCywB0MrsgACAENgQi2wBSywByNCIyCwACNCYbCAYrABYLAEKi2wBiwgIEUgsAJFY7ABRWJgRLABYC2wBywgIEUgsAArI7ECBCVgIEWKI2EgZCCwIFBYIbAAG7AwUFiwIBuwQFlZI7AAUFhlWbADJSNhRESwAWAtsAgssQUFRbABYUQtsAkssAFgICCwCUNKsABQWCCwCSNCWbAKQ0qwAFJYILAKI0JZLbAKLCC4BABiILgEAGOKI2GwC0NgIIpgILALI0IjLbALLEtUWLEHAURZJLANZSN4LbAMLEtRWEtTWLEHAURZGyFZJLATZSN4LbANLLEADENVWLEMDEOwAWFCsAorWbAAQ7ACJUKxCQIlQrEKAiVCsAEWIyCwAyVQWLEBAENgsAQlQoqKIIojYbAJKiEjsAFhIIojYbAJKiEbsQEAQ2CwAiVCsAIlYbAJKiFZsAlDR7AKQ0dgsIBiILACRWOwAUViYLEAABMjRLABQ7AAPrIBAQFDYEItsA4ssQAFRVRYALAMI0IgYLABYbUNDQEACwBCQopgsQ0FK7BtKxsiWS2wDyyxAA4rLbAQLLEBDistsBEssQIOKy2wEiyxAw4rLbATLLEEDistsBQssQUOKy2wFSyxBg4rLbAWLLEHDistsBcssQgOKy2wGCyxCQ4rLbAZLLAIK7EABUVUWACwDCNCIGCwAWG1DQ0BAAsAQkKKYLENBSuwbSsbIlktsBossQAZKy2wGyyxARkrLbAcLLECGSstsB0ssQMZKy2wHiyxBBkrLbAfLLEFGSstsCAssQYZKy2wISyxBxkrLbAiLLEIGSstsCMssQkZKy2wJCwgPLABYC2wJSwgYLANYCBDI7ABYEOwAiVhsAFgsCQqIS2wJiywJSuwJSotsCcsICBHICCwAkVjsAFFYmAjYTgjIIpVWCBHICCwAkVjsAFFYmAjYTgbIVktsCgssQAFRVRYALABFrAnKrABFTAbIlktsCkssAgrsQAFRVRYALABFrAnKrABFTAbIlktsCosIDWwAWAtsCssALADRWOwAUVisAArsAJFY7ABRWKwACuwABa0AAAAAABEPiM4sSoBFSotsCwsIDwgRyCwAkVjsAFFYmCwAENhOC2wLSwuFzwtsC4sIDwgRyCwAkVjsAFFYmCwAENhsAFDYzgtsC8ssQIAFiUgLiBHsAAjQrACJUmKikcjRyNhIFhiGyFZsAEjQrIuAQEVFCotsDAssAAWsAQlsAQlRyNHI2GwBkUrZYouIyAgPIo4LbAxLLAAFrAEJbAEJSAuRyNHI2EgsAQjQrAGRSsgsGBQWCCwQFFYswIgAyAbswImAxpZQkIjILAIQyCKI0cjRyNhI0ZgsARDsIBiYCCwACsgiophILACQ2BkI7ADQ2FkUFiwAkNhG7ADQ2BZsAMlsIBiYSMgILAEJiNGYTgbI7AIQ0awAiWwCENHI0cjYWAgsARDsIBiYCMgsAArI7AEQ2CwACuwBSVhsAUlsIBisAQmYSCwBCVgZCOwAyVgZFBYIRsjIVkjICCwBCYjRmE4WS2wMiywABYgICCwBSYgLkcjRyNhIzw4LbAzLLAAFiCwCCNCICAgRiNHsAArI2E4LbA0LLAAFrADJbACJUcjRyNhsABUWC4gPCMhG7ACJbACJUcjRyNhILAFJbAEJUcjRyNhsAYlsAUlSbACJWGwAUVjIyBYYhshWWOwAUViYCMuIyAgPIo4IyFZLbA1LLAAFiCwCEMgLkcjRyNhIGCwIGBmsIBiIyAgPIo4LbA2LCMgLkawAiVGUlggPFkusSYBFCstsDcsIyAuRrACJUZQWCA8WS6xJgEUKy2wOCwjIC5GsAIlRlJYIDxZIyAuRrACJUZQWCA8WS6xJgEUKy2wOSywMCsjIC5GsAIlRlJYIDxZLrEmARQrLbA6LLAxK4ogIDywBCNCijgjIC5GsAIlRlJYIDxZLrEmARQrsARDLrAmKy2wOyywABawBCWwBCYgLkcjRyNhsAZFKyMgPCAuIzixJgEUKy2wPCyxCAQlQrAAFrAEJbAEJSAuRyNHI2EgsAQjQrAGRSsgsGBQWCCwQFFYswIgAyAbswImAxpZQkIjIEewBEOwgGJgILAAKyCKimEgsAJDYGQjsANDYWRQWLACQ2EbsANDYFmwAyWwgGJhsAIlRmE4IyA8IzgbISAgRiNHsAArI2E4IVmxJgEUKy2wPSywMCsusSYBFCstsD4ssDErISMgIDywBCNCIzixJgEUK7AEQy6wJistsD8ssAAVIEewACNCsgABARUUEy6wLCotsEAssAAVIEewACNCsgABARUUEy6wLCotsEEssQABFBOwLSotsEIssC8qLbBDLLAAFkUjIC4gRoojYTixJgEUKy2wRCywCCNCsEMrLbBFLLIAADwrLbBGLLIAATwrLbBHLLIBADwrLbBILLIBATwrLbBJLLIAAD0rLbBKLLIAAT0rLbBLLLIBAD0rLbBMLLIBAT0rLbBNLLIAADkrLbBOLLIAATkrLbBPLLIBADkrLbBQLLIBATkrLbBRLLIAADsrLbBSLLIAATsrLbBTLLIBADsrLbBULLIBATsrLbBVLLIAAD4rLbBWLLIAAT4rLbBXLLIBAD4rLbBYLLIBAT4rLbBZLLIAADorLbBaLLIAATorLbBbLLIBADorLbBcLLIBATorLbBdLLAyKy6xJgEUKy2wXiywMiuwNistsF8ssDIrsDcrLbBgLLAAFrAyK7A4Ky2wYSywMysusSYBFCstsGIssDMrsDYrLbBjLLAzK7A3Ky2wZCywMyuwOCstsGUssDQrLrEmARQrLbBmLLA0K7A2Ky2wZyywNCuwNystsGgssDQrsDgrLbBpLLA1Ky6xJgEUKy2waiywNSuwNistsGsssDUrsDcrLbBsLLA1K7A4Ky2wbSwrsAhlsAMkUHiwARUwLQAAAEu4AMhSWLEBAY5ZuQgACABjILABI0SwAyNwsgQoCUVSRLIKAgcqsQYBRLEkAYhRWLBAiFixBgNEsSYBiFFYuAQAiFixBgFEWVlZWbgB/4WwBI2xBQBEAAA=";

/***/ }),

/***/ "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABaAAAAACCAYAAACuTHuKAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyFpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDE0IDc5LjE1MTQ4MSwgMjAxMy8wMy8xMy0xMjowOToxNSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo1OThBRDY4OUNDMTYxMUU0OUE3NUVGOEJDMzMzMjE2NyIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo1OThBRDY4QUNDMTYxMUU0OUE3NUVGOEJDMzMzMjE2NyI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjU5OEFENjg3Q0MxNjExRTQ5QTc1RUY4QkMzMzMyMTY3IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjU5OEFENjg4Q0MxNjExRTQ5QTc1RUY4QkMzMzMyMTY3Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+VU513gAAADVJREFUeNrs0DENACAQBDBIWLGBJQby/mUcJn5sJXQmOQMAAAAAAJqt+2prAAAAAACg2xdgANk6BEVuJgyMAAAAAElFTkSuQmCC":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABaAAAAACCAYAAACuTHuKAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyFpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDE0IDc5LjE1MTQ4MSwgMjAxMy8wMy8xMy0xMjowOToxNSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo1OThBRDY4OUNDMTYxMUU0OUE3NUVGOEJDMzMzMjE2NyIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo1OThBRDY4QUNDMTYxMUU0OUE3NUVGOEJDMzMzMjE2NyI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjU5OEFENjg3Q0MxNjExRTQ5QTc1RUY4QkMzMzMyMTY3IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjU5OEFENjg4Q0MxNjExRTQ5QTc1RUY4QkMzMzMyMTY3Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+VU513gAAADVJREFUeNrs0DENACAQBDBIWLGBJQby/mUcJn5sJXQmOQMAAAAAAJqt+2prAAAAAACg2xdgANk6BEVuJgyMAAAAAElFTkSuQmCC ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module) => {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABaAAAAACCAYAAACuTHuKAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyFpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDE0IDc5LjE1MTQ4MSwgMjAxMy8wMy8xMy0xMjowOToxNSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo1OThBRDY4OUNDMTYxMUU0OUE3NUVGOEJDMzMzMjE2NyIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo1OThBRDY4QUNDMTYxMUU0OUE3NUVGOEJDMzMzMjE2NyI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjU5OEFENjg3Q0MxNjExRTQ5QTc1RUY4QkMzMzMyMTY3IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjU5OEFENjg4Q0MxNjExRTQ5QTc1RUY4QkMzMzMyMTY3Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+VU513gAAADVJREFUeNrs0DENACAQBDBIWLGBJQby/mUcJn5sJXQmOQMAAAAAAJqt+2prAAAAAACg2xdgANk6BEVuJgyMAAAAAElFTkSuQmCC";

/***/ }),

/***/ "./style/icons/clone_icon.svg":
/*!************************************!*\
  !*** ./style/icons/clone_icon.svg ***!
  \************************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_1227_2582)\">\n<path d=\"M7.5 12C7.08333 12 6.72917 11.8542 6.4375 11.5625C6.14583 11.2708 6 10.9167 6 10.5V4.5C6 4.08333 6.14583 3.72917 6.4375 3.4375C6.72917 3.14583 7.08333 3 7.5 3H13.5C13.9167 3 14.2708 3.14583 14.5625 3.4375C14.8542 3.72917 15 4.08333 15 4.5V10.5C15 10.9167 14.8542 11.2708 14.5625 11.5625C14.2708 11.8542 13.9167 12 13.5 12H7.5ZM7.5 4.5V10.5H13.5V4.5H7.5ZM4.5 15C4.08333 15 3.72917 14.8542 3.4375 14.5625C3.14583 14.2708 3 13.9167 3 13.5V7H4.5V13.5H11V15H4.5ZM7.5 4.5V10.5V4.5Z\" fill=\"#444746\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_1227_2582\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/clone_job_icon.svg":
/*!****************************************!*\
  !*** ./style/icons/clone_job_icon.svg ***!
  \****************************************/
/***/ ((module) => {

module.exports = "<svg width=\"12\" height=\"14\" viewBox=\"0 0 12 14\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M0 1C0 0.447715 0.447714 0 0.999999 0H8.93233V2H1.98496V10H0V1ZM4 3C3.44772 3 3 3.44772 3 4V13C3 13.5523 3.44772 14 4 14H11C11.5523 14 12 13.5523 12 13V4C12 3.44772 11.5523 3 11 3H4ZM5 12V5H10V12H5Z\" fill=\"#3367D6\"/>\n</svg>\n";

/***/ }),

/***/ "./style/icons/cluster_error_icon.svg":
/*!********************************************!*\
  !*** ./style/icons/cluster_error_icon.svg ***!
  \********************************************/
/***/ ((module) => {

module.exports = "<svg width=\"15\" height=\"15\" viewBox=\"0 0 15 15\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M7.49219 0.5C11.3582 0.5 14.4922 3.63401 14.4922 7.5C14.4922 11.366 11.3582 14.5 7.49219 14.5C3.62619 14.5 0.492188 11.366 0.492188 7.5C0.492188 3.63401 3.62619 0.5 7.49219 0.5ZM8.49219 8.5V3.5H6.49219V8.5H8.49219ZM8.49219 9.5V11.5H6.49219V9.5H8.49219Z\" fill=\"#D50000\"/>\n</svg>\n";

/***/ }),

/***/ "./style/icons/cluster_icon.svg":
/*!**************************************!*\
  !*** ./style/icons/cluster_icon.svg ***!
  \**************************************/
/***/ ((module) => {

module.exports = "<svg width=\"52\" height=\"52\" viewBox=\"0 0 52 52\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<rect width=\"52\" height=\"52\" fill=\"white\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M30.2222 15.4444C30.2222 17.7763 28.3318 19.6666 25.9999 19.6666C23.6681 19.6666 21.7777 17.7763 21.7777 15.4444C21.7777 13.1125 23.6681 11.2222 25.9999 11.2222C28.3318 11.2222 30.2222 13.1125 30.2222 15.4444ZM15.4444 30.2222C17.7763 30.2222 19.6666 28.3318 19.6666 25.9999C19.6666 23.6681 17.7763 21.7777 15.4444 21.7777C13.1125 21.7777 11.2222 23.6681 11.2222 25.9999C11.2222 28.3318 13.1125 30.2222 15.4444 30.2222ZM36.5555 30.2222C38.8874 30.2222 40.7777 28.3318 40.7777 25.9999C40.7777 23.6681 38.8874 21.7777 36.5555 21.7777C34.2236 21.7777 32.3333 23.6681 32.3333 25.9999C32.3333 28.3318 34.2236 30.2222 36.5555 30.2222ZM25.9999 40.7777C28.3318 40.7777 30.2222 38.8874 30.2222 36.5555C30.2222 34.2236 28.3318 32.3333 25.9999 32.3333C23.6681 32.3333 21.7777 34.2236 21.7777 36.5555C21.7777 38.8874 23.6681 40.7777 25.9999 40.7777ZM29.1666 25.9999C29.1666 27.7488 27.7488 29.1666 25.9999 29.1666C24.251 29.1666 22.8333 27.7488 22.8333 25.9999C22.8333 24.251 24.251 22.8333 25.9999 22.8333C27.7488 22.8333 29.1666 24.251 29.1666 25.9999ZM17.5555 19.6666C18.7214 19.6666 19.6666 18.7214 19.6666 17.5555C19.6666 16.3896 18.7214 15.4444 17.5555 15.4444C16.3896 15.4444 15.4444 16.3896 15.4444 17.5555C15.4444 18.7214 16.3896 19.6666 17.5555 19.6666ZM19.6666 34.4444C19.6666 35.6103 18.7214 36.5555 17.5555 36.5555C16.3896 36.5555 15.4444 35.6103 15.4444 34.4444C15.4444 33.2785 16.3896 32.3333 17.5555 32.3333C18.7214 32.3333 19.6666 33.2785 19.6666 34.4444ZM34.4444 19.6666C35.6103 19.6666 36.5555 18.7214 36.5555 17.5555C36.5555 16.3896 35.6103 15.4444 34.4444 15.4444C33.2785 15.4444 32.3333 16.3896 32.3333 17.5555C32.3333 18.7214 33.2785 19.6666 34.4444 19.6666ZM36.5555 34.4444C36.5555 35.6103 35.6103 36.5555 34.4444 36.5555C33.2785 36.5555 32.3333 35.6103 32.3333 34.4444C32.3333 33.2785 33.2785 32.3333 34.4444 32.3333C35.6103 32.3333 36.5555 33.2785 36.5555 34.4444Z\" fill=\"#3367D6\"/>\n</svg>\n";

/***/ }),

/***/ "./style/icons/cluster_running_icon.svg":
/*!**********************************************!*\
  !*** ./style/icons/cluster_running_icon.svg ***!
  \**********************************************/
/***/ ((module) => {

module.exports = "<svg width=\"15\" height=\"15\" viewBox=\"0 0 15 15\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M14.4922 7.5C14.4922 6.33973 14.2099 5.2454 13.7103 4.28193L12.1948 5.79737C12.3873 6.3288 12.4922 6.90215 12.4922 7.5C12.4922 10.2614 10.2536 12.5 7.49219 12.5C4.73076 12.5 2.49219 10.2614 2.49219 7.5C2.49219 4.73857 4.73076 2.5 7.49219 2.5V7.5L11.0277 3.96446L11.4922 3.5L12.4419 2.55025C11.1752 1.2835 9.42519 0.5 7.49219 0.5C3.62619 0.5 0.492188 3.634 0.492188 7.5C0.492188 11.366 3.62619 14.5 7.49219 14.5C11.3582 14.5 14.4922 11.366 14.4922 7.5Z\" fill=\"#188038\"/>\n</svg>\n";

/***/ }),

/***/ "./style/icons/columns_icon.svg":
/*!**************************************!*\
  !*** ./style/icons/columns_icon.svg ***!
  \**************************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"> \n<g clip-path=\"url(#clip0_3065_14754)\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M6.375 4.125H2.625V13.875H6.375V4.125ZM7.125 4.125H10.875V13.875H7.125V4.125ZM11.625 4.125H15.375V13.875H11.625V4.125Z\" fill=\"black\" fill-opacity=\"0.66\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_3065_14754\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/create_cluster_icon.svg":
/*!*********************************************!*\
  !*** ./style/icons/create_cluster_icon.svg ***!
  \*********************************************/
/***/ ((module) => {

module.exports = "<svg width=\"14\" height=\"14\" viewBox=\"0 0 14 14\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M12.25 12.25H1.75V1.75H7V0.25H1.75C0.9175 0.25 0.25 0.925 0.25 1.75V12.25C0.25 13.075 0.9175 13.75 1.75 13.75H12.25C13.075 13.75 13.75 13.075 13.75 12.25V7H12.25V12.25ZM8.5 0.25V1.75H11.1925L3.82 9.1225L4.8775 10.18L12.25 2.8075V5.5H13.75V0.25H8.5Z\" fill=\"#3367D6\"/>\n</svg>\n";

/***/ }),

/***/ "./style/icons/database_icon.svg":
/*!***************************************!*\
  !*** ./style/icons/database_icon.svg ***!
  \***************************************/
/***/ ((module) => {

module.exports = "<svg width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_3065_14721)\">\n<path d=\"M12 21C9.48333 21 7.35 20.6167 5.6 19.85C3.86667 19.0667 3 18.1167 3 17V7C3 5.9 3.875 4.95833 5.625 4.175C7.39167 3.39167 9.51667 3 12 3C14.4833 3 16.6 3.39167 18.35 4.175C20.1167 4.95833 21 5.9 21 7V17C21 18.1167 20.125 19.0667 18.375 19.85C16.6417 20.6167 14.5167 21 12 21ZM12 9.025C13.4833 9.025 14.975 8.81667 16.475 8.4C17.975 7.96667 18.8167 7.50833 19 7.025C18.8167 6.54167 17.975 6.08333 16.475 5.65C14.9917 5.21667 13.5 5 12 5C10.4833 5 8.99167 5.21667 7.525 5.65C6.075 6.06667 5.23333 6.525 5 7.025C5.23333 7.525 6.075 7.98333 7.525 8.4C8.99167 8.81667 10.4833 9.025 12 9.025ZM12 14C12.7 14 13.375 13.9667 14.025 13.9C14.675 13.8333 15.2917 13.7417 15.875 13.625C16.475 13.4917 17.0333 13.3333 17.55 13.15C18.0833 12.9667 18.5667 12.7583 19 12.525V9.525C18.5667 9.75833 18.0833 9.96667 17.55 10.15C17.0333 10.3333 16.475 10.4917 15.875 10.625C15.2917 10.7417 14.675 10.8333 14.025 10.9C13.375 10.9667 12.7 11 12 11C11.3 11 10.6167 10.9667 9.95 10.9C9.28333 10.8333 8.65 10.7417 8.05 10.625C7.46667 10.4917 6.91667 10.3333 6.4 10.15C5.88333 9.96667 5.41667 9.75833 5 9.525V12.525C5.41667 12.7583 5.88333 12.9667 6.4 13.15C6.91667 13.3333 7.46667 13.4917 8.05 13.625C8.65 13.7417 9.28333 13.8333 9.95 13.9C10.6167 13.9667 11.3 14 12 14ZM12 19C12.7667 19 13.5417 18.9417 14.325 18.825C15.125 18.7083 15.8583 18.5583 16.525 18.375C17.1917 18.175 17.75 17.9583 18.2 17.725C18.65 17.475 18.9167 17.225 19 16.975V14.525C18.5667 14.7583 18.0833 14.9667 17.55 15.15C17.0333 15.3333 16.475 15.4917 15.875 15.625C15.2917 15.7417 14.675 15.8333 14.025 15.9C13.375 15.9667 12.7 16 12 16C11.3 16 10.6167 15.9667 9.95 15.9C9.28333 15.8333 8.65 15.7417 8.05 15.625C7.46667 15.4917 6.91667 15.3333 6.4 15.15C5.88333 14.9667 5.41667 14.7583 5 14.525V17C5.08333 17.25 5.34167 17.4917 5.775 17.725C6.225 17.9583 6.78333 18.175 7.45 18.375C8.11667 18.5583 8.85 18.7083 9.65 18.825C10.45 18.9417 11.2333 19 12 19Z\" fill=\"#444746\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_3065_14721\">\n<rect width=\"24\" height=\"24\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/database_widget_icon.svg":
/*!**********************************************!*\
  !*** ./style/icons/database_widget_icon.svg ***!
  \**********************************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_2908_23113)\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n<path d=\"M9 15.3C7.2375 15.3 5.74375 15.0375 4.51875 14.5125C3.30625 13.9875 2.7 13.35 2.7 12.6V5.4C2.7 4.65 3.3125 4.0125 4.5375 3.4875C5.7625 2.9625 7.25 2.7 9 2.7C10.7375 2.7 12.2188 2.9625 13.4438 3.4875C14.6813 4.0125 15.3 4.65 15.3 5.4V12.6C15.3 13.35 14.6875 13.9875 13.4625 14.5125C12.2375 15.0375 10.75 15.3 9 15.3ZM9 6.75C10.075 6.75 11.1125 6.61875 12.1125 6.35625C13.1125 6.08125 13.725 5.7625 13.95 5.4C13.725 5.05 13.1063 4.7375 12.0938 4.4625C11.0938 4.1875 10.0625 4.05 9 4.05C7.925 4.05 6.88125 4.1875 5.86875 4.4625C4.86875 4.7375 4.2625 5.05 4.05 5.4C4.2625 5.7625 4.8625 6.08125 5.85 6.35625C6.85 6.61875 7.9 6.75 9 6.75ZM9 10.35C9.525 10.35 10.025 10.325 10.5 10.275C10.975 10.2125 11.4188 10.1312 11.8313 10.0312C12.2563 9.93125 12.6438 9.80625 12.9938 9.65625C13.3563 9.49375 13.675 9.3125 13.95 9.1125V7.06875C13.65 7.23125 13.3125 7.38125 12.9375 7.51875C12.575 7.64375 12.1813 7.75 11.7563 7.8375C11.3313 7.925 10.8875 7.99375 10.425 8.04375C9.9625 8.08125 9.4875 8.1 9 8.1C8.5 8.1 8.0125 8.08125 7.5375 8.04375C7.075 7.99375 6.63125 7.925 6.20625 7.8375C5.79375 7.75 5.4 7.64375 5.025 7.51875C4.6625 7.38125 4.3375 7.23125 4.05 7.06875V9.1125C4.325 9.3125 4.6375 9.49375 4.9875 9.65625C5.3375 9.80625 5.71875 9.93125 6.13125 10.0312C6.55625 10.1312 7.00625 10.2125 7.48125 10.275C7.96875 10.325 8.475 10.35 9 10.35ZM9 13.95C9.55 13.95 10.1 13.9125 10.65 13.8375C11.2125 13.75 11.725 13.6437 12.1875 13.5187C12.6625 13.3812 13.0563 13.2312 13.3688 13.0687C13.6938 12.9062 13.8875 12.7375 13.95 12.5625V10.6687C13.65 10.8312 13.3125 10.9812 12.9375 11.1187C12.575 11.2437 12.1813 11.35 11.7563 11.4375C11.3313 11.525 10.8875 11.5937 10.425 11.6437C9.9625 11.6812 9.4875 11.7 9 11.7C8.5 11.7 8.0125 11.6812 7.5375 11.6437C7.075 11.5937 6.63125 11.525 6.20625 11.4375C5.79375 11.35 5.4 11.2437 5.025 11.1187C4.6625 10.9812 4.3375 10.8312 4.05 10.6687V12.6C4.1125 12.7625 4.3 12.925 4.6125 13.0875C4.9375 13.25 5.33125 13.3937 5.79375 13.5187C6.26875 13.6437 6.7875 13.75 7.35 13.8375C7.9125 13.9125 8.4625 13.95 9 13.95Z\" fill=\"#3B78E7\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_2908_23113\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/datasets_icon.svg":
/*!***************************************!*\
  !*** ./style/icons/datasets_icon.svg ***!
  \***************************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_2908_23634)\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M16 2H2V16H16V2ZM14 4H4V14H14V4ZM6 10H8V12H6V10ZM8 6H6V8H8V6ZM10 10H12V12H10V10ZM12 6H10V8H12V6Z\" fill=\"#3B78E7\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_2908_23634\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/delete_cluster_icon.svg":
/*!*********************************************!*\
  !*** ./style/icons/delete_cluster_icon.svg ***!
  \*********************************************/
/***/ ((module) => {

module.exports = "<svg width=\"12\" height=\"14\" viewBox=\"0 0 12 14\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M8.23244 1H12V3H0V1H3.76756C4.11337 0.402199 4.75972 0 5.5 0H6.5C7.24028 0 7.88663 0.402199 8.23244 1ZM1 4H11V12C11 13.1046 10.1046 14 9 14H3C1.89543 14 1 13.1046 1 12V4Z\" fill=\"#3367D6\"/>\n</svg>\n";

/***/ }),

/***/ "./style/icons/delete_icon.svg":
/*!*************************************!*\
  !*** ./style/icons/delete_icon.svg ***!
  \*************************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_1227_2584)\">\n<path d=\"M4.78333 16.975C4.30972 16.975 3.89722 16.8069 3.54583 16.4708C3.20972 16.1194 3.04167 15.7069 3.04167 15.2333V3.775H2.03333V2.03333H6.525V1.025H11.475V2.03333H15.9667V3.775H14.9583V15.2333C14.9583 15.7069 14.7826 16.1194 14.4313 16.4708C14.0951 16.8069 13.6903 16.975 13.2167 16.975H4.78333ZM13.2167 3.775H4.78333V15.2333H13.2167V3.775ZM6.525 13.4917H8.26667V5.51667H6.525V13.4917ZM9.73333 13.4917H11.475V5.51667H9.73333V13.4917ZM4.78333 3.775V15.2333V3.775Z\" fill=\"#444746\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_1227_2584\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/down_arrow_icon.svg":
/*!*****************************************!*\
  !*** ./style/icons/down_arrow_icon.svg ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_3712_17225)\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M13.5 6.75H4.5L9 11.25L13.5 6.75Z\" fill=\"#575757\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_3712_17225\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/dpms_icon.svg":
/*!***********************************!*\
  !*** ./style/icons/dpms_icon.svg ***!
  \***********************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_2908_23656)\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M16 2H2V16H16V2ZM14 4H4V14H14V4ZM6 10H8V12H6V10ZM8 6H6V8H8V6ZM10 10H12V12H10V10ZM12 6H10V8H12V6Z\" fill=\"black\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_2908_23656\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/edit_icon.svg":
/*!***********************************!*\
  !*** ./style/icons/edit_icon.svg ***!
  \***********************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_3526_17578)\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M15.7756 4.02011C16.0748 4.32014 16.0748 4.80351 15.7756 5.10266L14.3711 6.50715L11.4928 3.62886L12.8973 2.22436C13.1965 1.92521 13.6799 1.92521 13.9799 2.22436L15.7756 4.02011ZM2 16V13.1208L10.4901 4.63157L13.3684 7.50986L4.87917 16H2Z\" fill=\"#3367D6\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_3526_17578\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/edit_icon_disable.svg":
/*!*******************************************!*\
  !*** ./style/icons/edit_icon_disable.svg ***!
  \*******************************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_3526_17578)\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M15.7756 4.02011C16.0748 4.32014 16.0748 4.80351 15.7756 5.10266L14.3711 6.50715L11.4928 3.62886L12.8973 2.22436C13.1965 1.92521 13.6799 1.92521 13.9799 2.22436L15.7756 4.02011ZM2 16V13.1208L10.4901 4.63157L13.3684 7.50986L4.87917 16H2Z\" fill=\"black\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_3526_17578\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>";

/***/ }),

/***/ "./style/icons/error_icon.svg":
/*!************************************!*\
  !*** ./style/icons/error_icon.svg ***!
  \************************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_2416_4781)\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M9 1.5C4.86 1.5 1.5 4.86 1.5 9C1.5 13.14 4.86 16.5 9 16.5C13.14 16.5 16.5 13.14 16.5 9C16.5 4.86 13.14 1.5 9 1.5ZM9.75 12.75H8.25V11.25H9.75V12.75ZM9.75 9.75H8.25V5.25H9.75V9.75Z\" fill=\"#D50000\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_2416_4781\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/filter_icon.svg":
/*!*************************************!*\
  !*** ./style/icons/filter_icon.svg ***!
  \*************************************/
/***/ ((module) => {

module.exports = "<svg width=\"14\" height=\"10\" viewBox=\"0 0 14 10\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M0 0H14V2H0V0ZM2 4H12V6H2V4ZM10 8H4V10H10V8Z\" fill=\"black\"/>\n</svg>\n";

/***/ }),

/***/ "./style/icons/left_arrow_icon.svg":
/*!*****************************************!*\
  !*** ./style/icons/left_arrow_icon.svg ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "<svg width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M20 11H7.83L13.42 5.41L12 4L4 12L12 20L13.41 18.59L7.83 13H20V11Z\" fill=\"#3367D6\"/>\n</svg>\n";

/***/ }),

/***/ "./style/icons/plus_icon.svg":
/*!***********************************!*\
  !*** ./style/icons/plus_icon.svg ***!
  \***********************************/
/***/ ((module) => {

module.exports = "<svg width=\"12\" height=\"12\" viewBox=\"0 0 12 12\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M7 0H5V5H0V7H5V12H7V7H12V5H7V0Z\" fill=\"#3367D6\"/>\n</svg>\n";

/***/ }),

/***/ "./style/icons/plus_icon_disable.svg":
/*!*******************************************!*\
  !*** ./style/icons/plus_icon_disable.svg ***!
  \*******************************************/
/***/ ((module) => {

module.exports = "<svg width=\"12\" height=\"12\" viewBox=\"0 0 12 12\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M7 0H5V5H0V7H5V12H7V7H12V5H7V0Z\" fill=\"#8A8A8A\"/>\n</svg>";

/***/ }),

/***/ "./style/icons/pyspark_logo.svg":
/*!**************************************!*\
  !*** ./style/icons/pyspark_logo.svg ***!
  \**************************************/
/***/ ((module) => {

module.exports = "<svg width=\"52\" height=\"52\" viewBox=\"0 0 52 52\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<rect width=\"52\" height=\"52\" fill=\"white\"/>\n<path d=\"M1.95545 27.1482H2.59885C3.20021 27.1482 3.65017 27.0302 3.94874 26.7943C4.24732 26.5541 4.3966 26.2065 4.3966 25.7514C4.3966 25.2921 4.27045 24.9529 4.01813 24.7338C3.77002 24.5147 3.37893 24.4052 2.84486 24.4052H1.95545V27.1482ZM6.37098 25.6819C6.37098 26.6763 6.05979 27.4368 5.43741 27.9635C4.81923 28.4902 3.93823 28.7536 2.7944 28.7536H1.95545V32.0402H0V22.7998H2.94579C4.06439 22.7998 4.91385 23.0421 5.49418 23.5266C6.07871 24.007 6.37098 24.7254 6.37098 25.6819Z\" fill=\"#E25A1C\"/>\n<path d=\"M6.9513 24.974H9.05814L10.3891 28.9495C10.5026 29.295 10.5804 29.7038 10.6225 30.1757H10.6603C10.7066 29.7417 10.797 29.333 10.9316 28.9495L12.2373 24.974H14.3L11.3164 32.944C11.043 33.6814 10.6519 34.2334 10.1431 34.5999C9.63846 34.9665 9.04763 35.1498 8.37058 35.1498C8.03836 35.1498 7.71245 35.114 7.39285 35.0424V33.5128C7.62414 33.5676 7.87646 33.595 8.1498 33.595C8.49043 33.595 8.7869 33.4897 9.03922 33.279C9.29574 33.0725 9.49549 32.7586 9.63846 32.3372L9.75201 31.9896L6.9513 24.974Z\" fill=\"#E25A1C\"/>\n<g clip-path=\"url(#clip0_3526_17591)\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M48.5824 24.9978C48.5487 24.9273 48.5336 24.8918 48.5154 24.858C48.028 23.9502 47.5419 23.0424 47.0495 22.1346C47.0002 22.0436 47.0064 21.9899 47.074 21.9114C47.8495 21.0245 48.615 20.1326 49.3918 19.2494C49.4193 19.2182 49.4437 19.1852 49.454 19.1297C49.2284 19.1872 49.0029 19.2441 48.7761 19.3026C47.8402 19.5455 46.8968 19.7872 45.9696 20.0338C45.8826 20.0567 45.8431 20.0318 45.7993 19.9609C45.268 19.0911 44.733 18.2189 44.1955 17.3602C44.1681 17.3152 44.1382 17.2715 44.0795 17.2339C44.0364 17.4657 43.9928 17.6964 43.9505 17.9282C43.8014 18.7464 43.6523 19.5598 43.5044 20.3817C43.4883 20.4699 43.4662 20.5583 43.4585 20.6466C43.4511 20.731 43.4066 20.7622 43.3282 20.7865C42.2244 21.1263 41.1231 21.4685 40.0205 21.8108C39.9721 21.8256 39.9247 21.8453 39.8727 21.8913C40.7748 22.2421 41.6768 22.593 42.5915 22.9499C42.5581 22.9758 42.5361 22.9959 42.5116 23.0113C41.9478 23.3682 41.3828 23.7252 40.8202 24.0834C40.7527 24.1266 40.6993 24.1327 40.6235 24.0992C39.9495 23.8024 39.2704 23.5104 38.5938 23.216C38.2906 23.0835 38.0188 22.9081 37.807 22.6529C37.3272 22.0788 37.4224 21.4262 38.0614 21.0214C38.2706 20.8901 38.5086 20.7932 38.7454 20.7172C39.8267 20.3725 40.9129 20.04 41.9904 19.7063C42.0814 19.678 42.1232 19.6383 42.1408 19.542C42.2861 18.7225 42.4352 17.8982 42.5868 17.0885C42.6675 16.6506 42.7101 16.2028 42.9276 15.8005C43.0109 15.6459 43.1105 15.495 43.2308 15.3662C43.6618 14.8976 44.2619 14.8804 44.7218 15.326C44.8759 15.4768 45.0074 15.6535 45.1214 15.8363C45.6226 16.6373 46.1162 17.4433 46.6124 18.2529C46.6706 18.3482 46.723 18.3674 46.8304 18.3397C48.0394 18.0219 49.2485 17.7091 50.4638 17.3963C50.7144 17.3317 50.9662 17.3082 51.2231 17.3552C51.7806 17.4573 52.0249 17.8729 51.8357 18.4016C51.7501 18.642 51.6014 18.8444 51.4348 19.037C50.5903 20.0098 49.7434 20.9875 48.9039 21.9566C48.8349 22.0361 48.8335 22.0928 48.8814 22.1824C49.3876 23.1159 49.8887 24.047 50.3974 24.9916C50.5178 25.2148 50.6104 25.4479 50.6129 25.7043C50.6188 26.2882 50.1819 26.7666 49.5893 26.8525C49.2573 26.9 48.949 26.8305 48.6371 26.7366C47.8791 26.5072 47.1211 26.2815 46.3568 26.057C46.2863 26.0364 46.2593 26.009 46.2467 25.9348C46.1595 25.411 46.0637 24.8884 45.971 24.3646C45.9686 24.3502 45.973 24.3349 45.9755 24.3028C46.8413 24.5371 47.7045 24.7677 48.5941 25.0094\" fill=\"#E25A1C\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M47.0789 32.6646C46.3948 32.6636 45.7133 32.6603 45.0242 32.6632C44.9336 32.6632 44.8826 32.6378 44.8325 32.5625C44.0231 31.3554 43.2037 30.1459 42.4019 28.9437C42.3759 28.9054 42.3485 28.8685 42.3025 28.8038C42.1283 30.1042 41.9567 31.38 41.7851 32.6558H39.9934C40.0145 32.4852 40.0331 32.3196 40.0552 32.1552C40.2293 30.8427 40.406 29.5423 40.5814 28.2297C40.7493 26.9785 40.9159 25.7272 41.0863 24.476C41.0912 24.439 41.1166 24.3916 41.1475 24.3719C41.7639 23.9781 42.3828 23.588 43.0017 23.198C43.0106 23.1922 43.0233 23.1917 43.0551 23.1826C42.8684 24.5811 42.683 25.9673 42.4963 27.3535C42.5037 27.3583 42.511 27.3635 42.5184 27.3683C43.4894 26.3158 44.4604 25.2584 45.4502 24.1911C45.4786 24.353 45.5035 24.4917 45.528 24.6303C45.5975 25.0265 45.6645 25.4252 45.7384 25.8214C45.7536 25.9014 45.7316 25.9502 45.6773 26.0067C45.0496 26.6495 44.4244 27.2947 43.798 27.9449C43.7705 27.9732 43.7446 28.0024 43.7133 28.036C43.7333 28.0671 43.7505 28.0974 43.7705 28.1251C44.8493 29.6094 45.9255 31.0938 47.003 32.5781C47.0225 32.605 47.0509 32.6261 47.0749 32.65V32.6734\" fill=\"#3C3A3E\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M25.905 28.7394C25.8776 28.6032 25.858 28.402 25.7959 28.2143C25.4952 27.3078 24.5468 26.8159 23.5657 27.0355C22.487 27.2808 21.7114 28.1113 21.6112 29.1945C21.5285 29.9919 21.967 30.7647 22.7814 31.0469C23.4379 31.2787 24.0719 31.1818 24.6608 30.8371C25.4388 30.3807 25.8598 29.7024 25.9137 28.7394H25.905ZM21.1691 32.1129C21.1162 32.503 21.0653 32.8698 21.0162 33.2378C20.9507 33.726 20.8847 34.2155 20.822 34.7099C20.8148 34.7669 20.7971 34.7923 20.7344 34.7918C20.2421 34.79 19.7497 34.7905 19.256 34.7895C19.2447 34.7895 19.2335 34.7837 19.207 34.7761C19.2369 34.5455 19.2658 34.3136 19.2966 34.083C19.4052 33.2734 19.5134 32.4637 19.6236 31.6541C19.7502 30.7267 19.8491 29.8017 20.0108 28.8817C20.2964 27.2501 21.7147 25.8517 23.3685 25.4959C24.3295 25.2923 25.2479 25.3866 26.0873 25.9167C26.9243 26.4442 27.4029 27.217 27.5156 28.1739C27.671 29.5355 27.1586 30.6641 26.175 31.6087C25.526 32.2233 24.7467 32.6134 23.8572 32.7459C22.9338 32.882 22.0655 32.7315 21.2887 32.1987C21.2603 32.1791 21.2295 32.1619 21.1806 32.1318\" fill=\"#3C3A3E\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M20.3421 24.3846C19.7908 24.787 19.2583 25.1746 18.7259 25.5635C18.6398 25.431 18.563 25.2985 18.4728 25.1747C18.241 24.8569 17.9528 24.6202 17.5344 24.592C17.1861 24.5679 16.8879 24.68 16.6511 24.9318C16.4393 25.1562 16.4118 25.4764 16.6095 25.7304C16.8275 26.01 17.0655 26.275 17.3098 26.5339C17.7145 26.9632 18.1368 27.3754 18.5377 27.8097C18.9023 28.2022 19.1942 28.6414 19.2844 29.1836C19.3917 29.8215 19.2615 30.4226 18.9536 30.9869C18.3836 32.0235 17.4878 32.6307 16.2975 32.8147C15.7738 32.8975 15.2526 32.8813 14.7439 32.7341C14.0661 32.539 13.5937 32.1036 13.2905 31.4951C13.1834 31.278 13.1014 31.0486 13.0049 30.8155C13.5975 30.5051 14.1751 30.2021 14.7589 29.8967C14.779 29.9442 14.7936 29.9839 14.8123 30.0218C14.9122 30.2169 14.994 30.4242 15.1168 30.6045C15.4839 31.1381 16.0752 31.3001 16.6704 31.0363C16.8245 30.9682 16.9736 30.8732 17.1001 30.7627C17.486 30.4266 17.5587 29.958 17.273 29.536C17.1089 29.2931 16.9034 29.0748 16.7029 28.8576C16.2243 28.3375 15.7257 27.8333 15.2621 27.2997C14.9401 26.9341 14.7209 26.5097 14.6507 26.0239C14.5749 25.4891 14.684 24.9861 14.9677 24.5396C15.6731 23.422 16.6967 22.8467 18.0498 22.8835C18.8228 22.9109 19.4405 23.265 19.9166 23.8538C20.0582 24.028 20.191 24.2084 20.3351 24.3973\" fill=\"#3C3A3E\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M33.4224 30.3339C33.3323 31.0074 33.247 31.6465 33.1593 32.2844C33.1544 32.317 33.1285 32.3611 33.1005 32.3736C31.7599 32.9796 30.0059 32.8949 28.9159 31.6756C28.327 31.0205 28.0802 30.2403 28.1165 29.3816C28.2021 27.382 29.8956 25.6278 31.9253 25.3825C33.1093 25.2402 34.143 25.553 34.9448 26.4546C35.4911 27.068 35.7442 27.804 35.7066 28.6137C35.6821 29.1485 35.5964 29.6797 35.5287 30.2084C35.4322 30.9616 35.327 31.7173 35.2255 32.4656C35.2216 32.4918 35.2162 32.5187 35.2098 32.5528H33.6186C33.6397 32.3798 33.6592 32.2106 33.6818 32.0413C33.7973 31.1715 33.9248 30.2993 34.0263 29.4283C34.0895 28.8861 34.0497 28.3476 33.7958 27.8459C33.5264 27.3122 33.0754 27.0289 32.4802 26.9675C31.2499 26.84 30.0747 27.6766 29.8241 28.8567C29.6512 29.6393 29.924 30.3901 30.5608 30.8072C31.181 31.2108 31.8388 31.212 32.5153 30.9507C32.8586 30.8182 33.1493 30.6072 33.4274 30.3239\" fill=\"#3C3A3E\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M40.1881 25.5866C40.1152 26.1288 40.0428 26.6625 39.9701 27.2059C39.6318 27.2059 39.301 27.2041 38.9703 27.2064C38.7022 27.2083 38.4578 27.3781 38.3764 27.6235C38.3451 27.7193 38.3334 27.8222 38.3196 27.9228C38.1518 29.1741 37.9851 30.413 37.8185 31.652C37.7764 31.9661 37.7358 32.2801 37.6937 32.5991H36.0273C36.0582 32.3599 36.0875 32.128 36.1183 31.8962C36.2264 31.089 36.3351 30.2769 36.4441 29.4795C36.5385 28.7815 36.6232 28.081 36.7347 27.3818C36.8838 26.4495 37.831 25.6153 38.7895 25.5785C39.248 25.5589 39.7079 25.5752 40.1802 25.5752\" fill=\"#3C3A3E\"/>\n<path d=\"M49.0837 32.6649V31.978H49.0798L48.8041 32.6649H48.7166L48.4409 31.978H48.4365V32.6649H48.2987V31.8418H48.513L48.7635 32.4674L49.0104 31.8418H49.2234V32.6649H49.0837ZM47.8633 31.9522V32.6649H47.7255V31.9522H47.4624V31.8419H48.1277V31.9522H47.8646\" fill=\"#3C3A3E\"/>\n<path d=\"M22.5598 23.2315H22.972L22.8745 22.6206L22.5598 23.2315ZM23.0372 23.6265H22.3518L22.1338 24.0448H21.6477L22.7189 22.082H23.1875L23.5521 24.0448H23.1023L23.0377 23.6265\" fill=\"#3C3A3E\"/>\n<path d=\"M25.4916 22.4832H25.2473L25.1651 22.9358H25.4094C25.5573 22.9358 25.6738 22.841 25.6738 22.6623C25.6738 22.5439 25.6004 22.4832 25.4909 22.4832H25.4916ZM24.9003 22.0882H25.5417C25.8775 22.0882 26.1118 22.2844 26.1118 22.6206C26.1118 23.045 25.8061 23.3296 25.3701 23.3296H25.0932L24.9629 24.0472H24.5444L24.8978 22.0845\" fill=\"#3C3A3E\"/>\n<path d=\"M27.5337 23.2315H27.9459L27.8486 22.6206L27.5337 23.2315ZM28.0098 23.6265H27.3245L27.1065 24.0448H26.6204L27.6916 22.082H28.1602L28.5248 24.0448H28.075L28.0103 23.6265\" fill=\"#3C3A3E\"/>\n<path d=\"M30.6659 23.9794C30.5243 24.0427 30.3689 24.0805 30.2123 24.0805C29.6824 24.0805 29.3503 23.6916 29.3503 23.2046C29.3503 22.5814 29.8853 22.0576 30.5218 22.0576C30.6809 22.0576 30.825 22.095 30.9428 22.1582L30.884 22.628C30.7959 22.5327 30.6535 22.4661 30.4781 22.4661C30.1135 22.4661 29.789 22.7887 29.789 23.1629C29.789 23.4475 29.9719 23.6708 30.2601 23.6708C30.4367 23.6708 30.6071 23.6041 30.7224 23.5125L30.6666 23.9787\" fill=\"#3C3A3E\"/>\n<path d=\"M33.297 23.256H32.4262L32.2846 24.0448H31.8674L32.2208 22.082H32.6392L32.4989 22.8573H33.3697L33.5112 22.082H33.9297L33.5764 24.0448H33.1579L33.2982 23.256\" fill=\"#3C3A3E\"/>\n<path d=\"M34.8005 24.0409L35.1539 22.0781H36.2639L36.1934 22.4731H35.5018L35.4312 22.8534H36.0665L35.9959 23.2484H35.3607L35.2902 23.6434H35.9818L35.9112 24.0384H34.8012\" fill=\"#3C3A3E\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_3526_17591\">\n<rect width=\"39\" height=\"19.8305\" fill=\"white\" transform=\"translate(13 15)\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/python_logo.svg":
/*!*************************************!*\
  !*** ./style/icons/python_logo.svg ***!
  \*************************************/
/***/ ((module) => {

module.exports = "<svg width=\"42\" height=\"42\" viewBox=\"0 0 42 42\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path d=\"M21.0869 0C10.3025 0 10.9755 4.66616 10.9755 4.66616L10.9888 9.50052H21.2794V10.9508H6.89887C6.89887 10.9508 0 10.1694 0 21.0275C0 31.883 6.02274 31.4989 6.02274 31.4989H9.61753V26.4605C9.61753 26.4605 9.42372 20.4514 15.5447 20.4514H25.7503C25.7503 20.4514 31.485 20.5441 31.485 14.9216V5.62508C31.485 5.62508 32.3558 0 21.0869 0ZM15.4119 3.25028C16.4354 3.25028 17.2638 4.07676 17.2638 5.09794C17.2638 6.11912 16.4354 6.94559 15.4119 6.94559C15.1687 6.94594 14.9277 6.89839 14.7029 6.80566C14.478 6.71293 14.2738 6.57685 14.1017 6.40521C13.9297 6.23356 13.7933 6.02974 13.7004 5.80542C13.6074 5.58109 13.5598 5.34068 13.5601 5.09794C13.5601 4.07676 14.3885 3.25028 15.4119 3.25028Z\" fill=\"url(#paint0_linear_3526_17687)\"/>\n<path d=\"M20.9132 42.0006C31.6976 42.0006 31.0245 37.3342 31.0245 37.3342L31.0113 32.4996H20.7207V31.0493H35.0999C35.0999 31.0493 42.0001 31.8307 42.0001 20.9735C42.0001 10.1163 35.9773 10.5017 35.9773 10.5017H32.3825V15.5389C32.3825 15.5389 32.5764 21.5483 26.4554 21.5483H16.2498C16.2498 21.5483 10.5151 21.4556 10.5151 27.0783V36.3752C10.5151 36.3752 9.6443 42.0006 20.9132 42.0006ZM26.5881 38.7501C26.3449 38.7505 26.1039 38.7029 25.8791 38.6102C25.6542 38.5175 25.4499 38.3814 25.2779 38.2097C25.1059 38.0381 24.9695 37.8342 24.8766 37.6099C24.7836 37.3856 24.736 37.1452 24.7363 36.9024C24.7363 35.8825 25.5647 35.056 26.5881 35.056C27.6116 35.056 28.44 35.8812 28.44 36.9024C28.44 37.925 27.6116 38.7501 26.5881 38.7501Z\" fill=\"url(#paint1_linear_3526_17687)\"/>\n<defs>\n<linearGradient id=\"paint0_linear_3526_17687\" x1=\"4.08197\" y1=\"3.68471\" x2=\"25.0391\" y2=\"24.7594\" gradientUnits=\"userSpaceOnUse\">\n<stop stop-color=\"#387EB8\"/>\n<stop offset=\"1\" stop-color=\"#366994\"/>\n</linearGradient>\n<linearGradient id=\"paint1_linear_3526_17687\" x1=\"16.5246\" y1=\"16.8992\" x2=\"39.0359\" y2=\"38.5138\" gradientUnits=\"userSpaceOnUse\">\n<stop stop-color=\"#FFE052\"/>\n<stop offset=\"1\" stop-color=\"#FFC331\"/>\n</linearGradient>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/refresh_icon.svg":
/*!**************************************!*\
  !*** ./style/icons/refresh_icon.svg ***!
  \**************************************/
/***/ ((module) => {

module.exports = "<svg width=\"14\" height=\"14\" viewBox=\"0 0 14 14\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M7 14C10.5262 14 13.4438 11.3921 13.9291 8H11.9C11.4368 10.2824 9.41913 12 7 12C4.2384 12 2 9.7616 2 7C2 4.2384 4.2384 2 7 2C8.3808 2 9.6308 2.5596 10.5356 3.4644L8 6H14V0L11.9497 2.05034C10.6829 0.783563 8.93287 0 7 0C3.13425 0 0 3.13425 0 7C0 10.8658 3.13425 14 7 14Z\" fill=\"black\"/>\n</svg>\n";

/***/ }),

/***/ "./style/icons/restart_icon.svg":
/*!**************************************!*\
  !*** ./style/icons/restart_icon.svg ***!
  \**************************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_1227_2377)\">\n<path d=\"M8.12917 16.9521C6.3875 16.7229 4.93611 15.959 3.775 14.6604C2.61389 13.3465 2.03333 11.8035 2.03333 10.0312C2.03333 9.05347 2.21667 8.1368 2.58333 7.28125C2.96528 6.41042 3.49236 5.65417 4.16458 5.0125L5.40208 6.25C4.88264 6.73889 4.47778 7.31181 4.1875 7.96875C3.9125 8.61042 3.775 9.29792 3.775 10.0312C3.775 11.3146 4.1875 12.4451 5.0125 13.4229C5.8375 14.3854 6.87639 14.9736 8.12917 15.1875V16.9521ZM9.87083 16.9521V15.1875C11.1236 14.9736 12.1625 14.3854 12.9875 13.4229C13.8125 12.4451 14.225 11.3146 14.225 10.0312C14.225 8.57986 13.7132 7.35 12.6896 6.34167C11.6813 5.31806 10.4514 4.80625 9 4.80625H8.88542L9.91667 5.8375L8.70208 7.05208L5.58542 3.93542L8.70208 0.818749L9.91667 2.03333L8.90833 3.06458H9C10.9403 3.06458 12.5826 3.74444 13.9271 5.10417C15.2868 6.44861 15.9667 8.09097 15.9667 10.0312C15.9667 11.8035 15.3861 13.3465 14.225 14.6604C13.0639 15.959 11.6125 16.7229 9.87083 16.9521Z\" fill=\"#444746\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_1227_2377\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/restart_icon_disable.svg":
/*!**********************************************!*\
  !*** ./style/icons/restart_icon_disable.svg ***!
  \**********************************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_1227_2377)\">\n<path d=\"M8.12917 16.9521C6.3875 16.7229 4.93611 15.959 3.775 14.6604C2.61389 13.3465 2.03333 11.8035 2.03333 10.0312C2.03333 9.05347 2.21667 8.1368 2.58333 7.28125C2.96528 6.41042 3.49236 5.65417 4.16458 5.0125L5.40208 6.25C4.88264 6.73889 4.47778 7.31181 4.1875 7.96875C3.9125 8.61042 3.775 9.29792 3.775 10.0312C3.775 11.3146 4.1875 12.4451 5.0125 13.4229C5.8375 14.3854 6.87639 14.9736 8.12917 15.1875V16.9521ZM9.87083 16.9521V15.1875C11.1236 14.9736 12.1625 14.3854 12.9875 13.4229C13.8125 12.4451 14.225 11.3146 14.225 10.0312C14.225 8.57986 13.7132 7.35 12.6896 6.34167C11.6813 5.31806 10.4514 4.80625 9 4.80625H8.88542L9.91667 5.8375L8.70208 7.05208L5.58542 3.93542L8.70208 0.818749L9.91667 2.03333L8.90833 3.06458H9C10.9403 3.06458 12.5826 3.74444 13.9271 5.10417C15.2868 6.44861 15.9667 8.09097 15.9667 10.0312C15.9667 11.8035 15.3861 13.3465 14.225 14.6604C13.0639 15.959 11.6125 16.7229 9.87083 16.9521Z\" fill=\"#8A8A8A\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_1227_2377\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/right_arrow_icon.svg":
/*!******************************************!*\
  !*** ./style/icons/right_arrow_icon.svg ***!
  \******************************************/
/***/ ((module) => {

module.exports = "<svg width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_3712_17139)\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M9 6L9 18L15 12L9 6Z\" fill=\"black\" fill-opacity=\"0.66\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_3712_17139\">\n<rect width=\"24\" height=\"24\" fill=\"white\" transform=\"translate(0 24) rotate(-90)\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/scala_logo.svg":
/*!************************************!*\
  !*** ./style/icons/scala_logo.svg ***!
  \************************************/
/***/ ((module) => {

module.exports = "<svg width=\"52\" height=\"52\" viewBox=\"0 0 52 52\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_3526_17609)\">\n<rect width=\"52\" height=\"52\" fill=\"white\"/>\n<g clip-path=\"url(#clip1_3526_17609)\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M43.3194 39.9948C43.2831 39.9173 43.2667 39.8783 43.2472 39.8411C42.7223 38.8428 42.1988 37.8445 41.6685 36.8462C41.6154 36.7461 41.6221 36.687 41.6948 36.6007C42.53 35.6253 43.3544 34.6446 44.191 33.6733C44.2205 33.639 44.2469 33.6027 44.2579 33.5416C44.0151 33.6049 43.7722 33.6675 43.528 33.7318C42.5201 33.9989 41.5041 34.2647 40.5056 34.5358C40.4118 34.5611 40.3693 34.5337 40.3221 34.4557C39.75 33.4992 39.1739 32.5401 38.595 31.5958C38.5655 31.5462 38.5332 31.4982 38.4701 31.4568C38.4237 31.7118 38.3767 31.9654 38.3311 32.2204C38.1705 33.1202 38.01 34.0146 37.8508 34.9184C37.8333 35.0154 37.8096 35.1127 37.8012 35.2098C37.7933 35.3026 37.7454 35.3369 37.6609 35.3636C36.4722 35.7373 35.2862 36.1137 34.0988 36.49C34.0467 36.5064 33.9956 36.528 33.9396 36.5785C34.9111 36.9644 35.8826 37.3502 36.8675 37.7428C36.8316 37.7712 36.8079 37.7934 36.7816 37.8102C36.1744 38.2028 35.5659 38.5954 34.9601 38.9893C34.8873 39.0368 34.8299 39.0435 34.7482 39.0067C34.0223 38.6802 33.291 38.3591 32.5624 38.0354C32.2359 37.8897 31.9431 37.6968 31.7151 37.4162C31.1983 36.7848 31.3008 36.0671 31.989 35.6219C32.2143 35.4776 32.4707 35.371 32.7257 35.2874C33.8901 34.9083 35.0599 34.5427 36.2203 34.1758C36.3182 34.1446 36.3633 34.1009 36.3822 33.995C36.5387 33.0939 36.6993 32.1873 36.8625 31.2969C36.9494 30.8153 36.9953 30.3229 37.2295 29.8805C37.3193 29.7105 37.4265 29.5445 37.5561 29.4029C38.0202 28.8876 38.6665 28.8687 39.1617 29.3587C39.3277 29.5246 39.4693 29.7188 39.5921 29.9199C40.1318 30.8008 40.6635 31.6871 41.1978 32.5774C41.2605 32.6823 41.3169 32.7033 41.4325 32.6728C42.7346 32.3234 44.0366 31.9794 45.3454 31.6354C45.6153 31.5643 45.8865 31.5386 46.1631 31.5902C46.7635 31.7025 47.0266 32.1595 46.8229 32.741C46.7307 33.0054 46.5706 33.228 46.3911 33.4397C45.4817 34.5095 44.5696 35.5847 43.6656 36.6504C43.5912 36.7379 43.5898 36.8002 43.6413 36.8987C44.1864 37.9253 44.7261 38.9492 45.2739 39.988C45.4036 40.2335 45.5033 40.4898 45.506 40.7717C45.5123 41.4139 45.0419 41.94 44.4036 42.0344C44.0461 42.0867 43.7142 42.0103 43.3782 41.907C42.5619 41.6547 41.7456 41.4065 40.9225 41.1596C40.8465 41.1369 40.8175 41.1068 40.8039 41.0252C40.71 40.4492 40.6069 39.8745 40.5071 39.2985C40.5045 39.2827 40.5092 39.2658 40.5119 39.2305C41.4443 39.4881 42.3739 39.7418 43.3319 40.0075\" fill=\"#E25A1C\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M41.7004 48.4264C40.9637 48.4253 40.2297 48.4217 39.4876 48.4249C39.39 48.4249 39.3351 48.397 39.2811 48.3141C38.4095 46.9867 37.5271 45.6565 36.6635 44.3345C36.6356 44.2924 36.6061 44.2518 36.5565 44.1807C36.369 45.6107 36.1841 47.0137 35.9993 48.4167H34.0698C34.0925 48.2292 34.1126 48.047 34.1363 47.8663C34.3239 46.4228 34.5141 44.9928 34.703 43.5494C34.8838 42.1733 35.0633 40.7973 35.2468 39.4213C35.2521 39.3807 35.2794 39.3285 35.3126 39.3069C35.9765 38.8739 36.643 38.4449 37.3096 38.0159C37.3191 38.0095 37.3328 38.009 37.367 37.999C37.166 39.5369 36.9663 41.0613 36.7653 42.5857C36.7732 42.591 36.7811 42.5968 36.789 42.6021C37.8347 41.4446 38.8804 40.2817 39.9463 39.1081C39.977 39.2861 40.0038 39.4386 40.0301 39.591C40.105 40.0268 40.1772 40.4652 40.2568 40.9009C40.2731 40.9889 40.2494 41.0426 40.1909 41.1046C39.515 41.8115 38.8417 42.5211 38.167 43.2361C38.1375 43.2673 38.1096 43.2994 38.0758 43.3363C38.0974 43.3705 38.1159 43.4038 38.1375 43.4343C39.2992 45.0666 40.4582 46.6989 41.6186 48.3313C41.6397 48.3608 41.6702 48.384 41.6961 48.4103V48.4361\" fill=\"#3C3A3E\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M18.8976 44.1093C18.868 43.9596 18.847 43.7383 18.78 43.5319C18.4562 42.535 17.4348 41.994 16.3783 42.2355C15.2166 42.5053 14.3814 43.4186 14.2735 44.6098C14.1844 45.4867 14.6566 46.3366 15.5337 46.6468C16.2407 46.9018 16.9234 46.7952 17.5576 46.4162C18.3955 45.9143 18.8488 45.1683 18.9069 44.1093H18.8976ZM13.7973 47.8192C13.7404 48.2481 13.6856 48.6515 13.6327 49.0562C13.5621 49.5931 13.491 50.1314 13.4235 50.6751C13.4157 50.7378 13.3967 50.7657 13.3292 50.7652C12.799 50.7632 12.2687 50.7637 11.7371 50.7626C11.7249 50.7626 11.7128 50.7563 11.6843 50.7479C11.7164 50.4943 11.7476 50.2393 11.7808 49.9857C11.8978 49.0953 12.0142 48.205 12.133 47.3146C12.2692 46.2947 12.3758 45.2776 12.5499 44.2658C12.8575 42.4716 14.3849 40.9337 16.1659 40.5425C17.2008 40.3185 18.1899 40.4223 19.0939 41.0052C19.9952 41.5853 20.5106 42.4352 20.632 43.4874C20.7994 44.9848 20.2475 46.2259 19.1883 47.2647C18.4894 47.9406 17.6501 48.3696 16.6922 48.5153C15.6977 48.665 14.7627 48.4995 13.9261 47.9136C13.8955 47.892 13.8623 47.8731 13.8097 47.8399\" fill=\"#3C3A3E\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M12.9068 39.3201C12.3131 39.7626 11.7396 40.1889 11.1662 40.6165C11.0735 40.4708 10.9908 40.3252 10.8936 40.1889C10.644 39.8395 10.3337 39.5791 9.88303 39.5481C9.50793 39.5217 9.1868 39.645 8.93179 39.9218C8.70376 40.1687 8.67408 40.5208 8.88699 40.8C9.12177 41.1076 9.37813 41.399 9.64124 41.6836C10.0771 42.1558 10.5318 42.6091 10.9635 43.0866C11.3562 43.5183 11.6705 44.0013 11.7677 44.5975C11.8832 45.299 11.743 45.9601 11.4115 46.5806C10.7976 47.7206 9.83283 48.3883 8.55102 48.5907C7.98702 48.6817 7.42573 48.6639 6.87792 48.502C6.14796 48.2876 5.63929 47.8086 5.31276 47.1395C5.1974 46.9007 5.10902 46.6485 5.00513 46.3922C5.64333 46.0509 6.26535 45.7176 6.89411 45.3817C6.9157 45.4339 6.93149 45.4777 6.95159 45.5193C7.05913 45.7338 7.14724 45.9618 7.27946 46.1601C7.6748 46.747 8.31166 46.925 8.95257 46.635C9.11853 46.5601 9.27909 46.4556 9.41537 46.3342C9.83094 45.9645 9.9092 45.4492 9.60157 44.9851C9.42481 44.718 9.20353 44.4779 8.98765 44.2391C8.47222 43.6671 7.93521 43.1127 7.43598 42.5258C7.08922 42.1238 6.85309 41.6571 6.77753 41.1228C6.6959 40.5347 6.81343 39.9816 7.1189 39.4905C7.87854 38.2615 8.9809 37.6288 10.4381 37.6693C11.2706 37.6994 11.9358 38.0889 12.4485 38.7364C12.601 38.928 12.744 39.1263 12.8992 39.334\" fill=\"#3C3A3E\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M26.9932 45.8631C26.8962 46.6037 26.8043 47.3066 26.7098 48.0081C26.7046 48.0439 26.6766 48.0924 26.6466 48.1061C25.2028 48.7726 23.3138 48.6795 22.14 47.3385C21.5058 46.6181 21.24 45.7602 21.2791 44.8158C21.3713 42.6169 23.1951 40.6878 25.3809 40.418C26.656 40.2615 27.7692 40.6055 28.6327 41.597C29.221 42.2716 29.4935 43.081 29.4531 43.9713C29.4267 44.5595 29.3345 45.1437 29.2615 45.7251C29.1576 46.5534 29.0442 47.3844 28.9349 48.2073C28.9307 48.2362 28.9249 48.2657 28.9181 48.3032H27.2045C27.2272 48.113 27.2482 47.9268 27.2725 47.7407C27.3969 46.7842 27.5342 45.8251 27.6435 44.8672C27.7115 44.271 27.6688 43.6787 27.3953 43.127C27.1052 42.5402 26.6194 42.2285 25.9785 42.1611C24.6535 42.0208 23.3879 42.9408 23.1181 44.2386C22.9319 45.0993 23.2256 45.9249 23.9114 46.3836C24.5793 46.8274 25.2877 46.8287 26.0163 46.5414C26.386 46.3957 26.699 46.1637 26.9986 45.852\" fill=\"#3C3A3E\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M34.2794 40.6426C34.2009 41.2389 34.1229 41.8257 34.0446 42.4233C33.6803 42.4233 33.3241 42.4213 32.9679 42.4239C32.6792 42.426 32.416 42.6127 32.3283 42.8825C32.2946 42.9879 32.2821 43.1011 32.2672 43.2117C32.0864 44.5877 31.907 45.9502 31.7275 47.3128C31.6822 47.6581 31.6385 48.0035 31.5931 48.3542H29.7986C29.8318 48.0911 29.8633 47.8362 29.8965 47.5812C30.013 46.6935 30.13 45.8005 30.2474 44.9236C30.3491 44.156 30.4403 43.3857 30.5604 42.6168C30.7209 41.5915 31.741 40.6742 32.7732 40.6337C33.267 40.6121 33.7622 40.63 34.2709 40.63\" fill=\"#3C3A3E\"/>\n<path d=\"M43.8592 48.4262V47.6707H43.8551L43.5582 48.4262H43.4639L43.1671 47.6707H43.1623V48.4262H43.0139V47.521H43.2447L43.5145 48.209L43.7803 47.521H44.0097V48.4262H43.8592ZM42.5451 47.6424V48.4262H42.3966V47.6424H42.1133V47.5211H42.8297V47.6424H42.5464\" fill=\"#3C3A3E\"/>\n<path d=\"M15.295 38.0521H15.7389L15.634 37.3803L15.295 38.0521ZM15.8091 38.4865H15.071L14.8363 38.9465H14.3127L15.4664 36.7881H15.971L16.3636 38.9465H15.8793L15.8096 38.4865\" fill=\"#3C3A3E\"/>\n<path d=\"M18.4522 37.2295H18.1891L18.1006 37.7272H18.3637C18.5229 37.7272 18.6484 37.623 18.6484 37.4264C18.6484 37.2962 18.5693 37.2295 18.4514 37.2295H18.4522ZM17.8153 36.7951H18.5062C18.8678 36.7951 19.1201 37.0109 19.1201 37.3805C19.1201 37.8473 18.7908 38.1603 18.3213 38.1603H18.0231L17.8828 38.9495H17.4321L17.8126 36.791\" fill=\"#3C3A3E\"/>\n<path d=\"M20.6516 38.0521H21.0955L20.9907 37.3803L20.6516 38.0521ZM21.1643 38.4865H20.4263L20.1915 38.9465H19.668L20.8216 36.7881H21.3262L21.7189 38.9465H21.2345L21.1649 38.4865\" fill=\"#3C3A3E\"/>\n<path d=\"M24.0249 38.8751C23.8724 38.9447 23.7051 38.9863 23.5365 38.9863C22.9657 38.9863 22.6082 38.5586 22.6082 38.0231C22.6082 37.3378 23.1843 36.7617 23.8697 36.7617C24.0411 36.7617 24.1963 36.8029 24.3231 36.8723L24.2598 37.389C24.1649 37.2842 24.0115 37.2109 23.8226 37.2109C23.43 37.2109 23.0805 37.5657 23.0805 37.9772C23.0805 38.2902 23.2775 38.5357 23.5879 38.5357C23.7781 38.5357 23.9616 38.4624 24.0857 38.3617L24.0257 38.8743\" fill=\"#3C3A3E\"/>\n<path d=\"M26.8584 38.0791H25.9206L25.7682 38.9465H25.3188L25.6993 36.7881H26.15L25.9989 37.6407H26.9366L27.0891 36.7881H27.5398L27.1593 38.9465H26.7086L26.8597 38.0791\" fill=\"#3C3A3E\"/>\n<path d=\"M28.4773 38.9426L28.8578 36.7842H30.0532L29.9773 37.2186H29.2325L29.1565 37.6368H29.8406L29.7646 38.0712H29.0806L29.0046 38.5055H29.7494L29.6734 38.9399H28.478\" fill=\"#3C3A3E\"/>\n</g>\n<rect x=\"-26\" y=\"-3\" width=\"107\" height=\"21\" fill=\"#F4F6FB\"/>\n<path d=\"M19.5541 10.6707C19.5541 11.428 19.2806 12.0247 18.7336 12.4607C18.1905 12.8967 17.4332 13.1147 16.4617 13.1147C15.5667 13.1147 14.7749 12.9465 14.0864 12.6099V10.9575C14.6525 11.21 15.1306 11.3878 15.5208 11.4911C15.9147 11.5944 16.2743 11.646 16.5994 11.646C16.9895 11.646 17.2878 11.5714 17.4944 11.4222C17.7048 11.2731 17.8099 11.0512 17.8099 10.7567C17.8099 10.5922 17.764 10.4469 17.6722 10.3207C17.5804 10.1906 17.4447 10.0663 17.2649 9.94775C17.0889 9.82918 16.7275 9.63985 16.1805 9.37976C15.668 9.13879 15.2836 8.90739 15.0273 8.68555C14.7711 8.4637 14.5664 8.20553 14.4135 7.91101C14.2605 7.6165 14.184 7.27226 14.184 6.8783C14.184 6.13627 14.4345 5.55298 14.9355 5.12842C15.4404 4.70386 16.1366 4.49158 17.0239 4.49158C17.46 4.49158 17.875 4.54321 18.2689 4.64648C18.6667 4.74976 19.0817 4.8951 19.5139 5.08252L18.9402 6.46521C18.4927 6.28162 18.1217 6.15348 17.8271 6.08081C17.5365 6.00814 17.2496 5.9718 16.9666 5.9718C16.63 5.9718 16.3718 6.05021 16.192 6.20703C16.0122 6.36385 15.9224 6.56848 15.9224 6.82092C15.9224 6.97774 15.9587 7.11544 16.0314 7.23401C16.104 7.34875 16.2188 7.46159 16.3756 7.57251C16.5363 7.67961 16.913 7.87467 17.5059 8.15771C18.29 8.53255 18.8274 8.9093 19.118 9.28796C19.4087 9.6628 19.5541 10.1237 19.5541 10.6707Z\" fill=\"black\"/>\n<path d=\"M23.189 13.1147C21.1924 13.1147 20.1941 12.0189 20.1941 9.82727C20.1941 8.73718 20.4657 7.90527 21.0088 7.33154C21.552 6.75399 22.3303 6.46521 23.3439 6.46521C24.0859 6.46521 24.7515 6.61055 25.3405 6.90125L24.8241 8.25525C24.5487 8.14433 24.2925 8.05444 24.0553 7.9856C23.8182 7.91292 23.5811 7.87659 23.3439 7.87659C22.4336 7.87659 21.9784 8.52299 21.9784 9.8158C21.9784 11.0704 22.4336 11.6976 23.3439 11.6976C23.6805 11.6976 23.9922 11.6536 24.2791 11.5657C24.566 11.4739 24.8528 11.3324 25.1397 11.1411V12.6385C24.8566 12.8183 24.5698 12.9426 24.2791 13.0115C23.9922 13.0803 23.6289 13.1147 23.189 13.1147Z\" fill=\"black\"/>\n<path d=\"M30.3524 13L30.0139 12.1279H29.968C29.6735 12.4989 29.3694 12.7571 29.0557 12.9025C28.7459 13.044 28.3405 13.1147 27.8394 13.1147C27.2236 13.1147 26.7379 12.9388 26.3822 12.5869C26.0303 12.235 25.8543 11.734 25.8543 11.0837C25.8543 10.4029 26.0915 9.90186 26.5658 9.58057C27.0439 9.25545 27.7629 9.07568 28.723 9.04126L29.836 9.00684V8.72571C29.836 8.07548 29.5033 7.75037 28.8377 7.75037C28.3252 7.75037 27.7228 7.90527 27.0305 8.21509L26.451 7.0332C27.1892 6.64689 28.0077 6.45374 28.9066 6.45374C29.7672 6.45374 30.427 6.64115 30.8859 7.01599C31.3449 7.39083 31.5744 7.96073 31.5744 8.72571V13H30.3524ZM29.836 10.0281L29.159 10.051C28.6503 10.0663 28.2716 10.1581 28.023 10.3264C27.7744 10.4947 27.6501 10.751 27.6501 11.0952C27.6501 11.5886 27.9331 11.8353 28.4992 11.8353C28.9047 11.8353 29.2279 11.7187 29.4688 11.4854C29.7136 11.252 29.836 10.9422 29.836 10.5559V10.0281Z\" fill=\"black\"/>\n<path d=\"M34.779 13H33.0292V4.07275H34.779V13Z\" fill=\"black\"/>\n<path d=\"M40.3417 13L40.0032 12.1279H39.9573C39.6628 12.4989 39.3587 12.7571 39.0451 12.9025C38.7353 13.044 38.3298 13.1147 37.8288 13.1147C37.213 13.1147 36.7272 12.9388 36.3715 12.5869C36.0196 12.235 35.8437 11.734 35.8437 11.0837C35.8437 10.4029 36.0808 9.90186 36.5551 9.58057C37.0332 9.25545 37.7523 9.07568 38.7123 9.04126L39.8254 9.00684V8.72571C39.8254 8.07548 39.4926 7.75037 38.8271 7.75037C38.3145 7.75037 37.7121 7.90527 37.0198 8.21509L36.4403 7.0332C37.1785 6.64689 37.9971 6.45374 38.8959 6.45374C39.7565 6.45374 40.4163 6.64115 40.8753 7.01599C41.3343 7.39083 41.5638 7.96073 41.5638 8.72571V13H40.3417ZM39.8254 10.0281L39.1483 10.051C38.6396 10.0663 38.261 10.1581 38.0124 10.3264C37.7637 10.4947 37.6394 10.751 37.6394 11.0952C37.6394 11.5886 37.9225 11.8353 38.4886 11.8353C38.894 11.8353 39.2172 11.7187 39.4582 11.4854C39.703 11.252 39.8254 10.9422 39.8254 10.5559V10.0281Z\" fill=\"black\"/>\n<path d=\"M25.065 25.4977C25.065 26.0682 25.0104 26.5721 24.901 27.0093C24.7948 27.4434 24.6338 27.8093 24.4182 28.107C24.2057 28.4016 23.9415 28.6248 23.6257 28.7767C23.3129 28.9256 22.95 29 22.5371 29C22.1271 29 21.7643 28.924 21.4484 28.7721C21.1326 28.6202 20.8669 28.3969 20.6513 28.1023C20.4357 27.8047 20.2733 27.4372 20.164 27C20.0547 26.5628 20 26.0589 20 25.4884C20 24.7318 20.0957 24.0946 20.287 23.5767C20.4813 23.0589 20.7667 22.6667 21.1433 22.4C21.5228 22.1333 21.9874 22 22.5371 22C23.0897 22 23.5528 22.1318 23.9263 22.3953C24.3028 22.6589 24.5867 23.0512 24.7781 23.5721C24.9694 24.0899 25.065 24.7318 25.065 25.4977ZM21.6489 25.4977C21.6489 25.9597 21.6823 26.3457 21.7491 26.6558C21.8159 26.9659 21.9146 27.1984 22.0451 27.3535C22.1787 27.5054 22.3427 27.5814 22.5371 27.5814C22.7375 27.5814 22.9014 27.507 23.029 27.3581C23.1596 27.2093 23.2552 26.9814 23.3159 26.6744C23.3797 26.3643 23.4116 25.9721 23.4116 25.4977C23.4116 24.7783 23.3387 24.2481 23.193 23.907C23.0502 23.5628 22.8316 23.3907 22.5371 23.3907C22.3427 23.3907 22.1787 23.4698 22.0451 23.6279C21.9146 23.7829 21.8159 24.0171 21.7491 24.3302C21.6823 24.6403 21.6489 25.0295 21.6489 25.4977Z\" fill=\"#3C3A3E\"/>\n<path d=\"M31 28.907H29.1507L27.4153 24.6791H27.3789C27.3971 24.9271 27.4108 25.1581 27.4199 25.3721C27.432 25.5829 27.4396 25.7752 27.4427 25.9488C27.4487 26.1194 27.4518 26.2698 27.4518 26.4V28.907H25.9805V22.107H27.8161L29.5424 26.2186H29.5789C29.5667 25.9891 29.5561 25.7752 29.547 25.5767C29.5379 25.3783 29.5303 25.1953 29.5242 25.0279C29.5182 24.8605 29.5151 24.7085 29.5151 24.5721V22.107H31V28.907Z\" fill=\"#3C3A3E\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_3526_17609\">\n<rect width=\"52\" height=\"52\" fill=\"white\"/>\n</clipPath>\n<clipPath id=\"clip1_3526_17609\">\n<rect width=\"42\" height=\"21.8077\" fill=\"white\" transform=\"translate(5 29)\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/search_icon.svg":
/*!*************************************!*\
  !*** ./style/icons/search_icon.svg ***!
  \*************************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M9.76831 11.1645C8.97573 11.6924 8.02383 12 7 12C4.2383 12 2 9.7617 2 7C2 4.2383 4.2383 2 7 2C9.7617 2 12 4.2383 12 7C12 8.01451 11.698 8.95839 11.1789 9.74663L15.682 14.2497L14.2678 15.664L9.76831 11.1645ZM7 10C8.65685 10 10 8.65685 10 7C10 5.34315 8.65685 4 7 4C5.34315 4 4 5.34315 4 7C4 8.65685 5.34315 10 7 10Z\" fill=\"black\"/>\n</svg>\n";

/***/ }),

/***/ "./style/icons/serverless_icon.svg":
/*!*****************************************!*\
  !*** ./style/icons/serverless_icon.svg ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "<svg width=\"52\" height=\"52\" viewBox=\"0 0 52 52\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<rect width=\"52\" height=\"52\" fill=\"white\"/>\n<g clip-path=\"url(#clip0_2788_15614)\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M41.2396 23.229L36.8855 26.1318L41.2396 29.0346L43.4167 30.486L41.2396 31.9373L36.8855 34.8401L26 42.0971L15.1146 34.8401L10.7605 31.9373L8.58337 30.486L10.7605 29.0346L15.1049 26.1383L15.0894 26.115L10.7605 23.229L8.58337 21.7776L10.7605 20.3262L26 10.1665L41.2396 20.3262L43.4167 21.7776L41.2396 23.229ZM24.5487 14.0417V19.2892L16.8524 24.3875L12.9375 21.7776L24.5487 14.0417ZM27.4514 19.8473L34.7084 24.6804L39.0625 21.7776L27.4514 14.0417V19.8473ZM27.5834 38.1387V32.3332H30.75L26 25.9998L21.25 32.3332H24.4167V38.1387L12.9375 30.486L17.2917 27.5832L26 21.7786L34.7084 27.5832L39.0625 30.486L27.5834 38.1387Z\" fill=\"#3367D6\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_2788_15614\">\n<rect width=\"38\" height=\"38\" fill=\"white\" transform=\"translate(7 7)\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/settings_icon.svg":
/*!***************************************!*\
  !*** ./style/icons/settings_icon.svg ***!
  \***************************************/
/***/ ((module) => {

module.exports = "<svg width=\"31\" height=\"29\" viewBox=\"0 0 31 29\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M25.3562 18.5132L9.06505 27.9289L7.5093 25.2371L23.8005 15.8214L25.3562 18.5132Z\" fill=\"#85A4E6\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M9.00774 24.8616L9.00024 6.04559L11.9935 6.04419L12.0002 22.5972L9.00774 24.8616Z\" fill=\"#85A4E6\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M12.103 11.3096L11.6797 7.52124L27.9792 16.9225L26.4259 19.6157L12.103 11.3096Z\" fill=\"#85A4E6\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M19.8295 12.2219L11.6797 7.52124L12.103 11.3096L14.5156 12.6874C16.4101 13.3677 18.77 13.0119 19.8295 12.2219Z\" fill=\"#3367D6\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M9.8071 9.0613L9.8069 9.061C9.2795 8.1476 9.0004 7.1049 9 6.0453C8.9994 4.4316 9.627 2.9137 10.768 1.7718C11.909 0.629901 13.4262 0.000700647 15.0402 6.46588e-07C17.1939 -0.000999353 19.2013 1.158 20.2791 3.0245C20.8065 3.9379 21.0854 4.9808 21.086 6.0402C21.0871 9.3725 18.3772 12.0846 15.0453 12.0858C12.8919 12.0863 10.8846 10.9275 9.8071 9.0613ZM17.5866 4.579C17.0627 3.6716 16.0874 3.1083 15.0416 3.1088C14.258 3.1093 13.5214 3.4147 12.9675 3.9691C12.4136 4.5235 12.1088 5.2604 12.109 6.0441C12.1093 6.5589 12.2443 7.0647 12.4993 7.5064C13.0232 8.4138 13.998 8.977 15.0443 8.9766C16.662 8.9762 17.9775 7.6593 17.9769 6.0413C17.9768 5.5268 17.8418 5.021 17.5866 4.579Z\" fill=\"#85A4E6\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M9.00439 16.5056L9.00779 24.8614L12.0002 22.5969L11.9995 19.9898C11.6524 18.2819 10.2041 17.0405 9.00439 16.5056Z\" fill=\"#3367D6\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M18.122 22.6935L25.3569 18.5124L21.8246 16.9619L19.8294 18.116C18.7904 19.2079 17.9676 21.3548 18.122 22.6935Z\" fill=\"#3367D6\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M0.809447 25.719L0.808247 25.7169C-0.857153 22.8326 0.134247 19.1298 3.01805 17.4634C4.41535 16.6556 6.04385 16.4407 7.60325 16.8578C9.16265 17.2749 10.466 18.2742 11.2736 19.6717C12.9402 22.5581 11.949 26.2607 9.06545 27.9274C6.18015 29.5948 2.47665 28.6041 0.809447 25.719ZM8.58255 21.2287C8.18975 20.5489 7.55685 20.0638 6.79975 19.8611C6.04275 19.6587 5.25215 19.7632 4.57365 20.1553C3.17355 20.9644 2.69215 22.7621 3.50085 24.1627L3.50135 24.1635C4.31085 25.5643 6.10905 26.0452 7.50985 25.2357C8.90975 24.4263 9.39115 22.629 8.58255 21.2287Z\" fill=\"#85A4E6\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M19.7283 25.1829C19.7281 25.1826 19.7281 25.1826 19.7281 25.1826C18.6515 23.3179 18.6504 21.0015 19.7254 19.1381C20.5319 17.7399 21.8348 16.7395 23.3938 16.321C24.9528 15.9026 26.5812 16.1162 27.9794 16.9226C28.8987 17.4527 29.6637 18.2167 30.192 19.1316C31.2686 20.9963 31.2697 23.3127 30.1946 25.1765C29.3881 26.5747 28.0852 27.5751 26.5265 27.9934C24.9675 28.4118 23.3389 28.198 21.9406 27.3913C21.0214 26.8615 20.2564 26.0976 19.7283 25.1829ZM27.4995 20.6862C27.2439 20.2434 26.8727 19.8733 26.4261 19.6158C25.0247 18.8074 23.2268 19.2901 22.4187 20.6913C21.8966 21.5965 21.8974 22.7217 22.4207 23.628C22.6763 24.0708 23.0475 24.4409 23.4941 24.6984C24.1733 25.0902 24.9638 25.194 25.7206 24.9909C26.4776 24.7877 27.1098 24.3021 27.5015 23.6233C28.0234 22.7182 28.0228 21.5925 27.4995 20.6862Z\" fill=\"#85A4E6\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M11.9864 21.6326C11.9864 21.6326 8.23897 24.814 7.50977 25.2356L12.0727 22.5987C12.0676 22.2586 12.0497 21.9713 11.9864 21.6326Z\" fill=\"#5C85DE\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M13.0359 11.7302C13.0359 11.7302 12.1011 6.55899 12.1008 6.04419L12.103 11.3098C12.4015 11.4747 12.7132 11.6163 13.0359 11.7302Z\" fill=\"#5C85DE\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M21.2842 17.3536C21.2842 17.3536 25.6961 19.1949 26.4261 19.6159L21.8611 16.9829C21.5671 17.1599 21.5439 17.1302 21.2842 17.3536Z\" fill=\"#5C85DE\"/>\n</svg>\n";

/***/ }),

/***/ "./style/icons/signin_google_icon.svg":
/*!********************************************!*\
  !*** ./style/icons/signin_google_icon.svg ***!
  \********************************************/
/***/ ((module) => {

module.exports = "<svg width=\"215\" height=\"63\" viewBox=\"0 0 215 63\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">\n<rect width=\"215\" height=\"63\" fill=\"url(#pattern0)\"/>\n<defs>\n<pattern id=\"pattern0\" patternContentUnits=\"objectBoundingBox\" width=\"1\" height=\"1\">\n<use xlink:href=\"#image0_2908_26611\" transform=\"scale(0.00232558 0.00793651)\"/>\n</pattern>\n<image id=\"image0_2908_26611\" width=\"430\" height=\"126\" xlink:href=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAa4AAAB+CAYAAAB8vPUBAAAKsWlDQ1BJQ0MgUHJvZmlsZQAASImVlwdUE+kWgP+Z9JDQAhGQEnpHikAAKSG0AArSwUZIAgklxBQE7MriCq4FFREsK7pUBRtFbIgoFhbF3jfIIqCsiwUbKm+AQ9jdd957591z/rnfuXP/W+bMP+cOAGQttkiUDqsCkCGUiiMCfWlx8Qk0XD9AAzIgAFugyuZIRIzw8FCAyJT+u3y4B6Bxfdt2PNa/3/+vosblSTgAQOEIJ3ElnAyETyLrPUcklgKAqkLsxsukonHuRFhDjBSIsHycUyb5/TgnTTAaP+ETFcFEWBcAPInNFqcAQLJA7LQsTgoShxSEsL2QKxAinI2wV0ZGJhfhZoQtEB8RwuPx6Ul/iZPyt5hJiphsdoqCJ3uZELyfQCJKZ+f8n4/jf0tGumwqhxmySHxxUASikbqgB2mZIQoWJs0Lm2IBd8J/gvmyoOgp5kiYCVPMZfuFKPamzwud4mRBAEsRR8qKmmKexD9yisWZEYpcyWImY4rZ4um8srRohZ3PYyni5/KjYqc4SxAzb4olaZEh0z5MhV0si1DUzxMG+k7nDVD0niH5S78ClmKvlB8VpOidPV0/T8iYjimJU9TG5fn5T/tEK/xFUl9FLlF6uMKflx6osEuyIhV7pcgLOb03XPEMU9nB4VMMIoEUyAAXCEAmoAE/REuACKQDNsiR8rKl4w0xM0U5YkEKX0pjICeNR2MJOXY2NEd7RycAxs/t5GvxjjpxHiHqtWnb+moAPE+NjY2dnrYF3wTgWCIAxIZpm8UiAFT7AbhyhiMTZ03a0OMXDCACFaABtIE+MAYWyJfBEbgAD+AD/EEwCANRIB4sBhzABxlADJaBFWAtyAeFYCvYCUrBfnAQVIEj4DhoAmfABXAZXAc3wV3wGMhBH3gFhsEHMApBEA4iQxRIGzKATCFryBGiQ16QPxQKRUDxUCKUAgkhGbQCWg8VQkVQKXQAqoaOQaegC9BVqBt6CPVAg9Bb6AuMgkmwBqwHm8GzYDrMgEPgKHgRnAIvhXPhPHgzXAKXw4fhRvgCfB2+C8vhV/AICqCUUFSUIcoWRUcxUWGoBFQySoxahSpAFaPKUXWoFlQH6jZKjhpCfUZj0RQ0DW2L9kAHoaPRHPRS9Cr0JnQpugrdiG5H30b3oIfR3zFkjC7GGuOOYWHiMCmYZZh8TDGmAtOAuYS5i+nDfMBisVSsOdYVG4SNx6Zil2M3Yfdi67Gt2G5sL3YEh8Np46xxnrgwHBsnxeXjduMO487jbuH6cJ/wSngDvCM+AJ+AF+LX4YvxNfhz+Fv4fvwoQZVgSnAnhBG4hBzCFsIhQgvhBqGPMEpUI5oTPYlRxFTiWmIJsY54ifiE+E5JSclIyU1pvpJAaY1SidJRpStKPUqfSeokKxKTtJAkI20mVZJaSQ9J78hkshnZh5xAlpI3k6vJF8nPyJ+UKcp2yixlrvJq5TLlRuVbyq9VCCqmKgyVxSq5KsUqJ1RuqAypElTNVJmqbNVVqmWqp1Tvq46oUdQc1MLUMtQ2qdWoXVUbUMepm6n7q3PV89QPql9U76WgKMYUJoVDWU85RLlE6dPAaphrsDRSNQo1jmh0aQxrqmvO1ozRzNYs0zyrKaeiqGZUFjWduoV6nHqP+mWG3gzGDN6MjTPqZtya8VFrppaPFk+rQKte667WF22atr92mvY27SbtpzpoHSud+TrLdPbpXNIZmqkx02MmZ2bBzOMzH+nCula6EbrLdQ/qduqO6OnrBeqJ9HbrXdQb0qfq++in6u/QP6c/aEAx8DIQGOwwOG/wkqZJY9DSaSW0dtqwoa5hkKHM8IBhl+GokblRtNE6o3qjp8ZEY7pxsvEO4zbjYRMDk7kmK0xqTR6ZEkzppnzTXaYdph/NzM1izTaYNZkNmGuZs8xzzWvNn1iQLbwtllqUW9yxxFrSLdMs91retIKtnK34VmVWN6xhaxdrgfVe624bjI2bjdCm3Oa+LcmWYZtlW2vbY0e1C7VbZ9dk93qWyayEWdtmdcz6bu9sn25/yP6xg7pDsMM6hxaHt45WjhzHMsc7TmSnAKfVTs1Ob2Zbz+bN3jf7gTPFea7zBuc2528uri5ilzqXQVcT10TXPa736Rr0cPom+hU3jJuv22q3M26f3V3cpe7H3f/0sPVI86jxGJhjPoc359CcXk8jT7bnAU+5F80r0etnL7m3oTfbu9z7uY+xD9enwqefYclIZRxmvPa19xX7Nvh+ZLozVzJb/VB+gX4Ffl3+6v7R/qX+zwKMAlICagOGA50Dlwe2BmGCQoK2Bd1n6bE4rGrWcLBr8Mrg9hBSSGRIacjzUKtQcWjLXHhu8Nztc5/MM50nnNcUBsJYYdvDnoabhy8NPz0fOz98ftn8FxEOESsiOiIpkUsiayI/RPlGbYl6HG0RLYtui1GJWRhTHfMx1i+2KFYeNytuZdz1eJ14QXxzAi4hJqEiYWSB/4KdC/oWOi/MX3hvkfmi7EVXF+ssTl98donKEvaSE4mYxNjEmsSv7DB2OXskiZW0J2mYw+Ts4rzi+nB3cAd5nrwiXn+yZ3JR8kCKZ8r2lEG+N7+YPyRgCkoFb1KDUvenfkwLS6tMG0uPTa/PwGckZpwSqgvThO2Z+pnZmd0ia1G+SL7UfenOpcPiEHGFBJIskjRLNZABqVNmIftB1pPllVWW9WlZzLIT2WrZwuzOHKucjTn9uQG5vyxHL+csb1thuGLtip6VjJUHVkGrkla1rTZenbe6b03gmqq1xLVpa39dZ7+uaN379bHrW/L08tbk9f4Q+ENtvnK+OP/+Bo8N+39E/yj4sWuj08bdG78XcAuuFdoXFhd+3cTZdO0nh59KfhrbnLy5a4vLln1bsVuFW+9t895WVaRWlFvUu33u9sYdtB0FO97vXLLzavHs4v27iLtku+QloSXNu012b939tZRferfMt6x+j+6ejXs+7uXuvbXPZ1/dfr39hfu//Cz4+cGBwAON5WblxQexB7MOvjgUc6jjF/ov1RU6FYUV3yqFlfKqiKr2atfq6hrdmi21cK2sdvDwwsM3j/gdaa6zrTtQT60vPAqOyo6+PJZ47N7xkONtJ+gn6k6antzTQGkoaIQacxqHm/hN8ub45u5TwafaWjxaGk7bna48Y3im7Kzm2S3niOfyzo2dzz0/0ipqHbqQcqG3bUnb44txF++0z2/vuhRy6crlgMsXOxgd5694Xjlz1f3qqWv0a03XXa43djp3Nvzq/GtDl0tX4w3XG8033W62dM/pPnfL+9aF2363L99h3bl+d97d7nvR9x7cX3hf/oD7YOBh+sM3j7IejT5e8wTzpOCp6tPiZ7rPyn+z/K1e7iI/2+PX0/k88vnjXk7vq98lv3/ty3tBflHcb9BfPeA4cGYwYPDmywUv+16JXo0O5f+h9see1xavT/7p82fncNxw3xvxm7G3m95pv6t8P/t920j4yLMPGR9GPxZ80v5U9Zn+ueNL7Jf+0WVfcV9Lvll+a/ke8v3JWMbYmIgtZk+MAihkwcnJALytBIAcDwAFmSGICybn6gmBJv8FJgj8J56cvSfEBYA6RI2PR8xWAI4iy2wNACo+AIyPRlE+AHZyUqypGXhiXh8XLPLnUufO4L+LemZTDf4pk7P8X+r+pwaKqH/T/wJRFA0eTO16dQAAAIplWElmTU0AKgAAAAgABAEaAAUAAAABAAAAPgEbAAUAAAABAAAARgEoAAMAAAABAAIAAIdpAAQAAAABAAAATgAAAAAAAACQAAAAAQAAAJAAAAABAAOShgAHAAAAEgAAAHigAgAEAAAAAQAAAa6gAwAEAAAAAQAAAH4AAAAAQVNDSUkAAABTY3JlZW5zaG90KBfV5AAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAdZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IlhNUCBDb3JlIDYuMC4wIj4KICAgPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+MTI2PC9leGlmOlBpeGVsWURpbWVuc2lvbj4KICAgICAgICAgPGV4aWY6UGl4ZWxYRGltZW5zaW9uPjQzMDwvZXhpZjpQaXhlbFhEaW1lbnNpb24+CiAgICAgICAgIDxleGlmOlVzZXJDb21tZW50PlNjcmVlbnNob3Q8L2V4aWY6VXNlckNvbW1lbnQ+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgrXhkB8AAAAHGlET1QAAAACAAAAAAAAAD8AAAAoAAAAPwAAAD8AABEJPIGUpwAAENVJREFUeAHsnAd4FcUahv8ggdBL6B0ELCgdFLEgTa8PvUawXJoVAqFc6R1EkK7yUKSJilQpV4WLgL1RvVKUJr0EBELoJXe+ibt3c87Zwwk5SXaT73+enJ3dnd0z+86c+eaf+TchccqERgIkQAIkQAIuIRBC4XJJTbGYJEACJEACmgCFiw2BBEiABEjAVQQoXK6qLhaWBEiABEiAwsU2QAIkQAIk4CoCFC5XVRcLSwIkQAIkQOFiGyABEiABEnAVAQqXq6qLhSUBEiABEqBwsQ2QAAmQAAm4igCFy1XVxcKSAAmQAAlQuNgGSIAESIAEXEWAwuWq6mJhSYAESIAEKFxsAyRAAiRAAq4iQOFyVXWxsCRAAiRAAhQutgESIAESIAFXEaBwuaq6WFgSIAESIAEKF9sACZAACZCAqwhQuFxVXSwsCZAACZAAhYttgARIgARIwFUEKFyuqi4WlgRIgARIgMLFNkACJEACJOAqAhQuV1UXC0sCJEACJEDhYhsgARIgARJwFQHHCNeVK1cl5kKsXL58Ra5fvyFxrsLIwpIACZCAuwmEqOKHhmaULFnCJGeO7BIWltmxD+QI4ToVfUbOx8Q6FhILRgIkQALpjUCunNmlQP5wRz52qgvXseMn5eKlKxpOntw5JUf2bJIpU6iEhED/aSRAAiRAAilBIC4uTq5duy4XYi/K2XMx+iuzZQ2TIoULpsTXJ+o7UlW4DE8L7mnhgvklc+ZMiSo8M5MACZAACQSfwNWr1+T4yWi9bONEzyvVhAtrWoePntDESxQrTNEKftvjHUmABEjgjglAvA4dOa6vL160kKPWvFJNuAxvC9OD+cLz3DFcXkgCJEACJJA8BE6fOaunDZ3mdaWacB08dFSuqehBelvJ0+B4VxIgARJIKgHD68qklnNKliia1NsF7fpUE669+w7qkPeyZUowECNo1ckbkQAJkEDwCCBgY+/+Q4JQubJ3lwzejZN4p1QTrj1KuGDlHAQjiSx5OQmQAAmkOQJO7KspXGmumfGBSIAESCB4BChcFpZOhGEpHpMkQAIkQAKKgBP7anpcbJokQAIkQAK2BChcFjROhGEpHpMkQAIkQAKKgBP7anpcbJokQAIkQAK2BChcFjROhGEpHpMkQAIkQAKKgBP7anpcbJokQAIkQAK2BChcFjROhGEpHpMkQAIkQAKKgBP7anpcbJokQAIkQAK2BChcFjROhGEpHpMkQAIkQAKKgBP7anpcbJokQAIkQAK2BChcFjROhGEpHpMkQAIkQAKKgBP7anpcbJokQAIkQAK2BChcFjROhIHiXfptmy4ltpd3bI9P74g/lrVCZb2fpUIlvc0X8U+95QcJkAAJpFUCTuyr6XH93dogVGc+mSeX/hapQBshxAxCRhELlBjzkQAJuIkAhctSW06BcaeCZXkUnQxv86LeUsA8yXCfBEjAzQSc0ldbGaZrj+v0wrlyZtE8K48kpyFgFK8kY+QNSIAEHEKAwmWpiNSGkRyiZTwexcsgwS0JkIDbCaR2X+2LX7r0uA4Pikr0WpYveHbHig+fKFkfiA/ksMvD4yRAAiTgBgIULkstpRaM5PS08HipIVq3bt2S/QcOyM6du+SmShctUkTuvae85MyZ00LcO/nrf3/TBys++ID3SRccuXHjhvzw409Spkxp/cwuKHLARQxW3Vy9elXQPmCZM2eWDBkyBFyGpGS8cOGCbpPHT5yUM2fOSI7s2SU8PFweVG0tZ44cSbm1a69NrbpIKrDU6qv9lTtdeVyJES0jWtDqORmh8giT9xV9mNKidV113JMmT5F1X26Qy5cvJ6jnsLAwadOqpTz3XDsJUx2Wp02Z+q4sWbZcH27VorlEdnvdM4vj9zt2fln27tsnISEhMmLYEHn8sUcdX+ZAChjMuonq1Uc2b9mqv3bsmNHy8EM1AynCHefZoQZPn65YKRs2fiXXrl3zug+Es1KlihLZ9TW5u0wZr/Np+UBK10WwWFK4LCRTA8bvLZ60lMB3EoIV3vbF2071eYpgSovWxUuXZOCgIWan5PtpRKpVrSJvvTlKMmXKZGaJi4uTRk1bCEbFsBxqBLx6xTItAGYmhycgWBAuwx57tLaMGjHM2HXtNtC62bFjp5w9d04/Z4X775M8efL4fOaU6izh/U6bPlMWL1nqsxyeB0MzZpROnTpIRNs2kkENPNKDpVRdBJtlavTVt3uGdONxBbKudSdBFRAweGVWz+x20INxfsiwEXpUa9yrXLmygs4bntc3334nR44cNU5Ji+bNpEdkV3MfiaHDR8r6DRv1sbpP1pGhgwfqtFs+bt68KW0i2kv06dO6yL2iukvTJo3dUny/5Qykbnr16Su/bNqk7zNm9Eh5pNbDPu+ZEp0lBlG9er8hO3ftMssAz6pG9Wp6GjdP7txy+MgR2bNnr+zbf0CuX79u5oOXPHL4UHM/LSdSoi6Sgx+Fy0I1JWHcPLddYr6dK6dmx/8HDEsxzOSdiJZ5cQonMEXYqElzLVJ33XWXjB0zSnUS1ROUYv6CD2XW+3P0sfz58smHH8wVTB8aBoFbs3ad3n2qYX3JkiWLcco12+joaPns8zVStmwZqVWrVpoZuQdSN04SrgHK88dgyTCIUXc1UEK787Tz58/Lm2+Nk+9/+FFy5colkye8rcXNM19a3KdwBa9W04XHdWlbT7mhxCsk9G6J/SlOidjeBATdJFoo+KbNW6Rn73/pZ6is1gumTJqQ4HmwgwX5sW9PkMqVK0k95VGFhoZ65eEB9xJwinAtWrxU3nlvmgnyyTpPyOCB/QUDKn+2/NMVUqlixXQjWmBB4fLXIhJ3Ll0IV8zGegmo3PiroUQv+MI8ds+yDWbaDYlvv/te+g8crIuK9Y1p705NdLGPHj0qR48d19cVLVJYihYt6vMeWHP58aef5ZdfNsnJU6ekiIpYfPCBCloQER126NBhOXHypL4W05WYFjJs9+9/SExMjN6FwGKdDd+7ees22b79V71fpnQpqaM6O1+jc+M+dttdu3erdbpYffree+9JEK127Phxc7oUUYf5VETbuXPnZeu2bfovNvailCpVUmrWqKEjMO2+w/N4jFoX3L37d/MwpsMQHOJpWIPCFBqstPqe/Pnze2aRU6ei5c+DB/XxbFmzSoUK9+u0Xd1cvHhREPwAmzHzffljzx6d7tjhRbn/vvt02nofHLB2luPHjdGeOaaRtygOqANEGqJ8Tzz+uBQo4F1GfVObD3j+rVpHmGtt9evVlYH9+yZL5CK8UExt79m7T3E7JdmzZZPCqt3WeeJxVf5SNiVMePgW2rKKQt26bbucVG0W9VaoUEGpUa2aVKtW1Wc9JryDSFJ+D9a68Bcog6nUL9dvkF2qnaGN5MiRXUfN1q/3pO3v1LOcwdxPydmxQMud5oUL04QXlcflaTdjK+qpQ7d5W3gOdMoR7Z43HymqR6Q0b9rE3A8kMWv2HJn/wYc66wvPt5fOHTt4XQbRiVKeHdYmPC08PK8O+vjii7VmdCKCI7DOZpj1h7r4k49k/fqNagF/hnHa3GZXodJ9ekUJRuuJsa6RPcQIG584fpwORDGux7PhGWH9+70hBZVw9B0wyCv6Emsx7Z5tK106dQyo44JwNW3eSrDGBps1Y5qUL1dOp42PKyoEvbEKfkH4M6xJ40bSu2cP47S5fXv8RFm5+t96H+tzWKeD2dUN1pBeea2bzmP3cU/58jJz+nvmaWsdzJj2rho0bJXpM2aZ541ENiUE+H6IT6C27sv1MnzkaJ0dA5YlixcKgi6CbWv/s04mTppiDgQ871/7kUfUGu0ALcKe54z9ffv3S78Bg+XEiRPGoQTbkiVLCNYK8SqJnQXz92AnXBBVrHGePXvWqxgQ2mbqdx7V3X8b8LowiQcoXBaAKQXDmCa0fLWZjLtWUHI1/Mjcd1PCMzijSpXKOvy91sMPBTTitescDQYY4Xbv2TuBd2GcM7ZYMyterKgeBeOYP+Fq2KC+oAOyM3R4H8yfI0UKF7bL4nU8UOHCqBxrKr7Cs42bDhrQTxrUT+iZG+c8t1Yx6Kwi4154rn2CLFjvwbqPYXnz5pXlSz7xEsZWbZ/VI2rkmzDuLamuvDeYXd0kVbgQhGME5Ogv8viAiM95f0bAHsygIcPkq6+/0Xdp3y5CXu7S2eOOSd+F5zFi1Jvmu2h2d8Qa75jRI3xOicOrjezRU3vcdtfjeMECBWTqlIlSqGBBr2zB/j34Ei54k5Hdo0yBhlCFq7bz119/CbxFw9pFtJVXXu5i7Cb7NqX66sQ8SJr3uPwJV8bclSRrZe/1IV8AW4484+twoo4tHRieqPz+MmORe/DQ4Xraw5oPnWQDNWpu2aKZmgYpZD2VIG3XOSITQpv7vNHPDLVH4AY6Z0ynYEpv2/btsnLVaq/v9idcuC/eJ2vf7lntlYVlCdNiMnPWbNMLerphA+0dIW8gFqhwGfdq3OgZqV+3rhQvUVx27dot702brqZLj+nT6KwWLYz3QI38dtvl6j0leAAwTJu+O3Vygqyjx4yVL9asTXBs2jtTzKlAnDhw4E95sWN8R4/XEVYuX2KuC9nVDUb8P6spW9iCjz6W/SpCD4aQ8vJqmhaGez1Us4ZO48MqstjH2lNEm9ZqavAxyZ07l36BG9OOxrQmvJc3Rw1H1tta55deNacr8coFBk3BtK+/+VYwQDO825o1qkt9NbjAtPMJ9WLzps2bBWtsV65c0V+LyEpEKGa0eH2IZuzWvafu/JEJnlVT5QFXq1pVicEtvV786YpVegob5zFwgnhZp66T4/fgKVyYRXn19UjT08JA4Ln27QRTv7GxsbJFTa+PUx46fvew1197Rdq2bqXTyf1B4bIQTikYaVW4DJQYkaIDNsLCjeMYPWOE3V29WIzoLU+z6xyRb+NXX2tRRBrrUuPUi6vw6KwG76VP3/6yVf2gDPMnXBg9DhsySK9JGPmxXbX6M/WDjB88FC9WTEc/Ws/7SydGuHy9EoCReIdOL5kd4/Ili9R/d8jr7yv1udPqP0G0VGs7WO8A51WfLtWCgZMIimnSrKVgShFrgNjCPEfJHy9cZE6bPv1UQ+nfNz7YBnn91Q3Ow+4kOENf5+O1AbShYSNG6fuizKtXLtfp230gstV4vnmzZ0np0qV8XoIX3VesXOXznPVg3z69TXHHdGvzFq1NQdXrZ8or9nznC1Nr/1Lt0JiW9Zw2two31sKmTBrv9XtAfXaLjDIHMZiyRls1LDl+D57ChWArBF3B7F5PwXTnq2qqGGyyKkFbsWyx3+lRo/xJ3aZUX52YcqZ5j8szMMMKJ5vytu5SXlcgFgyPa/jzOaVCydBAvi5ReTCNsXjJMvlcjfKxsG81LLiPHjncax3GX+eIwA8EgMDs1r9wDsEOTVu00h049v0JV+1HaqmR/AhkS2AIOPhHo6b6GEbK69Z8FtBUJy4IVLg8PRprATp1edmc6nxn8kSpWPFB62nb9KtdIwUBGDB0csb6HIQcU6yw7t26yuy58/SL3p6ijDyG6MPDgadjmL+6MfLciXBVrVJFJk0YZ9zC3EJsGzz1jCDYAgbhCuTfMuEldiP4BlOMdv8JA69l4PWM25l1uhYeKzxXWInixWXenFmmR+p5H0QoTpw8VR/GeiPWHWFYz2qr1oIxwMDAafHCj2wDUA78qTzgDvEeMKatl6mpXWPAlxy/B6twIQCjTUQ7PR2IWYkF8+falhOzLBBSGH7Xj9b+f7vRB5Phw4nC9T8AAAD//2tnJ2UAABJJSURBVO2dB3wUxRfHXxRIaKGXgBA6CUERRbEgiihiAYFIE5IYQBARkSK9N0GqAaRKFQOYkFAUewf9C4oKCEiTUAKhh04o/3lzzjKce5tLzF0W7jd8PrezM7O7s98pb96bt8HvmgiUDWHHrr3yqZUrBnv06anf1Hd5f/9ykeRfLsplvp4RPvKYfpqp+PCIQAoLzpmpa925iJvy142/UVz8clq77kfjktKlStH8ubPJ39/fSJszdx4tXLRYnkdGtKEO7aKNvNZto+jAgQPyfPzbY+j++2oZec6RtlHRlJS0TyaPGjGMHqnzsFGke8836ZdfN8rzTh07UJvWrYw8PdLw2cZ07tw5mbRm9QrKmzevnu0y/trrb9AfmzbL/EkTxtG999Q0yvK78TtyqH3/fTRu7FtGnh7pN2CQwWr0yOFU5+GH9GyX8SVLl9G7M2bJ/IZPNaD+fXvLeMyUaRS3PIH8/Pxo+YdLaeas2fTJZ5/LvEXz51JwcFn5rs8934wuX75MuXPnplWJ8ZQrVy7jWVZtowr1fLMvrd+wQZ6OGT2SHnrwAZV1w1Fvg/bRL1FUZNsb8tVJ6zaRdODgQXka+/4CKl26tMpyeXy506u0/a+/ZP5bo0bQww89aFqWWcUvTzTNO3XqFF24eFHmTRg3hu6r5ehrkybHUMKKlTK96fONqfsbr5tez4ncV7nPcmDuX3y2hnLmyEFff/MtDRk2QqaXCw6mhfPfk3FXP+HNW9GRo0dl9sRxY6lWrXtl3BPj4e0xo+mB2vfL+3/z7Xc0eOhwGc+fPz+VL+d6Tkw5cpQOHToky776Skdq1bKFjHvyx1tzdUbewe9WF1znfutBl0/+bsrkVhNc+kt+9/0PNHT4SDk5cvprr3amFs3DjSJWk2ODhs8ak8nqlQkUKAaTqzDqrbH06T8Ts5Xgsppcn2nUhM6cOSMf4QnB1bJFc+rSuZPpKwwYNIS+/2GtzMuI4OJJnid7DoULF6aEuKVy0mzRqg0dOnyYwsKq0fSpMfTD2nXUf+BgWa5jh/bUtk1r+Tx+Lod6jz1Kw4YMknH1Y9U2qkxmBJeVcHkxIor273csVtwVXCwUWDhw4AmUJ9KMhvYdX6EdO3bKy+KXxVKxYsVkXF9QDBk0gOo/Xs/y1k3CW9Dx48dlmdjFC4kXa0s/jKNp786QaY0bPUe9erxheY9hI0bRl199Lcv06d2Lnn26oYx7Yjzogkuvp2UFnTJbt2pBnTtlnLnTbdI9heDSEHkLhpXgylGwBuW5e6JWK9fRrNC44gcWcf2ATOQcOXLEGOhml0+fOYtilyyTWU8+UZ8GDehnFLOaHPVJYN57s6hihQrGdc6Rbt170sbfHAsDK8GlD1Tne3hacL3YqiW90ull58fK88wKLr44un1H2rV7t7zPnFnTyU/844mYg1oNXxTaRKMm4XThwgUKCalKs6ZPo/ETJtHK1R/JckMHD6TH6z0m4+rHqm1UmcwILqs2yIzg0jWawMBAoWEuuUFzVHV1dTx27Dg1a96S2FKQN08eWvORQ8Pi8rpQ7Nm9Gz3fuJGr29CVK1eI+9D58+dlmXhRj2JFi0qNjTU3DsyYWVuFXr370s/rHVosjxUeMxw8PR6WJyTS5Jip8lnVw8Ko1r33yHh6PzVq3HWDlSG98pnN99ZcnZH63fIa18W/F9DFvxeaMtlTuBHVuMt6FaYuHLIoVUUtj5v3prnMzwrBxYOUV4UrVq6iLVv+pBnvTpUTotlDWesaOHiozOIB8e7Ud4xiVpNjx85daNu27bKs1aTBdXlamPmUqcfXBNe8BQtp3nxH3+rQPpoup12m+QsXSW661sJmIDYHsRkrTmgVnbt0pZSUI5QzZ05pJswjJm09WLWNKmcHwcXt37zli3T0mMOMzmbWYUMHSzOdqqfVceLkdyhxxSpZhE2drJWrMG36TFq67EN5+kT9x2nwwP4q619H7qvcZznkECZCNhXeJliv+/En6tvfIayKFGGt2LGI+9cNRMLVq1el8FMm66kxk+muO6vLop4eD2vXraN+AxxaOZsn2UxppwDBpbWGt2C4Elxrbq9Dift3U3j1pvTCnc20mmU+ysLNleCqLva2hok9rv8aeIC1bhtJyckOO3dYtVAhkGLkpOh878UfLKGZs+fI5LqP1KGRw4caRawmR558585bIMtWrVKFYiZPkHsxxsX/RBISV9Ckd6YYyb4muHbv3kMvtXdocndWDxN7V+elBlahQnma/95sg8sXX35Fw0eOludNnm9kTNa8J8TmO+dg1TaqrK4d6GYtla+O+h5XVmtc/AwWPCyAVHjwgdqyn7FQtgpsXmYzMwfej5on9mDLliljXLLhl1+pRy/HvmGBAgWINf+iRcwtFtwHuS9y4OePfWuUjJ8V+6ZNmzU3Flb6vpUsoP3o+0xsGk+IXyYXFlzE0+Mh9fRpaipMnWlpaVJj5b24UkFBWu2uR3lPNyDAn6pUrnw90cMxb83VGXmNW17jYhjODhqTzobRttQTBqfY1o5VspGQyYiVOTGrBBdXzVlgtIuOosiItnKVqarOHbxPvwF09uxZmcSmMjaZqWA1OR5OSaGIqHbSvMXla95dQ05GvHHM4aow7az55FMaN26CjMtE8eNrgovfW9+4VxxeiowgbhMVeAJtLJwx0oQzhh769XmTnm74lJ4k41ZtowqPeXs8fbzmE3n62KN1abjQdDiwFnT77bfLOP94WnDxM1gos3BWgbWG7t26Upk77lBJxvHEiRNC0MXQt999b6Q5OwdxBpsP20ZG0779+2W5smXL0JTJE6lQoULGdRzRnXD4nIUWCy8Vxk2YSKtWfyxP2RGGnY14kaEHFpKsmV26dEkmO+/XeWM8jBw9hj77/Av5/JCqVWQ92fyqh81btghh3keOywdq1xZaaD/Kly+fXsQjcQguDas3YSita1euarT6fBD9mbJVqwllida1RZgIB1uYE7PSo5AHWLcevaSpUL1I+fLl6J6ad9PVK1dp7Y8/SlOUyitYsADFLl4k9xFUWnqTIw/mPn37G5PtbbfdJlZ5laio2Dv4/Y9NdFqsEjlwOmuBHHxRcOn7iBKC+Hlv9kyqXKmiOpXH3oLlT//72Uhj4bIiIc7U8SW9tuGbfBgXT1OmTTfux16AVatUpoPJyXIfTWV4Q3Dx/l0fMfFvFB6temABUUHsjxYWwiZZ1Gv3nr/p7717DQHBZe+pWVMIm5E3eLyqe7ADTNfXuxumSNa87hNC8W6xt5MsPOt+EX1023aHVyNf83KHdhTR5kV1uTzyHiOzV/uw7L3JCzHeR7oi+i3389/FHq1aVEiNUXjHshaoB0+PB17ccFspEz0LrfCmTaiyGHPHhCl2/YZf5P4bs+YQHRVJ0S9F6lX0WNybc7W7L+ETGhcLrsR9u6Vp0BWY/2IyTE9o8TOzYn9LrztrUt2696K/duzQk/8Vr1SxIo0YPkR6WemZ7kyOvCrmTXIlmPTrOc5mL3ZIUG7Lvii4tvy5Ve5ZKTZBQSVp6Qfvq1PjuPqjj+nt8dcdgdh1n134zYI7bcMTWFS7DobJWN2nePFiFLc0Vp16RePih3EfmTt/AS16/wOpLRkVcBFhAdLp5fb0QngzUzO3uixp3z7q2q0HsaZmFdjNn939zQKzYtMqWyGsAmuKY8U+myszp6fHAy8GeUzv3LXLqprU/IVw6tqls2WZrMyE4NJoehvGiC9H/0vT0qojo5kRXu4IrZZ181CLurmdH/efz3k1mSi+dVkcu4ROnjx1w/3YLPJE/Xr0+mtdTFez7kyOfENeqcYuWSpXt7wq5fuyKYO9tNjTSzfFOO+huLvav1m9CpkPm7T4+x/loMCfHPCnB86B26dJsxcM02qPN7pJwe9cjs/dbRvWSCaL/R32hON6cKgWGiocdq7vO7rbBpnxKpQPdPrhfb/ElSuF2etL49s8vQg7SYRUDaFOHdsTf1vlTti7N4mmTZ9BP/+83uCnrmNB3Up87sAC0Cqw0wXf43NRL+VMpMpzn27Y4EnqLD6ZCNC+dVT5+tHT44H7yTtTpkpTKn/np4dCBQtSeHhTqVWyo4+3grfnanfeyyc0LgbB5kEWXu4EdwQY3y9+UwJdPV+J/vitvuVts1rbcn4YCzA2wfCHwLzyDalalcqIPQH2rMqqwPtaJ8Wqt6AYPGweVIFNlspENHfOTGIND8G7BFijOHgwmXgS98aehztvx8IhKSlJfCx7WGpLbMrkvsFm68wG9sRkbYSP+fLlpaCSJSk0NOSG/pjevdlSsXXbdjosvrUTqh6VLFGCQsVnCs6enendx9Pj4cTJk7RdmEFTxH5zQECAo57CEcvZhJlePbMiH4JLo5gdMOI2Laf4zQlaLVxHqxUPpdDiIbJAtRKhRsE/D2+lrSnbbtDeggNDaMdGx/c7RsF/Ip7Stpyfk9XnvI/Gbvc8gHSnDv05vDps3SaC2D7PA2rViuUZngD0+yEOAnYl4MvjITvm6vT6gc9oXAqEOyZDVTajxyJXn6HkPQ2My7LSk9C4qRci/JcMugtX5NRUx7dr+seY6vFsxmB3ZvWXBh6t+wiNGDZEZeMIArcMAV8fDxBcWlfOThieFF4h+RtJ0+HNKrS4idjcGN2hI+0RXmAcWJu6X/y9vwfFR6Ls4swmoBUrVxubyGz+iRGuyu7uWcib4gcEbhICvj4esnOudtVFfE7jUiAyYjZU17h7jAjrTcEFQjz6B3XdrUtmy/HGf0/xzQi7V1sF3jCePGk8lS9XzqoY8kDgpibgy+MBgkvrunaA4QnhxXtjg+q7/vM0GgLbR9kFea74k0affPoZsQOIc+Cv9wcO6AtNyxkMzm9JAr46HuwwVzt3KJ/VuBQIFl4c3HXaUNeZHd3xRjS7zu5p/F9P8Iee/N8p8J81Klq0iPwwEqZBu7cc6ucJAr42HiC4tF5kRxiZ0cCU92FW/b1DDRGiIAACIJDtBOw4V/u8xmXWK5QWxnm66zsLKRXC72wqo3qaysMRBEAABG4VAhBcWkvaEYZWPURBAARAAAQEATvO1dC40DVBAARAAARcEoDg0tDYEYZWPURBAARAAAQEATvO1dC40DVBAARAAARcEoDg0tDYEYZWPURBAARAAAQEATvO1dC40DVBAARAAARcEoDg0tDYEYZWPURBAARAAAQEATvO1dC40DVBAARAAARcEoDg0tDYEYZWPURBAARAAAQEATvO1dC40DVBAARAAARcEoDg0tDYEYZWPURBAARAAAQEATvO1dC40DVBAARAAARcEoDg0tDYEYZWPURBAARAAAQEATvO1dC40DVBAARAAARcEoDg0tDs3LWXronzShXKkp+fn5aDKAiAAAiAgB0IXLt2jXbuTiKeoStVDLZDlWQdsk3j2pt0gC6lXaaydwSRv38u2wBBRUAABEAABBwELl68REn7kylXzhwUXLa0bbBkm+BKOXKMTqWeoUIFA6lokUK2AYKKgAAIgAAIOAgcPXaCTpxMpQKB+ah4sSK2wZJtguvChYu078AhCQJal236AyoCAiAAApKA0rb4pEzpkhQQ4G8bMtkmuJiA0rpyCjU0qEQxmAxt0y1QERAAAV8mwEIr+fARShPbOXbTtrhdslVwcQUOJh+ms+cucFSaDfPny0u5cuWEw4Ykgh8QAAEQ8A4BdsS4dCmNTp85K82D/NS8eQKoVFAJ71QgA0/JdsHFdVWaVwbqjaIgAAIgAAIeJGBHTUu9ri0EF1eG97xST5+h8+cvSPWUXeURQAAEQAAEvEOAXd552yZ37gAKzJ/PVntazgRsI7icK4ZzEAABEAABEDAjAMFlRgVpIAACIAACtiUAwWXbpkHFQAAEQAAEzAhAcJlRQRoIgAAIgIBtCUBw2bZpUDEQAAEQAAEzAhBcZlSQBgIgAAIgYFsCEFy2bRpUDARAAARAwIwABJcZFaSBAAiAAAjYlgAEl22bBhUDARAAARAwIwDBZUYFaSAAAiAAArYlAMFl26ZBxUAABEAABMwIQHCZUUEaCIAACICAbQlAcNm2aVAxEAABEAABMwIQXGZUkAYCIAACIGBbAhBctm0aVAwEQAAEQMCMAASXGRWkgQAIgAAI2JYABJdtmwYVAwEQAAEQMCMAwWVGBWkgAAIgAAK2JQDBZdumQcVAAARAAATMCEBwmVFBGgiAAAiAgG0JQHDZtmlQMRAAARAAATMCEFxmVJAGAiAAAiBgWwIQXLZtGlQMBEAABEDAjMD/AQlGmZU+qyz9AAAAAElFTkSuQmCC\"/>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/sparkr_logo.svg":
/*!*************************************!*\
  !*** ./style/icons/sparkr_logo.svg ***!
  \*************************************/
/***/ ((module) => {

module.exports = "<svg width=\"52\" height=\"52\" viewBox=\"0 0 52 52\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_3526_17649)\">\n<rect width=\"52\" height=\"52\" fill=\"white\"/>\n<g clip-path=\"url(#clip1_3526_17649)\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M43.3194 39.9948C43.2831 39.9173 43.2667 39.8783 43.2472 39.8411C42.7223 38.8428 42.1988 37.8445 41.6685 36.8462C41.6154 36.7461 41.6221 36.687 41.6948 36.6007C42.53 35.6253 43.3544 34.6446 44.191 33.6733C44.2205 33.639 44.2469 33.6027 44.2579 33.5416C44.0151 33.6049 43.7722 33.6675 43.528 33.7318C42.5201 33.9989 41.5041 34.2647 40.5056 34.5358C40.4118 34.5611 40.3693 34.5337 40.3221 34.4557C39.75 33.4992 39.1739 32.5401 38.595 31.5958C38.5655 31.5462 38.5332 31.4982 38.4701 31.4568C38.4237 31.7118 38.3767 31.9654 38.3311 32.2204C38.1705 33.1202 38.01 34.0146 37.8508 34.9184C37.8333 35.0154 37.8096 35.1127 37.8012 35.2098C37.7933 35.3026 37.7454 35.3369 37.6609 35.3636C36.4722 35.7373 35.2862 36.1137 34.0988 36.4901C34.0467 36.5064 33.9956 36.528 33.9396 36.5785C34.9111 36.9644 35.8826 37.3502 36.8675 37.7428C36.8316 37.7712 36.8079 37.7934 36.7816 37.8102C36.1744 38.2028 35.5659 38.5954 34.9601 38.9893C34.8873 39.0368 34.8299 39.0435 34.7482 39.0067C34.0223 38.6802 33.291 38.3591 32.5624 38.0354C32.2359 37.8897 31.9431 37.6968 31.7151 37.4162C31.1983 36.7848 31.3008 36.0671 31.989 35.6219C32.2143 35.4776 32.4707 35.371 32.7257 35.2874C33.8901 34.9083 35.0599 34.5427 36.2203 34.1758C36.3182 34.1446 36.3633 34.1009 36.3822 33.995C36.5387 33.0939 36.6993 32.1873 36.8625 31.2969C36.9494 30.8153 36.9953 30.3229 37.2295 29.8805C37.3193 29.7105 37.4265 29.5445 37.5561 29.4029C38.0202 28.8876 38.6665 28.8687 39.1617 29.3587C39.3277 29.5246 39.4693 29.7188 39.5921 29.9199C40.1318 30.8008 40.6635 31.6871 41.1978 32.5774C41.2605 32.6823 41.3169 32.7033 41.4325 32.6728C42.7346 32.3234 44.0366 31.9794 45.3454 31.6354C45.6153 31.5643 45.8865 31.5386 46.1631 31.5902C46.7635 31.7025 47.0266 32.1595 46.8229 32.741C46.7307 33.0054 46.5706 33.228 46.3911 33.4398C45.4817 34.5095 44.5696 35.5847 43.6656 36.6505C43.5912 36.7379 43.5898 36.8002 43.6413 36.8987C44.1864 37.9253 44.7261 38.9492 45.2739 39.988C45.4036 40.2335 45.5033 40.4898 45.506 40.7717C45.5123 41.4139 45.0419 41.94 44.4036 42.0344C44.0461 42.0867 43.7142 42.0103 43.3782 41.907C42.5619 41.6547 41.7456 41.4065 40.9225 41.1596C40.8465 41.1369 40.8175 41.1068 40.8039 41.0252C40.71 40.4492 40.6069 39.8745 40.5071 39.2985C40.5045 39.2827 40.5092 39.2658 40.5119 39.2305C41.4443 39.4881 42.3739 39.7418 43.3319 40.0075\" fill=\"#E25A1C\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M41.7003 48.4264C40.9636 48.4253 40.2295 48.4217 39.4874 48.4249C39.3899 48.4249 39.335 48.397 39.281 48.3141C38.4094 46.9867 37.5269 45.6565 36.6634 44.3345C36.6355 44.2924 36.6059 44.2518 36.5564 44.1807C36.3689 45.6107 36.184 47.0137 35.9992 48.4167H34.0697C34.0924 48.2292 34.1125 48.047 34.1362 47.8663C34.3238 46.4228 34.514 44.9928 34.7029 43.5494C34.8837 42.1733 35.0632 40.7973 35.2467 39.4213C35.2519 39.3807 35.2793 39.3285 35.3125 39.3069C35.9764 38.8739 36.6429 38.4449 37.3094 38.0159C37.319 38.0095 37.3327 38.009 37.3669 37.999C37.1659 39.5369 36.9662 41.0613 36.7651 42.5857C36.7731 42.591 36.7809 42.5968 36.7889 42.6021C37.8346 41.4446 38.8803 40.2817 39.9462 39.1081C39.9768 39.2861 40.0037 39.4386 40.03 39.591C40.1049 40.0268 40.1771 40.4652 40.2567 40.9009C40.273 40.9889 40.2492 41.0426 40.1908 41.1046C39.5148 41.8115 38.8415 42.5211 38.1669 43.2361C38.1374 43.2673 38.1094 43.2994 38.0757 43.3363C38.0973 43.3705 38.1158 43.4038 38.1374 43.4343C39.2991 45.0666 40.4581 46.6989 41.6185 48.3313C41.6395 48.3608 41.67 48.384 41.6959 48.4103V48.4361\" fill=\"#3C3A3E\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M18.8976 44.1093C18.868 43.9596 18.847 43.7383 18.78 43.5319C18.4562 42.535 17.4348 41.994 16.3783 42.2355C15.2166 42.5053 14.3814 43.4186 14.2735 44.6098C14.1844 45.4867 14.6566 46.3366 15.5337 46.6468C16.2407 46.9018 16.9234 46.7952 17.5576 46.4162C18.3955 45.9143 18.8488 45.1683 18.9069 44.1093H18.8976ZM13.7973 47.8192C13.7404 48.2481 13.6856 48.6515 13.6327 49.0562C13.5621 49.5931 13.491 50.1314 13.4235 50.6751C13.4157 50.7378 13.3967 50.7657 13.3292 50.7652C12.799 50.7631 12.2687 50.7637 11.7371 50.7626C11.7249 50.7626 11.7128 50.7563 11.6843 50.7479C11.7164 50.4943 11.7476 50.2393 11.7808 49.9857C11.8978 49.0953 12.0142 48.205 12.133 47.3146C12.2692 46.2947 12.3758 45.2776 12.5499 44.2658C12.8575 42.4716 14.3849 40.9337 16.1659 40.5425C17.2008 40.3185 18.1899 40.4223 19.0939 41.0052C19.9952 41.5853 20.5106 42.4352 20.632 43.4874C20.7994 44.9848 20.2475 46.2259 19.1883 47.2647C18.4894 47.9406 17.6501 48.3696 16.6922 48.5153C15.6977 48.665 14.7627 48.4995 13.9261 47.9136C13.8955 47.892 13.8623 47.8731 13.8097 47.8399\" fill=\"#3C3A3E\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M12.9065 39.3201C12.3128 39.7626 11.7394 40.1889 11.1659 40.6165C11.0732 40.4708 10.9905 40.3252 10.8934 40.1889C10.6438 39.8395 10.3334 39.5791 9.88278 39.5481C9.50768 39.5217 9.18656 39.645 8.93154 39.9218C8.70352 40.1687 8.67383 40.5208 8.88675 40.8C9.12152 41.1076 9.37788 41.399 9.64099 41.6836C10.0768 42.1558 10.5315 42.6091 10.9633 43.0866C11.3559 43.5183 11.6703 44.0013 11.7675 44.5975C11.8829 45.299 11.7428 45.9601 11.4112 46.5806C10.7973 47.7206 9.83259 48.3883 8.55078 48.5907C7.98678 48.6817 7.42548 48.6639 6.87768 48.502C6.14772 48.2876 5.63904 47.8086 5.31252 47.1395C5.19715 46.9007 5.10878 46.6485 5.00488 46.3922C5.64309 46.0509 6.26511 45.7176 6.89387 45.3817C6.91546 45.4339 6.93124 45.4777 6.95135 45.5193C7.05888 45.7338 7.14699 45.9618 7.27922 46.1601C7.67456 46.747 8.31142 46.925 8.95232 46.635C9.11828 46.5601 9.27885 46.4556 9.41512 46.3342C9.8307 45.9645 9.90896 45.4492 9.60132 44.9851C9.42457 44.718 9.20329 44.4779 8.9874 44.2391C8.47198 43.6671 7.93497 43.1127 7.43574 42.5258C7.08897 42.1238 6.85285 41.6571 6.77729 41.1228C6.69566 40.5347 6.81318 39.9816 7.11866 39.4905C7.8783 38.2615 8.98066 37.6288 10.4379 37.6693C11.2704 37.6994 11.9356 38.0889 12.4483 38.7364C12.6008 38.928 12.7438 39.1263 12.899 39.334\" fill=\"#3C3A3E\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M26.9932 45.8631C26.8962 46.6037 26.8043 47.3066 26.7098 48.0081C26.7046 48.0439 26.6766 48.0924 26.6466 48.1061C25.2028 48.7726 23.3138 48.6795 22.14 47.3385C21.5058 46.6181 21.24 45.7602 21.2791 44.8158C21.3713 42.6169 23.1951 40.6878 25.3809 40.418C26.656 40.2615 27.7692 40.6055 28.6327 41.597C29.221 42.2716 29.4935 43.081 29.4531 43.9713C29.4267 44.5595 29.3344 45.1437 29.2615 45.7251C29.1576 46.5534 29.0442 47.3844 28.9349 48.2073C28.9307 48.2362 28.9249 48.2657 28.9181 48.3032H27.2045C27.2271 48.113 27.2482 47.9268 27.2725 47.7407C27.3969 46.7842 27.5342 45.8251 27.6435 44.8672C27.7115 44.271 27.6688 43.6787 27.3953 43.127C27.1052 42.5402 26.6194 42.2285 25.9785 42.1611C24.6535 42.0208 23.3879 42.9408 23.1181 44.2386C22.9319 45.0993 23.2256 45.9249 23.9114 46.3836C24.5793 46.8274 25.2877 46.8287 26.0163 46.5414C26.386 46.3957 26.699 46.1637 26.9986 45.852\" fill=\"#3C3A3E\"/>\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M34.2793 40.6421C34.2007 41.2384 34.1228 41.8252 34.0445 42.4228C33.6802 42.4228 33.324 42.4208 32.9678 42.4234C32.679 42.4255 32.4159 42.6122 32.3282 42.882C32.2945 42.9874 32.2819 43.1006 32.2671 43.2112C32.0863 44.5872 31.9068 45.9497 31.7274 47.3123C31.6821 47.6576 31.6383 48.003 31.593 48.3537H29.7985C29.8317 48.0907 29.8632 47.8357 29.8964 47.5807C30.0129 46.6931 30.1298 45.8 30.2472 44.9231C30.349 44.1555 30.4402 43.3852 30.5603 42.6163C30.7208 41.591 31.7409 40.6737 32.7731 40.6332C33.2669 40.6116 33.7621 40.6296 34.2708 40.6296\" fill=\"#3C3A3E\"/>\n<path d=\"M43.8591 48.4262V47.6707H43.8549L43.5581 48.4262H43.4638L43.1669 47.6707H43.1622V48.4262H43.0138V47.521H43.2445L43.5144 48.209L43.7802 47.521H44.0096V48.4262H43.8591ZM42.5449 47.6424V48.4262H42.3965V47.6424H42.1132V47.5211H42.8296V47.6424H42.5463\" fill=\"#3C3A3E\"/>\n<path d=\"M15.295 38.0521H15.7389L15.634 37.3803L15.295 38.0521ZM15.8091 38.4865H15.071L14.8363 38.9465H14.3127L15.4664 36.7881H15.971L16.3636 38.9465H15.8793L15.8096 38.4865\" fill=\"#3C3A3E\"/>\n<path d=\"M18.4523 37.2295H18.1892L18.1007 37.7272H18.3638C18.523 37.7272 18.6485 37.623 18.6485 37.4264C18.6485 37.2962 18.5694 37.2295 18.4515 37.2295H18.4523ZM17.8154 36.7951H18.5063C18.8679 36.7951 19.1202 37.0109 19.1202 37.3805C19.1202 37.8473 18.791 38.1603 18.3214 38.1603H18.0232L17.8829 38.9495H17.4323L17.8127 36.791\" fill=\"#3C3A3E\"/>\n<path d=\"M20.6516 38.0521H21.0955L20.9907 37.3803L20.6516 38.0521ZM21.1643 38.4865H20.4263L20.1915 38.9465H19.668L20.8216 36.7881H21.3262L21.7189 38.9465H21.2345L21.1649 38.4865\" fill=\"#3C3A3E\"/>\n<path d=\"M24.0248 38.8751C23.8723 38.9447 23.705 38.9863 23.5363 38.9863C22.9656 38.9863 22.608 38.5586 22.608 38.0231C22.608 37.3378 23.1842 36.7617 23.8696 36.7617C24.041 36.7617 24.1961 36.8029 24.323 36.8723L24.2597 37.389C24.1648 37.2842 24.0114 37.2109 23.8225 37.2109C23.4299 37.2109 23.0804 37.5657 23.0804 37.9772C23.0804 38.2902 23.2774 38.5357 23.5877 38.5357C23.778 38.5357 23.9615 38.4624 24.0856 38.3617L24.0256 38.8743\" fill=\"#3C3A3E\"/>\n<path d=\"M26.8582 38.0791H25.9205L25.768 38.9465H25.3187L25.6992 36.7881H26.1499L25.9988 37.6407H26.9365L27.089 36.7881H27.5396L27.1591 38.9465H26.7085L26.8596 38.0791\" fill=\"#3C3A3E\"/>\n<path d=\"M28.4774 38.9426L28.8579 36.7842H30.0534L29.9774 37.2186H29.2326L29.1566 37.6368H29.8407L29.7648 38.0712H29.0807L29.0047 38.5055H29.7495L29.6736 38.9399H28.4781\" fill=\"#3C3A3E\"/>\n</g>\n<rect x=\"-28\" y=\"-3\" width=\"107\" height=\"21\" fill=\"#F4F6FB\"/>\n<path d=\"M24.9558 8.33582H25.5295C26.0918 8.33582 26.5068 8.24211 26.7745 8.05469C27.0423 7.86727 27.1761 7.57275 27.1761 7.17114C27.1761 6.77336 27.0385 6.49032 26.7631 6.32202C26.4915 6.15373 26.0688 6.06958 25.4951 6.06958H24.9558V8.33582ZM24.9558 9.78162V13.0002H23.1772V4.6123H25.6213C26.7611 4.6123 27.6045 4.82076 28.1515 5.23767C28.6984 5.65076 28.9719 6.27995 28.9719 7.12524C28.9719 7.61865 28.8361 8.05851 28.5646 8.44482C28.293 8.82731 27.9086 9.12756 27.4114 9.34558C28.6736 11.2312 29.4959 12.4495 29.8784 13.0002H27.9048L25.9025 9.78162H24.9558Z\" fill=\"black\"/>\n<path d=\"M25.065 25.4977C25.065 26.0682 25.0104 26.5721 24.901 27.0093C24.7948 27.4434 24.6338 27.8093 24.4182 28.107C24.2057 28.4016 23.9415 28.6248 23.6257 28.7767C23.3129 28.9256 22.95 29 22.5371 29C22.1271 29 21.7643 28.924 21.4484 28.7721C21.1326 28.6202 20.8669 28.3969 20.6513 28.1023C20.4357 27.8047 20.2733 27.4372 20.164 27C20.0547 26.5628 20 26.0589 20 25.4884C20 24.7318 20.0957 24.0946 20.287 23.5767C20.4813 23.0589 20.7667 22.6667 21.1433 22.4C21.5228 22.1333 21.9874 22 22.5371 22C23.0897 22 23.5528 22.1318 23.9263 22.3953C24.3028 22.6589 24.5867 23.0512 24.7781 23.5721C24.9694 24.0899 25.065 24.7318 25.065 25.4977ZM21.6489 25.4977C21.6489 25.9597 21.6823 26.3457 21.7491 26.6558C21.8159 26.9659 21.9146 27.1984 22.0451 27.3535C22.1787 27.5054 22.3427 27.5814 22.5371 27.5814C22.7375 27.5814 22.9014 27.507 23.029 27.3581C23.1596 27.2093 23.2552 26.9814 23.3159 26.6744C23.3797 26.3643 23.4116 25.9721 23.4116 25.4977C23.4116 24.7783 23.3387 24.2481 23.193 23.907C23.0502 23.5628 22.8316 23.3907 22.5371 23.3907C22.3427 23.3907 22.1787 23.4698 22.0451 23.6279C21.9146 23.7829 21.8159 24.0171 21.7491 24.3302C21.6823 24.6403 21.6489 25.0295 21.6489 25.4977Z\" fill=\"#3C3A3E\"/>\n<path d=\"M31 28.907H29.1507L27.4153 24.6791H27.3789C27.3971 24.9271 27.4108 25.1581 27.4199 25.3721C27.432 25.5829 27.4396 25.7752 27.4427 25.9488C27.4487 26.1194 27.4518 26.2698 27.4518 26.4V28.907H25.9805V22.107H27.8161L29.5424 26.2186H29.5789C29.5667 25.9891 29.5561 25.7752 29.547 25.5767C29.5379 25.3783 29.5303 25.1953 29.5242 25.0279C29.5182 24.8605 29.5151 24.7085 29.5151 24.5721V22.107H31V28.907Z\" fill=\"#3C3A3E\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_3526_17649\">\n<rect width=\"52\" height=\"52\" fill=\"white\"/>\n</clipPath>\n<clipPath id=\"clip1_3526_17649\">\n<rect width=\"42\" height=\"21.8077\" fill=\"white\" transform=\"translate(5 29)\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/start_cluster_icon.svg":
/*!********************************************!*\
  !*** ./style/icons/start_cluster_icon.svg ***!
  \********************************************/
/***/ ((module) => {

module.exports = "<svg width=\"11\" height=\"12\" viewBox=\"0 0 11 12\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M0 0L11 6L0 12V0Z\" fill=\"#3367D6\"/>\n</svg>\n";

/***/ }),

/***/ "./style/icons/start_cluster_icon_disable.svg":
/*!****************************************************!*\
  !*** ./style/icons/start_cluster_icon_disable.svg ***!
  \****************************************************/
/***/ ((module) => {

module.exports = "<svg width=\"11\" height=\"12\" viewBox=\"0 0 11 12\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M0 0L11 6L0 12V0Z\" fill=\"#8A8A8A\"/>\n</svg>\n\n";

/***/ }),

/***/ "./style/icons/start_icon.svg":
/*!************************************!*\
  !*** ./style/icons/start_icon.svg ***!
  \************************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_1227_2375)\">\n<path d=\"M7 12.5L12.5 9L7 5.5V12.5ZM9 17C7.90278 17 6.86806 16.7917 5.89583 16.375C4.92361 15.9583 4.06944 15.3889 3.33333 14.6667C2.61111 13.9306 2.04167 13.0764 1.625 12.1042C1.20833 11.1319 1 10.0972 1 9C1 7.88889 1.20833 6.85417 1.625 5.89583C2.04167 4.92361 2.61111 4.07639 3.33333 3.35417C4.06944 2.61805 4.92361 2.04167 5.89583 1.625C6.86806 1.20833 7.90278 0.999999 9 0.999999C10.1111 0.999999 11.1458 1.20833 12.1042 1.625C13.0764 2.04167 13.9236 2.61805 14.6458 3.35417C15.3819 4.07639 15.9583 4.92361 16.375 5.89583C16.7917 6.85417 17 7.88889 17 9C17 10.0972 16.7917 11.1319 16.375 12.1042C15.9583 13.0764 15.3819 13.9306 14.6458 14.6667C13.9236 15.3889 13.0764 15.9583 12.1042 16.375C11.1458 16.7917 10.1111 17 9 17ZM9 15.5C10.8056 15.5 12.3403 14.8681 13.6042 13.6042C14.8681 12.3403 15.5 10.8056 15.5 9C15.5 7.19444 14.8681 5.65972 13.6042 4.39583C12.3403 3.13194 10.8056 2.5 9 2.5C7.19444 2.5 5.65972 3.13194 4.39583 4.39583C3.13194 5.65972 2.5 7.19444 2.5 9C2.5 10.8056 3.13194 12.3403 4.39583 13.6042C5.65972 14.8681 7.19444 15.5 9 15.5Z\" fill=\"#444746\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_1227_2375\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/start_icon_disable.svg":
/*!********************************************!*\
  !*** ./style/icons/start_icon_disable.svg ***!
  \********************************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_1227_2375)\">\n<path d=\"M7 12.5L12.5 9L7 5.5V12.5ZM9 17C7.90278 17 6.86806 16.7917 5.89583 16.375C4.92361 15.9583 4.06944 15.3889 3.33333 14.6667C2.61111 13.9306 2.04167 13.0764 1.625 12.1042C1.20833 11.1319 1 10.0972 1 9C1 7.88889 1.20833 6.85417 1.625 5.89583C2.04167 4.92361 2.61111 4.07639 3.33333 3.35417C4.06944 2.61805 4.92361 2.04167 5.89583 1.625C6.86806 1.20833 7.90278 0.999999 9 0.999999C10.1111 0.999999 11.1458 1.20833 12.1042 1.625C13.0764 2.04167 13.9236 2.61805 14.6458 3.35417C15.3819 4.07639 15.9583 4.92361 16.375 5.89583C16.7917 6.85417 17 7.88889 17 9C17 10.0972 16.7917 11.1319 16.375 12.1042C15.9583 13.0764 15.3819 13.9306 14.6458 14.6667C13.9236 15.3889 13.0764 15.9583 12.1042 16.375C11.1458 16.7917 10.1111 17 9 17ZM9 15.5C10.8056 15.5 12.3403 14.8681 13.6042 13.6042C14.8681 12.3403 15.5 10.8056 15.5 9C15.5 7.19444 14.8681 5.65972 13.6042 4.39583C12.3403 3.13194 10.8056 2.5 9 2.5C7.19444 2.5 5.65972 3.13194 4.39583 4.39583C3.13194 5.65972 2.5 7.19444 2.5 9C2.5 10.8056 3.13194 12.3403 4.39583 13.6042C5.65972 14.8681 7.19444 15.5 9 15.5Z\" fill=\"#8A8A8A\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_1227_2375\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/stop_cluster_disable_icon.svg":
/*!***************************************************!*\
  !*** ./style/icons/stop_cluster_disable_icon.svg ***!
  \***************************************************/
/***/ ((module) => {

module.exports = "<svg width=\"10\" height=\"10\" viewBox=\"0 0 10 10\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<rect width=\"10\" height=\"10\" fill=\"#8A8A8A\"/>\n</svg>\n";

/***/ }),

/***/ "./style/icons/stop_cluster_icon.svg":
/*!*******************************************!*\
  !*** ./style/icons/stop_cluster_icon.svg ***!
  \*******************************************/
/***/ ((module) => {

module.exports = "<svg width=\"10\" height=\"10\" viewBox=\"0 0 10 10\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<rect width=\"10\" height=\"10\" fill=\"#3367D6\"/>\n</svg>\n";

/***/ }),

/***/ "./style/icons/stop_disable_icon.svg":
/*!*******************************************!*\
  !*** ./style/icons/stop_disable_icon.svg ***!
  \*******************************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_1227_2376)\">\n<path d=\"M6 12H12V6H6V12ZM9 17C7.90278 17 6.86806 16.7917 5.89583 16.375C4.92361 15.9583 4.06944 15.3889 3.33333 14.6667C2.61111 13.9306 2.04167 13.0764 1.625 12.1042C1.20833 11.1319 1 10.0972 1 9C1 7.88889 1.20833 6.85417 1.625 5.89583C2.04167 4.92361 2.61111 4.07639 3.33333 3.35417C4.06944 2.61805 4.92361 2.04167 5.89583 1.625C6.86806 1.20833 7.90278 0.999999 9 0.999999C10.1111 0.999999 11.1458 1.20833 12.1042 1.625C13.0764 2.04167 13.9236 2.61805 14.6458 3.35417C15.3819 4.07639 15.9583 4.92361 16.375 5.89583C16.7917 6.85417 17 7.88889 17 9C17 10.0972 16.7917 11.1319 16.375 12.1042C15.9583 13.0764 15.3819 13.9306 14.6458 14.6667C13.9236 15.3889 13.0764 15.9583 12.1042 16.375C11.1458 16.7917 10.1111 17 9 17ZM9 15.5C10.8056 15.5 12.3403 14.8681 13.6042 13.6042C14.8681 12.3403 15.5 10.8056 15.5 9C15.5 7.19444 14.8681 5.65972 13.6042 4.39583C12.3403 3.13194 10.8056 2.5 9 2.5C7.19444 2.5 5.65972 3.13194 4.39583 4.39583C3.13194 5.65972 2.5 7.19444 2.5 9C2.5 10.8056 3.13194 12.3403 4.39583 13.6042C5.65972 14.8681 7.19444 15.5 9 15.5Z\" fill=\"#8A8A8A\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_1227_2376\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/stop_icon.svg":
/*!***********************************!*\
  !*** ./style/icons/stop_icon.svg ***!
  \***********************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_1227_2376)\">\n<path d=\"M6 12H12V6H6V12ZM9 17C7.90278 17 6.86806 16.7917 5.89583 16.375C4.92361 15.9583 4.06944 15.3889 3.33333 14.6667C2.61111 13.9306 2.04167 13.0764 1.625 12.1042C1.20833 11.1319 1 10.0972 1 9C1 7.88889 1.20833 6.85417 1.625 5.89583C2.04167 4.92361 2.61111 4.07639 3.33333 3.35417C4.06944 2.61805 4.92361 2.04167 5.89583 1.625C6.86806 1.20833 7.90278 0.999999 9 0.999999C10.1111 0.999999 11.1458 1.20833 12.1042 1.625C13.0764 2.04167 13.9236 2.61805 14.6458 3.35417C15.3819 4.07639 15.9583 4.92361 16.375 5.89583C16.7917 6.85417 17 7.88889 17 9C17 10.0972 16.7917 11.1319 16.375 12.1042C15.9583 13.0764 15.3819 13.9306 14.6458 14.6667C13.9236 15.3889 13.0764 15.9583 12.1042 16.375C11.1458 16.7917 10.1111 17 9 17ZM9 15.5C10.8056 15.5 12.3403 14.8681 13.6042 13.6042C14.8681 12.3403 15.5 10.8056 15.5 9C15.5 7.19444 14.8681 5.65972 13.6042 4.39583C12.3403 3.13194 10.8056 2.5 9 2.5C7.19444 2.5 5.65972 3.13194 4.39583 4.39583C3.13194 5.65972 2.5 7.19444 2.5 9C2.5 10.8056 3.13194 12.3403 4.39583 13.6042C5.65972 14.8681 7.19444 15.5 9 15.5Z\" fill=\"#444746\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_1227_2376\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/stop_icon_disable.svg":
/*!*******************************************!*\
  !*** ./style/icons/stop_icon_disable.svg ***!
  \*******************************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_1227_2376)\">\n<path d=\"M6 12H12V6H6V12ZM9 17C7.90278 17 6.86806 16.7917 5.89583 16.375C4.92361 15.9583 4.06944 15.3889 3.33333 14.6667C2.61111 13.9306 2.04167 13.0764 1.625 12.1042C1.20833 11.1319 1 10.0972 1 9C1 7.88889 1.20833 6.85417 1.625 5.89583C2.04167 4.92361 2.61111 4.07639 3.33333 3.35417C4.06944 2.61805 4.92361 2.04167 5.89583 1.625C6.86806 1.20833 7.90278 0.999999 9 0.999999C10.1111 0.999999 11.1458 1.20833 12.1042 1.625C13.0764 2.04167 13.9236 2.61805 14.6458 3.35417C15.3819 4.07639 15.9583 4.92361 16.375 5.89583C16.7917 6.85417 17 7.88889 17 9C17 10.0972 16.7917 11.1319 16.375 12.1042C15.9583 13.0764 15.3819 13.9306 14.6458 14.6667C13.9236 15.3889 13.0764 15.9583 12.1042 16.375C11.1458 16.7917 10.1111 17 9 17ZM9 15.5C10.8056 15.5 12.3403 14.8681 13.6042 13.6042C14.8681 12.3403 15.5 10.8056 15.5 9C15.5 7.19444 14.8681 5.65972 13.6042 4.39583C12.3403 3.13194 10.8056 2.5 9 2.5C7.19444 2.5 5.65972 3.13194 4.39583 4.39583C3.13194 5.65972 2.5 7.19444 2.5 9C2.5 10.8056 3.13194 12.3403 4.39583 13.6042C5.65972 14.8681 7.19444 15.5 9 15.5Z\" fill=\"#8A8A8A\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_1227_2376\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/submit_job_icon.svg":
/*!*****************************************!*\
  !*** ./style/icons/submit_job_icon.svg ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "<svg width=\"14\" height=\"14\" viewBox=\"0 0 14 14\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M12.25 0.25H1.75C0.9175 0.25 0.25 0.925 0.25 1.75V12.25C0.25 13.075 0.9175 13.75 1.75 13.75H12.25C13.075 13.75 13.75 13.075 13.75 12.25V1.75C13.75 0.925 13.075 0.25 12.25 0.25ZM10.75 7.75H7.75V10.75H6.25V7.75H3.25V6.25H6.25V3.25H7.75V6.25H10.75V7.75Z\" fill=\"#3367D6\"/>\n</svg>\n";

/***/ }),

/***/ "./style/icons/succeeded_icon.svg":
/*!****************************************!*\
  !*** ./style/icons/succeeded_icon.svg ***!
  \****************************************/
/***/ ((module) => {

module.exports = "<svg width=\"14\" height=\"15\" viewBox=\"0 0 14 15\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M7 0.5C3.136 0.5 0 3.636 0 7.5C0 11.364 3.136 14.5 7 14.5C10.864 14.5 14 11.364 14 7.5C14 3.636 10.864 0.5 7 0.5ZM5.6 11L2.1 7.5L3.087 6.513L5.6 9.019L10.913 3.706L11.9 4.7L5.6 11Z\" fill=\"#188038\"/>\n</svg>\n";

/***/ }),

/***/ "./style/icons/table_icon.svg":
/*!************************************!*\
  !*** ./style/icons/table_icon.svg ***!
  \************************************/
/***/ ((module) => {

module.exports = "<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_3237_14396)\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M16 2H2V16H16V2ZM6 8H4V10H6V8ZM4 4H14V6H4V4ZM6 12H4V14H6V12ZM8 8H10V10H8V8ZM14 8H12V10H14V8ZM8 12H10V14H8V12ZM14 12H12V14H14V12Z\" fill=\"black\" fill-opacity=\"0.66\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_3237_14396\">\n<rect width=\"18\" height=\"18\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>\n";

/***/ }),

/***/ "./style/icons/view_logs_icon.svg":
/*!****************************************!*\
  !*** ./style/icons/view_logs_icon.svg ***!
  \****************************************/
/***/ ((module) => {

module.exports = "<svg width=\"14\" height=\"14\" viewBox=\"0 0 14 14\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M12.25 12.25H1.75V1.75H7V0.25H1.75C0.9175 0.25 0.25 0.925 0.25 1.75V12.25C0.25 13.075 0.9175 13.75 1.75 13.75H12.25C13.075 13.75 13.75 13.075 13.75 12.25V7H12.25V12.25ZM8.5 0.25V1.75H11.1925L3.82 9.1225L4.8775 10.18L12.25 2.8075V5.5H13.75V0.25H8.5Z\" fill=\"#3367D6\"/>\n</svg>\n";

/***/ })

}]);
//# sourceMappingURL=lib_index_js-data_application_font-woff_charset_utf-8_base64_d09GRgABAAAAAAVgAA8AAAAACFAAAQAA-c66fb0.ff15b5b5553067fe4cb9.js.map